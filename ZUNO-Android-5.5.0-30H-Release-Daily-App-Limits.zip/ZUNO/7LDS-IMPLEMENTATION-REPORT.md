# VYRA 4.2.4 — 7-Layer Defense and Multi-Year Focus Lock

## Implemented in this source package

1. **Persistent deadline:** timed Focus locks store a start timestamp, end timestamp and duration label in app-private SharedPreferences.
2. **In-app emergency gate:** when Strict Mode is active, the normal early-exit flow is replaced by Android device-credential verification. If the device has no secure credential configured, the fallback requires a 60-second delay and the exact phrase `RELEASE VYRA`, followed by a second confirmation.
3. **Selected-app list lock:** the existing app picker refuses edits while a Focus session is active. The selected package list remains stored locally.
4. **Accessibility enforcement:** the existing Accessibility service applies selected-app rules while the service remains enabled by the user. The layer dashboard reports whether the setting is enabled.
5. **Saved-session recovery:** the absolute end timestamp is persisted, so the countdown can be reconstructed after the app process is restarted. The boot/time-change receiver records recovery events. Actual app blocking after a restart still depends on Android re-enabling the Accessibility service.
6. **Device Admin:** the dashboard reports the optional Device Admin receiver state. This app's Device Admin policy is limited and does not prevent the device owner from uninstalling it.
7. **Device Owner:** the dashboard reports whether Android has provisioned this app as Device Owner. It does not claim this mode is enabled by default, and this package does not silently provision or activate managed-device policies.

## Multi-year Custom Lock

The Custom Lock picker supports 0–25 years, 0–11 additional months, 0–30 days, 0–23 hours and 0–59 minutes. The end date is calculated with `ZonedDateTime` calendar arithmetic. A year is not treated as exactly 365 days and a month is not treated as exactly 30 days. The remaining-time display shows years, months, days, hours, minutes and seconds. The circular dial uses a compact years/months/days display for long sessions.

The open-ended Long-term Journey remains separate. It is an elapsed-time tracker, while Custom Lock is a fixed-expiry countdown.

## Emergency and platform limitations

Strict Mode is designed to prevent casual early exit inside VYRA, not to trap a device owner. Android Settings, force-stop, app-data clearing, system recovery, permission revocation and uninstall remain operating-system controls. Changing the device clock can affect an offline wall-clock deadline. A normal app cannot guarantee seven independent, undefeatable system enforcement layers. Device Owner is a managed-device provisioning mode and is not enabled by the app itself.

Only block apps needed for distraction control. Keep essential communication, emergency, system settings and device recovery available. Do not use this app to restrict another person's device without their knowledge and consent.

## Preserved earlier fixes

- The three visual-scan layout variables in `MainActivity.java` remain `LinearLayout.LayoutParams`; `fullWrap()` and `fullWidth()` return that type.
- The long-term journey calculation continues to use `ZonedDateTime.plus(Duration.ofMillis(...))`, not the unsupported `plusMillis()` method.
- Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17 and SDK 35 are retained.
- The workflow continues to extract the ZIP before Gradle setup and invokes the installed Gradle 8.9 command because the source archive has no Gradle wrapper.

## Verification status

- Original ZIP integrity: passed.
- New ZIP integrity and expected `VYRA/` root: checked after packaging.
- Java source syntax / structural checks: to be recorded in the final packaging report.
- Pure Java `FocusDuration` logic: checked with a local Java harness.
- Unit tests: source added for calendar/leap-year/DST/zero-duration cases; a full Gradle test run requires GitHub Actions.
- Android `assembleDebug`, D8, APK packaging and on-device tests: not run in this environment because Android SDK and Gradle are not installed here. No APK is claimed as built.
