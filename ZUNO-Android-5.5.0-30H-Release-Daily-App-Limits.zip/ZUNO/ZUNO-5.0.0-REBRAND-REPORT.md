# ZUNO 5.0.0 — Rebrand and Islamic visual refresh

## Identity
- Full product name: **ZUNO — Islamic Wellness & Digital Protection**.
- Launcher display name: **ZUNO**.
- Primary app/launcher logo: supplied user image (mosque, crescent and ZUNO wordmark).
- Palette: midnight `#101012`, charcoal `#211F1D`, warm gold `#DDB56B`, ivory `#F5E8D0`, warm muted text `#BEB195`.

## Updated surfaces
- App launcher/adaptive icon.
- Onboarding/welcome screens.
- Main dashboard and focus/protection pages.
- Adult-content block screen.
- Prayer, Azan, Qibla and Hijri calendar screen.
- Offline guide and arcade screens.
- Android app theme, status/navigation bars, app labels and user-visible brand text.

## Existing capabilities preserved
- Shia prayer times, Azan audio asset and lock-screen notification Stop action.
- Qibla and Hijri calendar/observance countdowns.
- Focus timer, All-in-One timer, streaks and levels.
- Adult-content domain/text/image protection features and included TFLite assets.

## Compatibility decisions
- `applicationId`/namespace remain `com.nexas.safe` so this remains an upgrade of the same Android app rather than a separate installation.
- Existing preference names, notification channel IDs, receiver/service class names and Java package names remain unchanged to avoid losing settings or scheduled alarms.
- Internal class name `VyraGuideActivity` is retained, but user-facing text is rebranded.

## Checks performed
- Java grammar parse via JDK compiler: no Java syntax diagnostics (Android SDK classes are not installed here, so this is not a full compile).
- Android XML resources and manifest: parsed successfully.
- Supplied logo: copied to drawable-nodpi and launcher drawable resources.
- Adaptive launcher icon XML references the new ZUNO image.
- Gradle build attempted with `./gradlew --no-daemon testDebugUnitTest assembleDebug --offline`; wrapper could not download Gradle 8.9 because `services.gradle.org` DNS/network access is unavailable. No APK build or Android 16 visual/device test is claimed.

## Build environment
- Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17, compile/target SDK 35, min SDK 26.
- Version name 5.0.0, version code 26.
