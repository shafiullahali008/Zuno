# Keep the TensorFlow Lite Java/JNI API and native bridge used by the local image classifier.
-keep class org.tensorflow.lite.** { *; }
-keepclasseswithmembers class * { native <methods>; }
