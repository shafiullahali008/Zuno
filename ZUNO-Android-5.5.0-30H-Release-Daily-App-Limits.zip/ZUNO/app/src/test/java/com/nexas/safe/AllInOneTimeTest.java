package com.nexas.safe;

import org.junit.Test;
import static org.junit.Assert.*;

public class AllInOneTimeTest {
    @Test public void validatesDurationBounds() {
        assertFalse(AllInOneTime.isValidDuration(59_999L));
        assertTrue(AllInOneTime.isValidDuration(60_000L));
        assertTrue(AllInOneTime.isValidDuration(7L * AllInOneTime.DAY_MS));
        assertTrue(AllInOneTime.isValidDuration(AllInOneTime.MAX_DURATION_MS));
        assertFalse(AllInOneTime.isValidDuration(AllInOneTime.MAX_DURATION_MS + 1L));
    }

    @Test public void firstStreakDayStartsImmediately() {
        assertEquals(1, AllInOneTime.currentStreakDay(0L));
        assertEquals(1, AllInOneTime.currentStreakDay(AllInOneTime.DAY_MS - 1L));
        assertEquals(2, AllInOneTime.currentStreakDay(AllInOneTime.DAY_MS));
    }

    @Test public void completedDaysCountOnlyFullDays() {
        assertEquals(0, AllInOneTime.completedDays(0L));
        assertEquals(0, AllInOneTime.completedDays(AllInOneTime.DAY_MS - 1L));
        assertEquals(1, AllInOneTime.completedDays(AllInOneTime.DAY_MS));
        assertEquals(7, AllInOneTime.completedDays(7L * AllInOneTime.DAY_MS));
    }

    @Test public void elapsedIsNeverNegative() {
        assertEquals(0L, AllInOneTime.elapsed(100L, 99L));
        assertEquals(500L, AllInOneTime.elapsed(100L, 600L));
    }
}
