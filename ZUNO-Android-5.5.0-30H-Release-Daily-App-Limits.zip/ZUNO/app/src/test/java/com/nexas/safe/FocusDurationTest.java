package com.nexas.safe;

import org.junit.Test;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import static org.junit.Assert.*;

public class FocusDurationTest {
    private static final ZoneId KARACHI = ZoneId.of("Asia/Karachi");

    @Test public void customLockSupportsCalendarYearsAndMonths() {
        long start = ZonedDateTime.of(2026, 11, 25, 12, 0, 0, 0, KARACHI).toInstant().toEpochMilli();
        long end = FocusDuration.calculateEndAtMillis(start, KARACHI, 3, 6, 2, 4, 30);
        ZonedDateTime result = Instant.ofEpochMilli(end).atZone(KARACHI);
        assertEquals(2030, result.getYear());
        assertEquals(5, result.getMonthValue());
        assertEquals(27, result.getDayOfMonth());
        assertEquals(16, result.getHour());
        assertEquals(30, result.getMinute());
    }

    @Test public void oneYearFromLeapDayUsesCalendarRules() {
        ZoneId utc = ZoneId.of("UTC");
        long start = ZonedDateTime.of(2024, 2, 29, 8, 0, 0, 0, utc).toInstant().toEpochMilli();
        long end = FocusDuration.calculateEndAtMillis(start, utc, 1, 0, 0, 0, 0);
        ZonedDateTime result = Instant.ofEpochMilli(end).atZone(utc);
        assertEquals(2025, result.getYear());
        assertEquals(2, result.getMonthValue());
        assertEquals(28, result.getDayOfMonth());
    }

    @Test public void calendarDayRespectsDaylightSavingTime() {
        ZoneId newYork = ZoneId.of("America/New_York");
        long start = ZonedDateTime.of(2026, 3, 7, 12, 0, 0, 0, newYork).toInstant().toEpochMilli();
        long end = FocusDuration.calculateEndAtMillis(start, newYork, 0, 0, 1, 0, 0);
        assertEquals(23L, (end - start) / 3_600_000L);
    }

    @Test public void zeroDurationIsRejected() {
        try {
            FocusDuration.calculateEndAtMillis(0L, KARACHI, 0, 0, 0, 0, 0);
            fail("Expected zero duration to be rejected");
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().contains("greater than zero"));
        }
    }

    @Test public void expiredLockDisplaysZero() {
        long now = ZonedDateTime.of(2026, 11, 25, 12, 0, 0, 0, KARACHI).toInstant().toEpochMilli();
        assertEquals("0 years · 0 months · 0 days\n00:00:00 remaining",
                FocusDuration.formatRemaining(now, now - 1L, KARACHI));
    }
}
