package com.nexas.safe;

import org.junit.Test;
import static org.junit.Assert.*;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Map;

public class ShiaPrayerCalculatorTest {
    @Test public void jafariTimesAreChronologicallyOrderedForWahCantt() {
        LocalDate date = LocalDate.of(2026, 11, 25);
        Map<String, ZonedDateTime> times = ShiaPrayerCalculator.calculate(date, 33.7995, 72.7221,
                ZoneId.of("Asia/Karachi"), ShiaPrayerCalculator.Method.JAFARI_QOM, new int[6]);
        assertTrue(times.get("Fajr").isBefore(times.get("Sunrise")));
        assertTrue(times.get("Sunrise").isBefore(times.get("Dhuhr")));
        assertTrue(times.get("Dhuhr").isBefore(times.get("Asr")));
        assertTrue(times.get("Asr").isBefore(times.get("Maghrib")));
        assertTrue(times.get("Maghrib").isBefore(times.get("Isha")));
    }

    @Test public void prayerOffsetsAreAppliedInMinutes() {
        LocalDate date = LocalDate.of(2026, 11, 25);
        int[] offsets = new int[6]; offsets[0] = 5;
        Map<String, ZonedDateTime> base = ShiaPrayerCalculator.calculate(date, 33.7995, 72.7221,
                ZoneId.of("Asia/Karachi"), ShiaPrayerCalculator.Method.JAFARI_QOM, new int[6]);
        Map<String, ZonedDateTime> tuned = ShiaPrayerCalculator.calculate(date, 33.7995, 72.7221,
                ZoneId.of("Asia/Karachi"), ShiaPrayerCalculator.Method.JAFARI_QOM, offsets);
        assertEquals(5L, java.time.Duration.between(base.get("Fajr"), tuned.get("Fajr")).toMinutes());
    }

    @Test public void seasonalDatesDoNotRollPrayerTimesIntoPreviousDay() {
        LocalDate[] dates = {
                LocalDate.of(2026, 1, 1), LocalDate.of(2026, 3, 20), LocalDate.of(2026, 6, 21),
                LocalDate.of(2026, 9, 22), LocalDate.of(2026, 11, 25)
        };
        for (LocalDate date : dates) {
            Map<String, ZonedDateTime> times = ShiaPrayerCalculator.calculate(date, 33.7995, 72.7221,
                    ZoneId.of("Asia/Karachi"), ShiaPrayerCalculator.Method.JAFARI_QOM, new int[6]);
            assertEquals(date, times.get("Fajr").toLocalDate());
            assertEquals(date, times.get("Maghrib").toLocalDate());
        }
    }

    @Test public void highLatitudeFallbackProducesFiniteTimes() {
        Map<String, ZonedDateTime> times = ShiaPrayerCalculator.calculate(LocalDate.of(2026, 12, 21),
                69.65, 18.96, ZoneId.of("Europe/Oslo"), ShiaPrayerCalculator.Method.JAFARI_QOM, new int[6]);
        for (ZonedDateTime time : times.values()) assertNotNull(time);
    }

    @Test public void jafariMidnightFallsBetweenMaghribAndTomorrowFajr() {
        LocalDate date = LocalDate.of(2026, 11, 25);
        ZoneId zone = ZoneId.of("Asia/Karachi");
        ZonedDateTime midnight = ShiaPrayerCalculator.jafariMidnight(date, 33.7995, 72.7221, zone,
                ShiaPrayerCalculator.Method.JAFARI_QOM, new int[6]);
        ZonedDateTime maghrib = ShiaPrayerCalculator.calculate(date, 33.7995, 72.7221, zone,
                ShiaPrayerCalculator.Method.JAFARI_QOM, new int[6]).get("Maghrib");
        ZonedDateTime fajr = ShiaPrayerCalculator.calculate(date.plusDays(1), 33.7995, 72.7221, zone,
                ShiaPrayerCalculator.Method.JAFARI_QOM, new int[6]).get("Fajr");
        assertTrue(midnight.isAfter(maghrib));
        assertTrue(midnight.isBefore(fajr));
    }
}
