Bundled NEXAS-owned prototype models:
- text_safety.tflite: text-risk screening (synthetic training examples)
- url_risk.tflite: URL-pattern screening (synthetic training examples)

Only these two TFLite weights are part of ZUNO's Android AI runtime. Missing, incompatible or failed inference returns UNKNOWN. Prototype scores are advisory and are not a guarantee of safety.
