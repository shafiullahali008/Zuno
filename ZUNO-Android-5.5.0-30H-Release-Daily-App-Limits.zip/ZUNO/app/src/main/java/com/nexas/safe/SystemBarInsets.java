package com.nexas.safe;

import android.graphics.Insets;
import android.os.Build;
import android.view.View;
import android.view.WindowInsets;

/** Applies system-bar and display-cutout spacing for target-35 edge-to-edge windows. */
final class SystemBarInsets {
    private SystemBarInsets() { }

    static void apply(View root) {
        if (root == null || Build.VERSION.SDK_INT < 35) return;
        final int baseLeft = root.getPaddingLeft();
        final int baseTop = root.getPaddingTop();
        final int baseRight = root.getPaddingRight();
        final int baseBottom = root.getPaddingBottom();
        root.setOnApplyWindowInsetsListener((view, windowInsets) -> {
            Insets bars = windowInsets.getInsets(
                    WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            view.setPadding(baseLeft + bars.left, baseTop + bars.top,
                    baseRight + bars.right, baseBottom + bars.bottom);
            return windowInsets;
        });
        root.requestApplyInsets();
    }
}
