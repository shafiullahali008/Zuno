package com.nexas.safe;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

/** Offline solar prayer-time calculator using the Jafari (Qom) convention by default. */
public final class ShiaPrayerCalculator {
    public enum Method {
        JAFARI_QOM(16.0, 4.0, 14.0, "Jafari (Qom)"),
        TEHRAN(17.7, 4.5, 14.0, "University of Tehran"),
        ISLAMIC_CENTRE_ENGLAND(15.0, Double.NaN, 14.0, "Islamic Centre of England");
        public final double fajrAngle, maghribAngle, ishaAngle;
        public final String title;
        Method(double fajr, double maghrib, double isha, String title) {
            this.fajrAngle = fajr; this.maghribAngle = maghrib; this.ishaAngle = isha; this.title = title;
        }
    }

    public static final String[] KEYS = {"Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha"};
    private static final double SUNRISE_ANGLE = 0.833;
    private ShiaPrayerCalculator() { }

    public static Map<String, ZonedDateTime> calculate(LocalDate date, double latitude, double longitude,
            ZoneId zone, Method method, int[] offsetsMinutes) {
        if (date == null || zone == null || method == null) throw new IllegalArgumentException("Date, zone and method are required");
        if (!Double.isFinite(latitude) || latitude < -90 || latitude > 90 || !Double.isFinite(longitude) || longitude < -180 || longitude > 180)
            throw new IllegalArgumentException("Invalid coordinates");
        int[] offsets = offsetsMinutes == null ? new int[6] : offsetsMinutes;
        if (offsets.length < 6) throw new IllegalArgumentException("Six prayer offsets are required");

        Solar solar = solar(date, latitude, longitude, zone);
        double noon = solar.solarNoonHours;
        double sunriseAngle = hourAngleForAltitude(-SUNRISE_ANGLE, latitude, solar.declination);
        // At extreme latitudes the Sun may not reach a requested angle. Use an angle-based
        // fraction of the estimated night instead of returning a bogus midnight time.
        if (!Double.isFinite(sunriseAngle)) sunriseAngle = 6.0;
        double sunrise = noon - sunriseAngle;
        double sunset = noon + sunriseAngle;
        double nightHours = Math.max(1.0, 24.0 - 2.0 * sunriseAngle);
        double fajrAngle = hourAngleForAltitude(-method.fajrAngle, latitude, solar.declination);
        double fajr = Double.isFinite(fajrAngle) ? noon - fajrAngle : sunrise - nightHours * method.fajrAngle / 60.0;
        double dhuhr = noon + 1.0 / 60.0;
        double asrAltitude = Math.toDegrees(Math.atan(1.0 / (1.0 + Math.tan(Math.toRadians(Math.abs(latitude - solar.declination))))));
        double asrAngle = hourAngleForAltitude(asrAltitude, latitude, solar.declination);
        double asr = noon + (Double.isFinite(asrAngle) ? asrAngle : 4.0);
        double maghrib;
        if (Double.isNaN(method.maghribAngle)) {
            // Islamic Centre of England convention: sunset plus 15 minutes.
            maghrib = sunset + 15.0 / 60.0;
        } else {
            double maghribAngle = hourAngleForAltitude(-method.maghribAngle, latitude, solar.declination);
            maghrib = Double.isFinite(maghribAngle) ? noon + maghribAngle
                    : sunset + nightHours * method.maghribAngle / 60.0;
        }
        double ishaAngle = hourAngleForAltitude(-method.ishaAngle, latitude, solar.declination);
        double isha = Double.isFinite(ishaAngle) ? noon + ishaAngle : sunset + nightHours * method.ishaAngle / 60.0;

        double[] hours = {fajr, sunrise, dhuhr, asr, maghrib, isha};
        Map<String, ZonedDateTime> result = new LinkedHashMap<>();
        for (int i = 0; i < hours.length; i++) {
            long mins = Math.round(hours[i] * 60.0) + offsets[i];
            LocalDateTime local = date.atStartOfDay().plusMinutes(mins);
            result.put(KEYS[i], local.atZone(zone));
        }
        return result;
    }

    /** Jafari religious midnight: midpoint between today's Maghrib and tomorrow's Fajr. */
    public static ZonedDateTime jafariMidnight(LocalDate date, double latitude, double longitude, ZoneId zone,
            Method method, int[] offsetsMinutes) {
        Map<String, ZonedDateTime> today = calculate(date, latitude, longitude, zone, method, offsetsMinutes);
        Map<String, ZonedDateTime> tomorrow = calculate(date.plusDays(1), latitude, longitude, zone, method, offsetsMinutes);
        ZonedDateTime maghrib = today.get("Maghrib");
        ZonedDateTime fajr = tomorrow.get("Fajr");
        return maghrib.plusSeconds(java.time.Duration.between(maghrib, fajr).getSeconds() / 2L);
    }

    private static double hourAngleForAltitude(double altitudeDegrees, double latitude, double declinationDegrees) {
        double lat = Math.toRadians(latitude);
        double dec = Math.toRadians(declinationDegrees);
        double alt = Math.toRadians(altitudeDegrees);
        double denominator = Math.cos(lat) * Math.cos(dec);
        if (Math.abs(denominator) < 1.0e-10) return Double.NaN;
        double cosH = (Math.sin(alt) - Math.sin(lat) * Math.sin(dec)) / denominator;
        if (cosH < -1.0 || cosH > 1.0) return Double.NaN;
        return Math.toDegrees(Math.acos(cosH)) / 15.0;
    }

    private static Solar solar(LocalDate date, double latitude, double longitude, ZoneId zone) {
        double jd = julianDay(date);
        double d = jd - 2451545.0;
        double g = normalizeDegrees(357.529 + 0.98560028 * d);
        double q = normalizeDegrees(280.459 + 0.98564736 * d);
        double l = normalizeDegrees(q + 1.915 * sin(g) + 0.020 * sin(2.0 * g));
        double e = 23.439 - 0.00000036 * d;
        double ra = normalizeHours(Math.toDegrees(Math.atan2(cos(e) * sin(l), cos(l))) / 15.0);
        double equation = q / 15.0 - ra;
        // Right-ascension wraps at 0/24h; normalize the difference to the small
        // equation-of-time interval instead of allowing a near-24h jump.
        if (equation > 12.0) equation -= 24.0;
        else if (equation < -12.0) equation += 24.0;
        double declination = Math.toDegrees(Math.asin(sin(e) * sin(l)));
        ZoneOffset offset = zone.getRules().getOffset(date.atTime(12, 0));
        double zoneHours = offset.getTotalSeconds() / 3600.0;
        double noon = 12.0 + zoneHours - longitude / 15.0 - equation;
        return new Solar(noon, declination);
    }

    private static double julianDay(LocalDate date) {
        int y = date.getYear();
        int m = date.getMonthValue();
        int d = date.getDayOfMonth();
        if (m <= 2) { y--; m += 12; }
        int a = y / 100;
        int b = 2 - a + a / 4;
        return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + b - 1524.5;
    }
    private static double normalizeDegrees(double value) { return ((value % 360.0) + 360.0) % 360.0; }
    private static double normalizeHours(double value) { return ((value % 24.0) + 24.0) % 24.0; }
    private static double sin(double d) { return Math.sin(Math.toRadians(d)); }
    private static double cos(double d) { return Math.cos(Math.toRadians(d)); }

    private static final class Solar {
        final double solarNoonHours, declination;
        Solar(double noon, double declination) { this.solarNoonHours = noon; this.declination = declination; }
    }
}
