package com.nexas.safe;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class NexasDeviceAdminReceiver extends DeviceAdminReceiver {
    @Override public void onEnabled(Context context, Intent intent) {
        Toast.makeText(context, "ZUNO Admin enabled", Toast.LENGTH_SHORT).show();
    }
    @Override public CharSequence onDisableRequested(Context context, Intent intent) {
        return "Disabling this optional permission turns off ZUNO Device Admin features. Android system controls remain available.";
    }
    @Override public void onDisabled(Context context, Intent intent) {
        Toast.makeText(context, "ZUNO Admin disabled", Toast.LENGTH_SHORT).show();
    }
}
