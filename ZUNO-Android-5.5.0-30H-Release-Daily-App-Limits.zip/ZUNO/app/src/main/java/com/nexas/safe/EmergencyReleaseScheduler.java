package com.nexas.safe;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** Persistent, user-requested delayed release. Undo is offered only during the first 30 seconds. */
final class EmergencyReleaseScheduler {
    static final long RELEASE_DELAY_MS = 30L * 60L * 60L * 1000L;
    static final long UNDO_WINDOW_MS = 30_000L;
    static final String ACTION_RELEASE = "com.nexas.safe.action.DELAYED_FOCUS_RELEASE";
    private static final int REQUEST_CODE = 7591;

    private EmergencyReleaseScheduler() { }

    static long request(Context context) {
        long now = System.currentTimeMillis();
        long releaseAt = now + RELEASE_DELAY_MS;
        ProtectionPrefs.prefs(context).edit()
                .putLong(ProtectionPrefs.KEY_PENDING_RELEASE_AT, releaseAt)
                .putLong(ProtectionPrefs.KEY_RELEASE_UNDO_UNTIL, now + UNDO_WINDOW_MS)
                .commit();
        scheduleAt(context, releaseAt);
        return releaseAt;
    }

    static long pendingAt(Context context) {
        return ProtectionPrefs.prefs(context).getLong(ProtectionPrefs.KEY_PENDING_RELEASE_AT, 0L);
    }

    static long undoUntil(Context context) {
        return ProtectionPrefs.prefs(context).getLong(ProtectionPrefs.KEY_RELEASE_UNDO_UNTIL, 0L);
    }

    static boolean canUndo(Context context) {
        long pending = pendingAt(context);
        return pending > System.currentTimeMillis() && undoUntil(context) >= System.currentTimeMillis();
    }

    static void cancel(Context context) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm != null) alarm.cancel(pendingIntent(context));
        ProtectionPrefs.prefs(context).edit()
                .remove(ProtectionPrefs.KEY_PENDING_RELEASE_AT)
                .remove(ProtectionPrefs.KEY_RELEASE_UNDO_UNTIL)
                .commit();
    }

    static void restore(Context context) {
        long at = pendingAt(context);
        if (at <= 0L) return;
        if (at <= System.currentTimeMillis()) {
            completeIfDue(context);
        } else {
            scheduleAt(context, at);
        }
    }

    static void completeIfDue(Context context) {
        long at = pendingAt(context);
        if (at <= 0L) return;
        if (System.currentTimeMillis() < at) {
            scheduleAt(context, at);
            return;
        }
        android.content.SharedPreferences saved = ProtectionPrefs.prefs(context);
        long now = System.currentTimeMillis();
        long started = saved.getLong(ProtectionPrefs.KEY_FOCUS_JOURNEY_STARTED_AT,
                saved.getLong(ProtectionPrefs.KEY_FOCUS_STARTED_AT, now));
        long elapsed = Math.max(0L, now - started);
        boolean allInOne = saved.getBoolean(ProtectionPrefs.KEY_ALL_IN_ONE_ACTIVE, false);
        android.content.SharedPreferences.Editor edit = saved.edit()
                .putLong(ProtectionPrefs.KEY_FOCUS_UNTIL, 0L)
                .putBoolean(ProtectionPrefs.KEY_FOCUS_JOURNEY_ACTIVE, false)
                .putBoolean(ProtectionPrefs.KEY_ALL_IN_ONE_ACTIVE, false)
                .putLong(ProtectionPrefs.KEY_ALL_IN_ONE_END_AT, 0L)
                .putLong(ProtectionPrefs.KEY_FOCUS_JOURNEY_LAST_MS, elapsed)
                .remove(ProtectionPrefs.KEY_PENDING_RELEASE_AT)
                .remove(ProtectionPrefs.KEY_RELEASE_UNDO_UNTIL);
        if (allInOne) edit.putLong(ProtectionPrefs.KEY_ALL_IN_ONE_LAST_ELAPSED_MS, elapsed);
        edit.commit();
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm != null) alarm.cancel(pendingIntent(context));
    }

    private static void scheduleAt(Context context, long at) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarm.canScheduleExactAlarms()) {
                alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pendingIntent(context));
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pendingIntent(context));
            } else {
                alarm.set(AlarmManager.RTC_WAKEUP, at, pendingIntent(context));
            }
        } catch (SecurityException denied) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pendingIntent(context));
            } else {
                alarm.set(AlarmManager.RTC_WAKEUP, at, pendingIntent(context));
            }
        }
    }

    private static PendingIntent pendingIntent(Context context) {
        Intent intent = new Intent(context, EmergencyReleaseReceiver.class).setAction(ACTION_RELEASE);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, REQUEST_CODE, intent, flags);
    }
}
