package com.nexas.safe;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.content.res.ColorStateList;
import android.view.HapticFeedbackConstants;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.Window;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** The block screen can be dismissed to ZUNO without ending the active focus timer. */
public class BlockActivity extends Activity {
    private static final int BG = Color.rgb(5, 5, 7);
    private static final int WHITE = Color.rgb(255, 247, 225);
    private static final int MUTED = Color.rgb(190, 177, 151);
    private static final int TEAL = Color.rgb(255, 199, 48);
    private final Handler handler = new Handler();
    private final ExecutorService imageLoader = Executors.newSingleThreadExecutor();
    private TextView countdown;
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            updateCountdown();
            if (!isFinishing()) handler.postDelayed(this, 1000L);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(BG);
        window.setNavigationBarColor(BG);
        applyImmersiveBlockWindow();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        String imageRaw = ProtectionPrefs.prefs(this).getString(ProtectionPrefs.KEY_BLOCK_SCREEN_IMAGE, "");
        if (imageRaw != null && !imageRaw.isEmpty()) {
            ImageView fullScreenImage = new ImageView(this);
            fullScreenImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
            root.addView(fullScreenImage, new FrameLayout.LayoutParams(-1, -1));
            loadCustomImageAsync(Uri.parse(imageRaw), fullScreenImage);
            View scrim = new View(this);
            GradientDrawable overlay = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{0x66030407, 0x26030407, 0x99030407});
            scrim.setBackground(overlay);
            root.addView(scrim, new FrameLayout.LayoutParams(-1, -1));
        } else {
            root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[]{Color.rgb(5, 5, 7), Color.rgb(20, 18, 16), Color.rgb(7, 7, 9)}));
        }
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.setPadding(dp(24), dp(20), dp(24), dp(26));
        FrameLayout.LayoutParams contentLp = new FrameLayout.LayoutParams(-1, -1);
        root.addView(content, contentLp);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("ZUNO  /  FOCUS", 11, TEAL, true);
        brand.setLetterSpacing(0.16f);
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1f));
        Button close = new Button(this);
        close.setText("×");
        close.setTextSize(23);
        close.setTextColor(WHITE);
        close.setAllCaps(false);
        close.setMinWidth(dp(42));
        close.setMinHeight(dp(42));
        close.setBackground(ripple(round(Color.rgb(27, 25, 22), 14, Color.rgb(132, 96, 35)), Color.argb(65, 226, 183, 107)));
        addPressMotion(close);
        close.setOnClickListener(v -> openNexasDashboard());
        top.addView(close, new LinearLayout.LayoutParams(dp(46), dp(46)));
        content.addView(top, matchWrap());

        TextView shield = text("◈", 52, TEAL, true);
        shield.setGravity(Gravity.CENTER);
        shield.setShadowLayer(dp(16), 0f, 0f, Color.argb(175, 255, 199, 48));
        LinearLayout.LayoutParams shieldLp = matchWrap(); shieldLp.topMargin = dp(24);
        content.addView(shield, shieldLp);
        shield.setScaleX(0.78f); shield.setScaleY(0.78f); shield.setAlpha(0f);
        shield.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(620)
                .setInterpolator(new android.view.animation.OvershootInterpolator(0.85f)).start();
        android.animation.ObjectAnimator shieldPulse = android.animation.ObjectAnimator.ofFloat(shield, android.view.View.ALPHA, 1f, 0.78f, 1f);
        shieldPulse.setDuration(2800L); shieldPulse.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        shieldPulse.setInterpolator(new AccelerateDecelerateInterpolator()); shieldPulse.start();

        String reason = getIntent() == null ? "" : getIntent().getStringExtra("reason");
        boolean dailyLimit = "daily_limit".equals(reason);
        TextView brandTitle = text(dailyLimit ? "DAILY APP LIMIT REACHED" : "PROTECTION ACTIVE", 10, TEAL, true);
        brandTitle.setGravity(Gravity.CENTER);
        brandTitle.setLetterSpacing(0.14f);
        LinearLayout.LayoutParams btLp = matchWrap(); btLp.topMargin = dp(12); btLp.bottomMargin = dp(20);
        content.addView(brandTitle, btLp);

        TextView heading = text(dailyLimit ? "Time is up." : "Stay focused.", 34, WHITE, true);
        heading.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams headingLp = matchWrap(); headingLp.bottomMargin = dp(12);
        content.addView(heading, headingLp);

        String customMessage = dailyLimit
                ? "You have reached today's time allowance for this app. Your daily limit resets at local midnight."
                : ProtectionPrefs.prefs(this).getString(ProtectionPrefs.KEY_BLOCK_SCREEN_TEXT,
                    "This content has been blocked to protect your focus.");
        if (customMessage == null || customMessage.trim().isEmpty()) {
            customMessage = "This content has been blocked to protect your focus.";
        }
        TextView message = text(customMessage, 15, MUTED, false);
        message.setGravity(Gravity.CENTER);
        message.setLineSpacing(dp(4), 1.0f);
        LinearLayout.LayoutParams messageLp = new LinearLayout.LayoutParams(-1, -2);
        messageLp.bottomMargin = dp(22);
        content.addView(message, messageLp);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(17), dp(17), dp(17), dp(17));
        card.setBackground(round(Color.rgb(27, 25, 22), 19, Color.rgb(132, 96, 35)));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
        cardLp.bottomMargin = dp(22);
        content.addView(card, cardLp);
        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);
        statusRow.addView(text(dailyLimit ? "DAILY SCREEN TIME" : "FOCUS SESSION", 10, MUTED, true), new LinearLayout.LayoutParams(0, -2, 1f));
        statusRow.addView(text("●  ACTIVE", 10, TEAL, true));
        card.addView(statusRow);
        countdown = text("", 25, WHITE, true);
        LinearLayout.LayoutParams countdownLp = matchWrap(); countdownLp.topMargin = dp(13);
        if (dailyLimit) countdown.setVisibility(View.GONE);
        card.addView(countdown, countdownLp);
        TextView sub = text(dailyLimit ? "Other apps remain available. This app becomes available again after the daily reset." : "Opening ZUNO will not stop this protection session.", 11, MUTED, false);
        LinearLayout.LayoutParams subLp = matchWrap(); subLp.topMargin = dp(5); card.addView(sub, subLp);

        Button openApp = new Button(this);
        openApp.setText("OPEN ZUNO");
        openApp.setTextColor(BG);
        openApp.setTextSize(13);
        openApp.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        openApp.setAllCaps(false);
        openApp.setLetterSpacing(0.05f);
        openApp.setBackground(ripple(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{Color.rgb(255, 235, 150), TEAL, Color.rgb(190, 126, 24)}), Color.argb(68, 255, 255, 255)));
        addPressMotion(openApp);
        openApp.setOnClickListener(v -> openNexasDashboard());
        content.addView(openApp, new LinearLayout.LayoutParams(-1, dp(54)));

        TextView footer = text("YOU CAN DISMISS THIS SCREEN • FOCUS MODE STAYS ACTIVE", 9, Color.rgb(190, 177, 151), true);
        footer.setGravity(Gravity.CENTER);
        footer.setLetterSpacing(0.04f);
        LinearLayout.LayoutParams footerLp = matchWrap(); footerLp.topMargin = dp(18);
        content.addView(footer, footerLp);

        setContentView(root);
        SystemBarInsets.apply(root);
        root.setAlpha(0f); root.setTranslationY(dp(12));
        root.animate().alpha(1f).translationY(0f).setDuration(440)
                .setInterpolator(new AccelerateDecelerateInterpolator()).start();
        headingEntrance(content);
        updateCountdown();
    }

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    private void updateCountdown() {
        if (countdown == null) return;
        if (!ProtectionPrefs.isFocusActive(this)) {
            countdown.setText("Protection ready");
            return;
        }
        long remaining = Math.max(0L, ProtectionPrefs.focusUntil(this) - System.currentTimeMillis());
        long seconds = remaining / 1000L;
        if (ProtectionPrefs.isAllInOneActive(this)) {
            long days = seconds / 86_400L;
            long hours = (seconds % 86_400L) / 3_600L;
            long minutes = (seconds % 3_600L) / 60L;
            long secs = seconds % 60L;
            countdown.setText(days > 0
                    ? String.format(Locale.ROOT, "ALL-IN-ONE • %dD %02d:%02d:%02d LEFT", days, hours, minutes, secs)
                    : String.format(Locale.ROOT, "ALL-IN-ONE • %02d:%02d:%02d LEFT", hours, minutes, secs));
            return;
        }
        if (ProtectionPrefs.isJourneyActive(this)) {
            countdown.setText("LONG-TERM JOURNEY ACTIVE");
            return;
        }
        countdown.setText(String.format(Locale.ROOT, "%02d:%02d:%02d remaining",
                seconds / 3600L, (seconds % 3600L) / 60L, seconds % 60L));
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private RippleDrawable ripple(GradientDrawable content, int rippleColor) {
        GradientDrawable mask = round(Color.WHITE, 16, Color.WHITE);
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), content, mask);
    }

    private void addPressMotion(Button button) {
        button.setElevation(dp(2));
        button.setOnTouchListener((view, event) -> {
            if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                view.animate().scaleX(0.965f).scaleY(0.965f).translationZ(dp(4)).setDuration(100).start();
                view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            } else if (event.getAction() == android.view.MotionEvent.ACTION_UP
                    || event.getAction() == android.view.MotionEvent.ACTION_CANCEL) {
                view.animate().scaleX(1f).scaleY(1f).translationZ(0f).setDuration(190)
                        .setInterpolator(new android.view.animation.OvershootInterpolator(1.12f)).start();
            }
            return false;
        });
    }

    private void headingEntrance(LinearLayout root) {
        for (int i = 0; i < root.getChildCount(); i++) {
            android.view.View child = root.getChildAt(i);
            if (child instanceof TextView) {
                child.setAlpha(0f);
                child.animate().alpha(1f).setStartDelay(90L + i * 28L).setDuration(360L).start();
            }
        }
    }

    private GradientDrawable round(int color, int radius, int stroke) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }


    private void applyImmersiveBlockWindow() {
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersiveBlockWindow();
    }

    private void openNexasDashboard() {
        Intent app = new Intent(this, MainActivity.class);
        app.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(app);
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void goHome() {
        Intent home = new Intent(Intent.ACTION_MAIN);
        home.addCategory(Intent.CATEGORY_HOME);
        home.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(home);
        finish();
    }


    private void loadCustomImageAsync(Uri uri, ImageView target) {
        imageLoader.execute(() -> {
            Bitmap decoded = null;
            try {
                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                try (InputStream input = getContentResolver().openInputStream(uri)) {
                    if (input == null) throw new IllegalStateException("Image cannot be opened");
                    BitmapFactory.decodeStream(input, null, bounds);
                }
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                    throw new IllegalStateException("Image dimensions are unavailable");
                }
                int sample = 1;
                int longest = Math.max(bounds.outWidth, bounds.outHeight);
                while (longest / sample > 1440) sample *= 2;
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = sample;
                options.inPreferredConfig = Bitmap.Config.ARGB_8888;
                try (InputStream input = getContentResolver().openInputStream(uri)) {
                    if (input == null) throw new IllegalStateException("Image cannot be opened");
                    decoded = BitmapFactory.decodeStream(input, null, options);
                }
                if (decoded == null) throw new IllegalStateException("Image decode returned no bitmap");
                final Bitmap result = decoded;
                handler.post(() -> {
                    if (isFinishing() || isDestroyed() || target.getParent() == null) {
                        if (!result.isRecycled()) result.recycle();
                    } else {
                        target.setImageBitmap(result);
                    }
                });
                decoded = null; // ownership transferred to the ImageView callback
            } catch (Exception | OutOfMemoryError ignored) {
                // Keep the block screen usable even if a user-selected image is unavailable.
            } finally {
                if (decoded != null && !decoded.isRecycled()) decoded.recycle();
            }
        });
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(ticker);
        imageLoader.shutdownNow();
        super.onDestroy();
    }

    @Override public void onBackPressed() { openNexasDashboard(); }
}
