package com.nexas.safe;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class EmergencyReleaseReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null || !EmergencyReleaseScheduler.ACTION_RELEASE.equals(intent.getAction())) return;
        EmergencyReleaseScheduler.completeIfDue(context);
    }
}
