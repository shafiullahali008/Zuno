package com.nexas.safe;

import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.security.MessageDigest;

/** Copies bundled, versioned TFLite models into private app storage and verifies SHA-256. */
final class NexasModelAssets {
    private NexasModelAssets() { }
    static File install(Context context, String name, String expectedSha256) {
        if (!name.equals("text_safety.tflite") && !name.equals("url_risk.tflite")) return null;
        File dir = new File(context.getNoBackupFilesDir(), "models");
        if (!dir.exists() && !dir.mkdirs()) return null;
        File target = new File(dir, name);
        try {
            if (!valid(target, expectedSha256)) {
                File temp = new File(dir, name + ".tmp");
                try (InputStream in = context.getAssets().open("models/" + name);
                     FileOutputStream out = new FileOutputStream(temp, false)) {
                    byte[] buffer = new byte[8192]; int n;
                    while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                    out.getFD().sync();
                }
                if (!valid(temp, expectedSha256)) { temp.delete(); return null; }
                if (target.exists()) target.delete();
                if (!temp.renameTo(target)) { temp.delete(); return null; }
            }
            return valid(target, expectedSha256) ? target : null;
        } catch (Exception e) { return null; }
    }
    private static boolean valid(File f, String expected) {
        if (f == null || !f.isFile() || f.length() < 100) return false;
        try (InputStream in = new java.io.FileInputStream(f)) {
            byte[] header = new byte[8];
            if (in.read(header) != 8 || header[4] != 'T' || header[5] != 'F' || header[6] != 'L' || header[7] != '3') return false;
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = new byte[65536]; int n;
            while ((n = in.read(b)) != -1) md.update(b, 0, n);
            StringBuilder hex = new StringBuilder();
            for (byte v : md.digest()) hex.append(String.format(java.util.Locale.ROOT, "%02x", v & 255));
            return expected.equals(hex.toString());
        } catch (Exception e) { return false; }
    }
}
