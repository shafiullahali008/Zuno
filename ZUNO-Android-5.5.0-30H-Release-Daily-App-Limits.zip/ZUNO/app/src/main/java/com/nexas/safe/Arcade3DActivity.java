package com.nexas.safe;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 * Device-safe, offline perspective arcade renderer.
 * Canvas rendering is used instead of requiring a particular OpenGL/EGL config;
 * the games keep their depth, motion, swipe controls and local gameplay.
 */
public final class Arcade3DActivity extends Activity {
    private static final int BG = Color.rgb(5, 5, 7);
    private static final int INK = Color.rgb(255, 247, 225);
    private static final int MUTED = Color.rgb(190, 177, 151);
    private static final int TEAL = Color.rgb(255, 199, 48);
    private static final int VIOLET = Color.rgb(190, 126, 24);
    private static final int AMBER = Color.rgb(255, 225, 139);
    private static final int ROSE = Color.rgb(255, 199, 48);

    private final Handler main = new Handler(Looper.getMainLooper());
    private String mode = "runner";
    private ArcadeCanvasView gameView;
    private TextView scoreText;
    private TextView statusText;
    private TextView pauseButton;
    private Button retryButton;
    private float downX;
    private float downY;
    private boolean gameFinished;

    private final Runnable uiTicker = new Runnable() {
        @Override public void run() {
            if (gameView != null && scoreText != null && !isFinishing() && !isDestroyed()) {
                scoreText.setText(gameView.getScoreLabel());
                if (gameView.isFinished() && !gameFinished) {
                    gameFinished = true;
                    statusText.setText(mode.equals("runner") ? "RUN COMPLETE · TRY AGAIN" : "COURSE COMPLETE · TRY AGAIN");
                    retryButton.setVisibility(View.VISIBLE);
                } else if (!gameView.isFinished() && !gameView.isPaused()) {
                    statusText.setText(gameView.getHint());
                    retryButton.setVisibility(View.GONE);
                }
            }
            if (!isFinishing() && !isDestroyed()) main.postDelayed(this, 250L);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        mode = getIntent().getStringExtra("game_mode");
        if (mode == null) mode = "runner";
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(
                0);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        gameView = new ArcadeCanvasView();
        root.addView(gameView, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(12), dp(10), dp(12), dp(10));
        top.setBackground(surface(Color.rgb(22, 21, 20), Color.rgb(137, 99, 35), 18));
        TextView back = chip("‹", 27, INK);
        top.addView(back, new LinearLayout.LayoutParams(dp(42), dp(42)));
        back.setOnClickListener(v -> finish());
        LinearLayout titleStack = new LinearLayout(this);
        titleStack.setOrientation(LinearLayout.VERTICAL);
        TextView title = label(mode.equals("runner") ? "TEMPLE SPRINT" : "ORBIT ROLL", 13, INK, true);
        TextView overline = label("ZUNO ARCADE  /  OFFLINE", 8, TEAL, true);
        overline.setLetterSpacing(0.10f);
        titleStack.addView(title);
        LinearLayout.LayoutParams overLp = new LinearLayout.LayoutParams(-2, -2);
        overLp.topMargin = dp(2);
        titleStack.addView(overline, overLp);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, -2, 1f);
        titleLp.leftMargin = dp(8);
        top.addView(titleStack, titleLp);
        scoreText = chip("0 M", 11, TEAL);
        top.addView(scoreText, new LinearLayout.LayoutParams(dp(74), dp(40)));
        pauseButton = chip("Ⅱ", 17, INK);
        LinearLayout.LayoutParams pauseLp = new LinearLayout.LayoutParams(dp(42), dp(42));
        pauseLp.leftMargin = dp(6);
        top.addView(pauseButton, pauseLp);
        pauseButton.setOnClickListener(v -> {
            boolean paused = gameView.togglePause();
            pauseButton.setText(paused ? "▶" : "Ⅱ");
            statusText.setText(paused ? "PAUSED" : gameView.getHint());
        });
        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        topLp.setMargins(dp(12), dp(10), dp(12), 0);
        root.addView(top, topLp);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setGravity(Gravity.CENTER);
        bottom.setPadding(dp(14), dp(11), dp(14), dp(12));
        bottom.setBackground(surface(Color.rgb(22, 21, 20), Color.rgb(137, 99, 35), 18));
        statusText = label(mode.equals("runner")
                ? "SWIPE LEFT / RIGHT · UP TO JUMP · DOWN TO SLIDE"
                : "SWIPE LEFT / RIGHT TO STEER · COLLECT LIGHT ORBS", 10, MUTED, true);
        statusText.setGravity(Gravity.CENTER);
        bottom.addView(statusText, new LinearLayout.LayoutParams(-1, -2));
        retryButton = new Button(this);
        retryButton.setText("PLAY AGAIN");
        retryButton.setTextColor(Color.rgb(24, 18, 8));
        retryButton.setTextSize(11);
        retryButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        retryButton.setAllCaps(false);
        retryButton.setBackground(surface(TEAL, TEAL, 14));
        retryButton.setVisibility(View.GONE);
        LinearLayout.LayoutParams retryLp = new LinearLayout.LayoutParams(-1, dp(44));
        retryLp.topMargin = dp(8);
        bottom.addView(retryButton, retryLp);
        retryButton.setOnClickListener(v -> {
            gameFinished = false;
            retryButton.setVisibility(View.GONE);
            pauseButton.setText("Ⅱ");
            gameView.resetGame();
            statusText.setText(gameView.getHint());
        });
        FrameLayout.LayoutParams bottomLp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        bottomLp.setMargins(dp(12), 0, dp(12), dp(10));
        root.addView(bottom, bottomLp);

        gameView.setOnTouchListener((v, event) -> handleGameTouch(event, v.getWidth(), v.getHeight()));
        setContentView(root);
        SystemBarInsets.apply(root);
        main.post(uiTicker);
        gameView.startGame();
        root.setAlpha(0f);
        root.setScaleX(0.985f);
        root.setScaleY(0.985f);
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260)
                .setInterpolator(new DecelerateInterpolator()).start();
    }

    private boolean handleGameTouch(MotionEvent event, int width, int height) {
        if (gameView == null || width <= 0 || height <= 0) return true;
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            downX = event.getX();
            downY = event.getY();
            return true;
        }
        if (event.getAction() == MotionEvent.ACTION_UP) {
            float dx = event.getX() - downX;
            float dy = event.getY() - downY;
            if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > dp(32)) {
                gameView.moveLane(dx < 0 ? -1 : 1);
            } else if (mode.equals("runner") && Math.abs(dy) > dp(32)) {
                if (dy < 0) gameView.jump(); else gameView.slide();
            }
            return true;
        }
        return true;
    }

    @Override protected void onResume() {
        super.onResume();
        if (gameView != null) gameView.startGame();
        main.removeCallbacks(uiTicker);
        main.post(uiTicker);
    }

    @Override protected void onPause() {
        main.removeCallbacks(uiTicker);
        if (gameView != null) gameView.pauseGame();
        super.onPause();
    }

    @Override protected void onDestroy() {
        main.removeCallbacks(uiTicker);
        if (gameView != null) gameView.stopGame();
        gameView = null;
        super.onDestroy();
    }

    @Override public void onBackPressed() { finish(); }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return view;
    }

    private TextView chip(String value, int size, int color) {
        TextView view = label(value, size, color, true);
        view.setGravity(Gravity.CENTER);
        view.setBackground(surface(Color.rgb(22, 21, 20), Color.rgb(137, 99, 35), 14));
        return view;
    }

    private android.graphics.drawable.GradientDrawable surface(int fill, int stroke, int radius) {
        android.graphics.drawable.GradientDrawable drawable = new android.graphics.drawable.GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radius));
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private final class ArcadeCanvasView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final Path path = new Path();
        private final ArrayList<Item> items = new ArrayList<>();
        private final Random random = new Random();
        private long lastFrameNanos;
        private long lastSpawnNanos;
        private long startNanos;
        private float elapsed;
        private float distance;
        private float speed;
        private float jumpRemaining;
        private float slideRemaining;
        private float laneVisual = 1f;
        private int lane = 1;
        private int lives = 3;
        private int coins;
        private int score;
        private boolean running;
        private boolean paused;
        private boolean finished;
        private String scoreLabel = "0 M";
        private String hint;

        ArcadeCanvasView() {
            super(Arcade3DActivity.this);
            setLayerType(View.LAYER_TYPE_HARDWARE, null);
            resetGame();
            setFocusable(true);
        }

        void startGame() {
            if (!finished) {
                running = true;
                paused = false;
                lastFrameNanos = 0L;
                postInvalidateOnAnimation();
            }
        }
        void pauseGame() { running = false; }
        void stopGame() { running = false; }
        boolean isPaused() { return paused; }
        boolean isFinished() { return finished; }
        String getScoreLabel() { return scoreLabel; }
        String getHint() { return hint; }

        boolean togglePause() {
            if (finished) return false;
            paused = !paused;
            lastFrameNanos = 0L;
            if (paused) running = false;
            else startGame();
            invalidate();
            return paused;
        }

        void moveLane(int direction) {
            if (paused || finished) return;
            lane = Math.max(0, Math.min(2, lane + direction));
            hint = mode.equals("runner") ? "DODGE THE BARRIERS · COLLECT THE ORBS" : "KEEP ROLLING · AVOID BLOCKS";
        }
        void jump() { if (!paused && !finished && jumpRemaining <= 0f) { jumpRemaining = 0.72f; slideRemaining = 0f; } }
        void slide() { if (!paused && !finished && slideRemaining <= 0f) { slideRemaining = 0.62f; jumpRemaining = 0f; } }

        void resetGame() {
            items.clear();
            elapsed = 0f;
            distance = 0f;
            speed = mode.equals("runner") ? 7.2f : 5.5f;
            lives = 3;
            coins = 0;
            score = 0;
            lane = 1;
            laneVisual = 1f;
            jumpRemaining = 0f;
            slideRemaining = 0f;
            lastFrameNanos = 0L;
            lastSpawnNanos = 0L;
            finished = false;
            paused = false;
            running = true;
            scoreLabel = mode.equals("runner") ? "0 M" : "0 M  ·  0 ✦";
            hint = mode.equals("runner") ? "SWIPE LEFT / RIGHT · UP TO JUMP · DOWN TO SLIDE" : "SWIPE LEFT / RIGHT TO STEER · COLLECT LIGHT ORBS";
            invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            if (w <= 0f || h <= 0f) return;
            drawWorld(canvas, w, h);
            if (running && !paused && !finished) {
                long now = System.nanoTime();
                float dt = lastFrameNanos == 0L ? 0.016f : Math.min(0.04f, (now - lastFrameNanos) / 1_000_000_000f);
                lastFrameNanos = now;
                update(dt, now);
                postInvalidateOnAnimation();
            }
        }

        private void update(float dt, long now) {
            elapsed += dt;
            distance += speed * dt;
            speed = Math.min(mode.equals("runner") ? 12.8f : 10.2f,
                    (mode.equals("runner") ? 7.2f : 5.5f) + distance / (mode.equals("runner") ? 260f : 310f));
            jumpRemaining = Math.max(0f, jumpRemaining - dt);
            slideRemaining = Math.max(0f, slideRemaining - dt);
            laneVisual += (lane - laneVisual) * Math.min(1f, dt * 12f);
            if (lastSpawnNanos == 0L || now - lastSpawnNanos > (long)(Math.max(580L, 980L - distance * 0.18f) * 1_000_000L)) {
                items.add(new Item(random.nextInt(3), random.nextFloat() > 0.36f));
                lastSpawnNanos = now;
            }
            Iterator<Item> iterator = items.iterator();
            while (iterator.hasNext()) {
                Item item = iterator.next();
                item.depth += dt * speed / 26f;
                if (!item.checked && item.depth >= 0.82f && item.depth <= 0.94f && item.lane == lane) {
                    item.checked = true;
                    if (item.coin) coins++;
                    else if (mode.equals("orb") || (jumpRemaining < 0.15f && slideRemaining < 0.15f)) lives--;
                }
                if (item.depth > 1.16f || (item.checked && item.coin)) iterator.remove();
            }
            score = (int)(distance * (mode.equals("runner") ? 3f : 2.2f)) + coins * (mode.equals("runner") ? 20 : 25);
            scoreLabel = mode.equals("runner") ? ((int)distance) + " M  ·  " + coins + " ✦" : ((int)distance) + " M  ·  " + coins + " ✦";
            if (lives <= 0 || distance >= (mode.equals("runner") ? 1600f : 1250f)) {
                finished = true;
                running = false;
            }
        }

        private void drawWorld(Canvas c, float w, float h) {
            float horizon = h * 0.22f;
            paint.setShader(new LinearGradient(0, 0, 0, h,
                    new int[]{Color.rgb(7, 7, 9), Color.rgb(19, 17, 14), Color.rgb(5, 5, 7)},
                    null, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, paint);
            paint.setShader(null);
            // Soft atmospheric rings above the horizon.
            glow.setColor(Color.argb(42, 255, 198, 48));
            c.drawCircle(w * 0.5f, horizon * 0.68f, w * 0.36f, glow);
            glow.setColor(Color.argb(36, 190, 126, 24));
            c.drawCircle(w * 0.5f, horizon * 0.70f, w * 0.25f, glow);

            path.reset();
            path.moveTo(w * 0.38f, horizon);
            path.lineTo(w * 0.62f, horizon);
            path.lineTo(w * 0.98f, h);
            path.lineTo(w * 0.02f, h);
            path.close();
            paint.setShader(new LinearGradient(0, horizon, 0, h,
                    Color.rgb(31, 23, 10), Color.rgb(78, 53, 15), Shader.TileMode.CLAMP));
            c.drawPath(path, paint);
            paint.setShader(null);
            line.setColor(Color.argb(125, 201, 145, 37));
            line.setStrokeWidth(dp(1));
            c.drawLine(w * 0.38f, horizon, w * 0.02f, h, line);
            c.drawLine(w * 0.62f, horizon, w * 0.98f, h, line);
            for (int i = 1; i <= 2; i++) {
                float xTop = w * (0.38f + i * 0.08f);
                float xBottom = w * (0.02f + i * 0.32f);
                c.drawLine(xTop, horizon, xBottom, h, line);
            }
            // Animated floor markers create a moving depth grid.
            float offset = (distance * 0.11f) % 1f;
            for (int i = 0; i < 11; i++) {
                float t = (i / 11f + offset) % 1f;
                float y = horizon + (h - horizon) * t * t;
                float half = (w * 0.12f) + t * (w * 0.39f);
                line.setColor(Color.argb((int)(35 + t * 90), 190, 132, 30));
                c.drawLine(w * 0.5f - half, y, w * 0.5f + half, y, line);
            }
            drawSideStructures(c, w, h, horizon);
            drawItems(c, w, h, horizon);
            drawPlayer(c, w, h, horizon);
            drawLives(c, w, h);
            if (paused) drawPauseVeil(c, w, h);
            if (finished) drawFinishVeil(c, w, h);
        }

        private void drawSideStructures(Canvas c, float w, float h, float horizon) {
            for (int i = 0; i < 7; i++) {
                float t = ((i / 7f) + (distance * 0.008f)) % 1f;
                float depth = t * t;
                float y = horizon + (h - horizon) * depth;
                float scale = 0.20f + depth * 1.05f;
                drawPrism(c, w * 0.12f - scale * 20f, y, scale * 18f, scale * 70f, Color.rgb(132, 91, 25), Color.rgb(255, 208, 74));
                drawPrism(c, w * 0.88f - scale * 2f, y, scale * 18f, scale * 70f, Color.rgb(132, 91, 25), Color.rgb(255, 208, 74));
            }
        }

        private void drawItems(Canvas c, float w, float h, float horizon) {
            for (Item item : items) {
                float depth = Math.max(0.02f, Math.min(1f, item.depth));
                float perspective = depth * depth;
                float y = horizon + (h * 0.74f - horizon) * depth;
                float laneX = w * (0.30f + item.lane * 0.20f);
                float size = dp(9) + perspective * dp(36);
                float x = laneX + (w * (item.lane - 1) * 0.025f * depth);
                if (item.coin) {
                    glow.setColor(Color.argb(42, 184, 133, 44));
                    c.drawCircle(x, y, size * 1.35f, glow);
                    paint.setShader(new LinearGradient(x - size, y - size, x + size, y + size,
                            Color.rgb(255, 220, 139), Color.rgb(190, 131, 39), Shader.TileMode.CLAMP));
                    c.drawCircle(x, y, size * 0.72f, paint);
                    paint.setShader(null);
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(Math.max(dp(1), size * 0.12f));
                    paint.setColor(Color.rgb(255, 250, 225));
                    c.drawCircle(x, y, size * 0.42f, paint);
                    paint.setStyle(Paint.Style.FILL);
                } else {
                    drawPrism(c, x, y, size * 0.90f, size * 1.10f,
                            mode.equals("runner") ? Color.rgb(159, 94, 23) : Color.rgb(149, 102, 26),
                            mode.equals("runner") ? Color.rgb(255, 219, 103) : Color.rgb(255, 232, 165));
                }
            }
        }

        private void drawPlayer(Canvas c, float w, float h, float horizon) {
            float laneX = w * (0.30f + laneVisual * 0.20f);
            float baseY = h * 0.75f;
            float jump = jumpRemaining > 0f ? (float)Math.sin((0.72f - jumpRemaining) / 0.72f * Math.PI) * h * 0.12f : 0f;
            float height = slideRemaining > 0f ? h * 0.055f : h * 0.105f;
            float width = w * 0.105f;
            float y = baseY - jump;
            glow.setColor(Color.argb(48, 218, 173, 91));
            c.drawOval(laneX - width * 0.95f, baseY + height * 0.46f,
                    laneX + width * 0.95f, baseY + height * 0.72f, glow);
            if (mode.equals("runner")) {
                drawPrism(c, laneX, y, width, height, Color.rgb(112, 75, 19), Color.rgb(255, 199, 48));
                if (slideRemaining <= 0f) {
                    paint.setShader(new LinearGradient(laneX - width / 2, y - height * 0.9f,
                            laneX + width / 2, y - height * 0.2f,
                            Color.rgb(255, 248, 220), Color.rgb(255, 199, 48), Shader.TileMode.CLAMP));
                    c.drawCircle(laneX, y - height * 0.88f, width * 0.46f, paint);
                    paint.setShader(null);
                }
            } else {
                float radius = width * 0.72f;
                glow.setColor(Color.argb(55, 218, 173, 91));
                c.drawCircle(laneX, y - radius * 0.2f, radius * 1.45f, glow);
                paint.setShader(new LinearGradient(laneX - radius, y - radius, laneX + radius, y + radius,
                        new int[]{Color.rgb(255, 248, 220), Color.rgb(255, 199, 48), Color.rgb(190, 126, 24)},
                        null, Shader.TileMode.CLAMP));
                c.drawCircle(laneX, y - radius * 0.35f, radius, paint);
                paint.setShader(null);
                paint.setColor(Color.argb(190, 255, 247, 225));
                c.drawCircle(laneX - radius * 0.28f, y - radius * 0.65f, radius * 0.20f, paint);
            }
        }

        private void drawPrism(Canvas c, float x, float y, float width, float height, int front, int top) {
            float half = width * 0.5f;
            float depth = width * 0.24f;
            float topY = y - height;
            Path frontFace = new Path();
            frontFace.moveTo(x - half, topY + depth);
            frontFace.lineTo(x + half, topY + depth);
            frontFace.lineTo(x + half, y);
            frontFace.lineTo(x - half, y);
            frontFace.close();
            paint.setShader(null);
            paint.setColor(front);
            c.drawPath(frontFace, paint);
            Path topFace = new Path();
            topFace.moveTo(x - half, topY + depth);
            topFace.lineTo(x, topY);
            topFace.lineTo(x + half, topY + depth);
            topFace.lineTo(x, topY + depth * 1.8f);
            topFace.close();
            paint.setColor(top);
            c.drawPath(topFace, paint);
            Path sideFace = new Path();
            sideFace.moveTo(x + half, topY + depth);
            sideFace.lineTo(x, topY + depth * 1.8f);
            sideFace.lineTo(x, y);
            sideFace.lineTo(x + half, y);
            sideFace.close();
            paint.setColor(shade(front, 0.78f));
            c.drawPath(sideFace, paint);
            paint.setColor(Color.argb(45, 39, 57, 74));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(1f, width * 0.025f));
            c.drawPath(frontFace, paint);
            paint.setStyle(Paint.Style.FILL);
        }

        private void drawLives(Canvas c, float w, float h) {
            for (int i = 0; i < lives; i++) {
                paint.setColor(ROSE);
                c.drawCircle(w * 0.5f - dp(15) + i * dp(15), h * 0.12f, dp(4), paint);
            }
        }

        private void drawPauseVeil(Canvas c, float w, float h) {
            paint.setColor(Color.argb(80, 255, 199, 48));
            c.drawRect(0, 0, w, h, paint);
            paint.setColor(INK);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            paint.setTextSize(dp(28));
            c.drawText("PAUSED", w * 0.5f, h * 0.50f, paint);
            paint.setTextAlign(Paint.Align.LEFT);
        }

        private void drawFinishVeil(Canvas c, float w, float h) {
            paint.setColor(Color.argb(100, 255, 199, 48));
            c.drawRect(0, 0, w, h, paint);
            paint.setColor(INK);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            paint.setTextSize(dp(26));
            c.drawText(mode.equals("runner") ? "RUN COMPLETE" : "COURSE COMPLETE", w * 0.5f, h * 0.47f, paint);
            paint.setTextSize(dp(13));
            paint.setColor(MUTED);
            c.drawText("Tap PLAY AGAIN below", w * 0.5f, h * 0.47f + dp(28), paint);
            paint.setTextAlign(Paint.Align.LEFT);
        }

        private int shade(int color, float factor) {
            return Color.rgb(Math.round(Color.red(color) * factor),
                    Math.round(Color.green(color) * factor), Math.round(Color.blue(color) * factor));
        }

        private final class Item {
            final int lane;
            final boolean coin;
            float depth;
            boolean checked;
            Item(int lane, boolean coin) { this.lane = lane; this.coin = coin; }
        }
    }
}
