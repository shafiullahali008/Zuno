package com.nexas.safe;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class PrayerStopReceiver extends BroadcastReceiver {
    public static final String ACTION_STOP = "com.nexas.safe.STOP_AZAN";
    @Override public void onReceive(Context context, Intent intent) {
        context.stopService(new Intent(context, PrayerAzanService.class));
        android.app.NotificationManager manager = (android.app.NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) { manager.cancel(PrayerNotifications.NOTIFICATION_ID); manager.cancel(PrayerNotifications.NOTIFICATION_ID + 1); }
    }
}
