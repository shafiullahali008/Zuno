package com.nexas.safe;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.time.Duration;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.chrono.HijrahChronology;
import java.time.chrono.HijrahDate;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Shia prayer, Azan, Qibla and Hijri calendar companion. */
public class PrayerActivity extends Activity implements SensorEventListener {
    private static final int REQ_LOCATION = 9101;
    private static final int REQ_AUDIO = 9102;
    private static final int REQ_NOTIFICATION = 9103;
    private static final int GOLD = 0xFFFFC832;
    private static final int DARK = 0xFFFFF4D8;
    private static final int MUTED = 0xFFBEAD8B;
    private static final int BG = 0xFF050507;
    private static final int WHITE = 0xFF171719;
    private final android.os.Handler handler = new android.os.Handler();
    private LinearLayout content;
    private TextView locationText, hijriText, nextPrayerText, sehriText, iftarText, streakText, levelText,
            nextEventText, qiblaText, qiblaArrow, methodText, audioText, reminderStatus, midnightText;
    private TextView countdownDays, countdownHours, countdownMinutes, countdownSeconds;
    private PrayerCountdownView countdownView;
    private LinearLayout prayerList, calendarGrid, eventList;
    private int calendarYear, calendarMonth;
    private LocalDate renderedDate;
    private double latitude, longitude;
    private float[] gravityValues, magneticValues;
    private SensorManager sensorManager;
    private Sensor accelerometer, magnetometer;
    private LocationManager pendingLocationManager;
    private LocationListener pendingLocationListener;
    private Runnable locationTimeout;
    private double qiblaBearing;
    private final String[] prayers = {"Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"};
    private Map<String, ZonedDateTime> cachedToday = java.util.Collections.emptyMap();
    private Map<String, ZonedDateTime> cachedTomorrow = java.util.Collections.emptyMap();
    private ZonedDateTime cachedJafariMidnight;
    private String cachedPrayerConfigKey = "";
    private Runnable ticker;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (Build.VERSION.SDK_INT >= 23) getWindow().getDecorView().setSystemUiVisibility(0);
        latitude = PrayerPrefs.latitude(this);
        longitude = PrayerPrefs.longitude(this);
        HijrahDate now = currentHijri();
        calendarYear = now.get(ChronoField.YEAR);
        calendarMonth = now.get(ChronoField.MONTH_OF_YEAR);
        buildPage();
        ensureNotificationPermission();
        PrayerScheduler.scheduleUpcoming(this);
        refreshAll();
        ticker = new Runnable() { @Override public void run() { refreshLive(); handler.postDelayed(this, 1000L); } };
    }

    @Override protected void onResume() {
        super.onResume();
        PrayerScheduler.scheduleUpcoming(this);
        if (ticker != null) { handler.removeCallbacks(ticker); handler.post(ticker); }
        refreshAll();
        registerCompass();
    }

    @Override protected void onPause() {
        handler.removeCallbacks(ticker);
        unregisterCompass();
        super.onPause();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(ticker);
        stopLocationUpdates();
        super.onDestroy();
    }

    private void buildPage() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(18), dp(18), dp(30));
        scroll.addView(content);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = text("‹", 31, DARK, true);
        back.setGravity(Gravity.CENTER);
        top.addView(back, new LinearLayout.LayoutParams(dp(42), dp(46)));
        back.setOnClickListener(v -> finish());
        LinearLayout heading = new LinearLayout(this); heading.setOrientation(LinearLayout.VERTICAL);
        heading.addView(text("ZUNO • ISLAMIC WELLNESS", 9, GOLD, true));
        heading.addView(text("Prayer & Calendar", 23, DARK, true));
        top.addView(heading, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView settings = text("⚙", 22, MUTED, true); settings.setGravity(Gravity.CENTER);
        top.addView(settings, new LinearLayout.LayoutParams(dp(42), dp(42)));
        settings.setOnClickListener(v -> showPrayerSettings());
        content.addView(top, fullWidth(-2));

        LinearLayout dateCard = card();
        dateCard.setBackground(gradient(new int[]{0xFF1B1814, 0xFF33240D}, 22));
        hijriText = text("Loading Hijri date…", 17, WHITE, true);
        dateCard.addView(hijriText);
        locationText = text("Wah Cantt, Pakistan (default location)", 10, 0xFFE8D8B8, false);
        LinearLayout.LayoutParams locp = fullWidth(-2); locp.topMargin = dp(7); dateCard.addView(locationText, locp);
        Button locationButton = smallButton("Use current location / Change");
        LinearLayout.LayoutParams lbp = fullWrap(); lbp.topMargin = dp(12); dateCard.addView(locationButton, lbp);
        locationButton.setOnClickListener(v -> showLocationOptions());
        addCard(dateCard);

        LinearLayout nextCard = card();
        nextCard.setGravity(Gravity.CENTER_HORIZONTAL);
        nextCard.setBackground(gradient(new int[]{0xFF29200F, 0xFF121214}, 22));
        nextPrayerText = text("Next prayer", 12, MUTED, true); nextCard.addView(nextPrayerText);
        countdownView = new PrayerCountdownView(this);
        LinearLayout.LayoutParams dialp = new LinearLayout.LayoutParams(dp(214), dp(214)); dialp.topMargin = dp(9); nextCard.addView(countdownView, dialp);
        TextView note = text("Prayer alarms are scheduled by Android; exact timing needs alarm access", 10, MUTED, false);
        LinearLayout.LayoutParams notep = fullWrap(); notep.topMargin = dp(5); nextCard.addView(note, notep);
        addCard(nextCard);

        section("TODAY'S PRAYER TIMES", "Jafari calculation · daily checklist refreshes at local midnight; history is kept for streaks");
        prayerList = new LinearLayout(this); prayerList.setOrientation(LinearLayout.VERTICAL); content.addView(prayerList);

        LinearLayout fasting = card();
        fasting.addView(text("RAMADAN & DAILY FASTING", 10, GOLD, true));
        sehriText = text("Sehri closes at Fajr · calculating…", 14, DARK, true);
        LinearLayout.LayoutParams slp = fullWidth(-2); slp.topMargin = dp(10); fasting.addView(sehriText, slp);
        iftarText = text("Iftar at Maghrib · calculating…", 14, DARK, true);
        LinearLayout.LayoutParams ilp = fullWidth(-2); ilp.topMargin = dp(8); fasting.addView(iftarText, ilp);
        midnightText = text("Islamic midnight: calculating…", 11, MUTED, false);
        LinearLayout.LayoutParams milp = fullWidth(-2); milp.topMargin = dp(8); fasting.addView(midnightText, milp);
        addCard(fasting);

        LinearLayout progress = card();
        progress.addView(text("PRAYER CONSISTENCY", 10, GOLD, true));
        progress.addView(text("Mark all five prayers manually; a complete day extends your streak", 10, MUTED, false));
        streakText = text("Prayer streak: 0 days", 20, DARK, true);
        LinearLayout.LayoutParams stp = fullWidth(-2); stp.topMargin = dp(7); progress.addView(streakText, stp);
        levelText = text("Level 1 · Begin with today", 11, MUTED, false);
        LinearLayout.LayoutParams levp = fullWidth(-2); levp.topMargin = dp(5); progress.addView(levelText, levp);
        addCard(progress);

        section("QIBLA DIRECTION", "Compass uses your device sensors when available");
        LinearLayout qibla = card(); qibla.setGravity(Gravity.CENTER_HORIZONTAL);
        qiblaArrow = text("↑", 52, GOLD, true); qiblaArrow.setGravity(Gravity.CENTER);
        qibla.addView(qiblaArrow, fullWidth(dp(74)));
        qiblaText = text("Bearing to Kaaba: —", 15, DARK, true);
        LinearLayout.LayoutParams qtp = fullWrap(); qtp.topMargin = dp(5); qibla.addView(qiblaText, qtp);
        addCard(qibla);

        section("SHIA ISLAMIC CALENDAR", "Hijri date is an astronomical calendar estimate; adjust for local moon sighting");
        LinearLayout calCard = card();
        LinearLayout calHead = new LinearLayout(this); calHead.setGravity(Gravity.CENTER_VERTICAL);
        Button prev = smallButton("‹"); Button next = smallButton("›");
        TextView calTitle = text(hijriMonthName(calendarMonth) + " " + calendarYear, 14, DARK, true); calTitle.setGravity(Gravity.CENTER);
        calHead.addView(prev, new LinearLayout.LayoutParams(dp(48), dp(40)));
        calHead.addView(calTitle, new LinearLayout.LayoutParams(0, dp(40), 1f));
        calHead.addView(next, new LinearLayout.LayoutParams(dp(48), dp(40)));
        calCard.addView(calHead);
        prev.setOnClickListener(v -> shiftCalendar(-1, calTitle));
        next.setOnClickListener(v -> shiftCalendar(1, calTitle));
        calendarGrid = new LinearLayout(this); calendarGrid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams cgp = fullWidth(-2); cgp.topMargin = dp(10); calCard.addView(calendarGrid, cgp);
        LinearLayout calActions = new LinearLayout(this); calActions.setGravity(Gravity.CENTER_VERTICAL);
        Button adjustHijri = smallButton("Adjust Hijri date");
        Button custom = smallButton("Set personal countdown");
        calActions.addView(adjustHijri, new LinearLayout.LayoutParams(0, dp(42), 1f));
        calActions.addView(custom, new LinearLayout.LayoutParams(0, dp(42), 1f));
        LinearLayout.LayoutParams cap = fullWidth(-2); cap.topMargin = dp(12); calCard.addView(calActions, cap);
        adjustHijri.setOnClickListener(v -> chooseHijriOffset());
        custom.setOnClickListener(v -> chooseCustomCountdown());
        addCard(calCard);

        LinearLayout events = card(); events.addView(text("UPCOMING SHIA OCCASIONS", 10, GOLD, true));
        nextEventText = text("Finding next occasion…", 14, DARK, true);
        LinearLayout.LayoutParams nep = fullWidth(-2); nep.topMargin = dp(8); events.addView(nextEventText, nep);
        eventList = new LinearLayout(this); eventList.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams elp = fullWidth(-2); elp.topMargin = dp(7); events.addView(eventList, elp);
        addCard(events);

        LinearLayout waqiatCard = card();
        waqiatCard.addView(text("AHAM ISLAMIC WAQIAAT", 10, GOLD, true));
        TextView waqiatDesc = text("Read curated accounts from classical Twelver Shia sources, with book references and historical-source notes.", 12, MUTED, false);
        LinearLayout.LayoutParams wdp = fullWidth(-2); wdp.topMargin = dp(7); waqiatCard.addView(waqiatDesc, wdp);
        Button openWaqiat = smallButton("OPEN ISLAMIC WAQIAAT LIBRARY");
        LinearLayout.LayoutParams wbp = fullWidth(-2); wbp.topMargin = dp(11); waqiatCard.addView(openWaqiat, wbp);
        openWaqiat.setOnClickListener(v -> startActivity(new Intent(this, WaqiatActivity.class)));
        addCard(waqiatCard);

        section("AZAN & NOTIFICATIONS", "Your uploaded audio is the default Azan and can be replaced anytime");
        LinearLayout audio = card();
        Switch master = new Switch(this); master.setText("Automatic Azan at prayer times"); master.setTextColor(DARK); master.setTextSize(14);
        master.setShowText(true);
        master.setThumbTintList(new android.content.res.ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{GOLD, Color.rgb(155, 148, 136)}));
        master.setTrackTintList(new android.content.res.ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{0x887D5A20, 0x557A746A}));
        master.setChecked(PrayerPrefs.azanEnabled(this)); audio.addView(master);
        master.setOnCheckedChangeListener((button, checked) -> {
            PrayerPrefs.get(this).edit().putBoolean(PrayerPrefs.AZAN_ENABLED, checked).apply();
            PrayerScheduler.scheduleUpcoming(this); updateAudioStatus();
        });
        audioText = text("Current audio: uploaded Azan", 11, MUTED, false);
        LinearLayout.LayoutParams atp = fullWidth(-2); atp.topMargin = dp(8); audio.addView(audioText, atp);
        LinearLayout audioActions = new LinearLayout(this); audioActions.setGravity(Gravity.CENTER_VERTICAL);
        Button upload = smallButton("Upload / Change Azan"); Button preview = smallButton("Preview"); Button stop = smallButton("Stop");
        audioActions.addView(upload, new LinearLayout.LayoutParams(0, dp(43), 1.2f));
        audioActions.addView(preview, new LinearLayout.LayoutParams(0, dp(43), 0.9f));
        audioActions.addView(stop, new LinearLayout.LayoutParams(0, dp(43), 0.6f));
        LinearLayout.LayoutParams aap = fullWidth(-2); aap.topMargin = dp(10); audio.addView(audioActions, aap);
        upload.setOnClickListener(v -> openAudioPicker());
        preview.setOnClickListener(v -> previewAzan());
        stop.setOnClickListener(v -> stopAzanPlayback());
        Button restore = smallButton("Restore uploaded default Azan");
        LinearLayout.LayoutParams rlp = fullWidth(dp(42)); rlp.topMargin = dp(8); audio.addView(restore, rlp);
        restore.setOnClickListener(v -> { PrayerPrefs.get(this).edit().remove(PrayerPrefs.AUDIO_PATH).apply(); updateAudioStatus(); toast("Bundled Azan restored"); });
        reminderStatus = text("Checking Android alarm and notification access…", 10, MUTED, false);
        LinearLayout.LayoutParams rsp = fullWidth(-2); rsp.topMargin = dp(10); audio.addView(reminderStatus, rsp);
        LinearLayout permissionActions = new LinearLayout(this); permissionActions.setGravity(Gravity.CENTER_VERTICAL);
        Button exactAlarm = smallButton("Exact alarms"); Button notificationSettings = smallButton("Notifications");
        permissionActions.addView(exactAlarm, new LinearLayout.LayoutParams(0, dp(43), 1f));
        permissionActions.addView(notificationSettings, new LinearLayout.LayoutParams(0, dp(43), 1f));
        LinearLayout.LayoutParams eap = fullWidth(dp(43)); eap.topMargin = dp(8); audio.addView(permissionActions, eap);
        exactAlarm.setOnClickListener(v -> openExactAlarmSettings());
        notificationSettings.setOnClickListener(v -> openNotificationSettings());
        addCard(audio);

        section("PRAYER CALCULATION", "Shia presets and manual precaution adjustments");
        LinearLayout calc = card();
        methodText = text("Jafari (Qom): Fajr 16° · Maghrib 4° · Isha 14° · Asr shadow 1", 12, DARK, true);
        calc.addView(methodText);
        Button method = smallButton("Choose Shia calculation preset");
        LinearLayout.LayoutParams mp = fullWidth(dp(43)); mp.topMargin = dp(10); calc.addView(method, mp);
        method.setOnClickListener(v -> chooseMethod());
        Button adjust = smallButton("Adjust prayer times (minutes)");
        LinearLayout.LayoutParams ap = fullWidth(dp(43)); ap.topMargin = dp(7); calc.addView(adjust, ap);
        adjust.setOnClickListener(v -> chooseOffsets());
        addCard(calc);

        TextView disclaimer = text("Calculation note: Jafari/Qom angles are used by default. Local Shia authorities and Marja timetables may differ, especially for Maghrib and moon-sighting dates. Compare with your trusted local mosque/Marja timetable and use the minute adjustments where needed. The app does not issue religious rulings.", 10, MUTED, false);
        disclaimer.setLineSpacing(dp(3), 1.0f);
        LinearLayout.LayoutParams dpv = fullWidth(-2); dpv.topMargin = dp(10); content.addView(disclaimer, dpv);
        setContentView(scroll);
        SystemBarInsets.apply(scroll);
    }

    private void refreshAll() {
        latitude = PrayerPrefs.latitude(this); longitude = PrayerPrefs.longitude(this);
        refreshPrayerCache();
        updateHijriHeader();
        if (locationText != null) locationText.setText(PrayerPrefs.location(this));
        updatePrayerList(); updateLiveCountdown(); updateProgress(); updateQibla(); updateCalendar(); updateEvents(); updateAudioStatus(); updateMethodLabel();
    }

    private void refreshLive() {
        if (isFinishing()) return;
        refreshPrayerCache();
        if (renderedDate == null || !renderedDate.equals(LocalDate.now())) {
            PrayerScheduler.scheduleUpcoming(this);
            refreshAll();
            return;
        }
        updateHijriHeader();
        updateLiveCountdown(); updateFastingCountdowns();
    }

    private void updateHijriHeader() {
        if (hijriText == null) return;
        HijrahDate h = currentHijri();
        hijriText.setText(h.get(ChronoField.DAY_OF_MONTH) + " " + hijriMonthName(h.get(ChronoField.MONTH_OF_YEAR))
                + " " + h.get(ChronoField.YEAR) + " AH");
    }

    private HijrahDate currentHijri() {
        int offset = PrayerPrefs.get(this).getInt(PrayerPrefs.HIJRI_OFFSET, 0);
        return HijrahDate.from(LocalDate.now().plusDays(offset));
    }

    private void updatePrayerList() {
        if (prayerList == null) return;
        renderedDate = LocalDate.now();
        prayerList.removeAllViews();
        Map<String, ZonedDateTime> times = cachedToday;
        for (String prayer : prayers) {
            LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(13), dp(11), dp(10), dp(11));
            row.setBackground(round(WHITE, 15, 0xFF9B7024));
            LinearLayout left = new LinearLayout(this); left.setOrientation(LinearLayout.VERTICAL);
            left.addView(text(prayer, 14, DARK, true));
            TextView time = text(formatTime(times.get(prayer)), 11, MUTED, false);
            LinearLayout.LayoutParams tlp = fullWrap(); tlp.topMargin = dp(3); left.addView(time, tlp);
            row.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
            CheckBox done = new CheckBox(this); done.setText("Prayed"); done.setTextColor(MUTED); done.setTextSize(10);
            String today = LocalDate.now().toString();
            done.setChecked(PrayerPrefs.get(this).getBoolean(PrayerPrefs.doneKey(today, prayer), false));
            done.setOnCheckedChangeListener((button, checked) -> {
                PrayerPrefs.get(this).edit().putBoolean(PrayerPrefs.doneKey(today, prayer), checked).apply(); updateProgress();
            });
            row.addView(done);
            CheckBox azan = new CheckBox(this); azan.setText("Azan"); azan.setTextColor(MUTED); azan.setTextSize(10);
            azan.setChecked(PrayerPrefs.get(this).getBoolean("azan_" + prayer.toLowerCase(Locale.ROOT), true));
            azan.setOnCheckedChangeListener((button, checked) -> {
                PrayerPrefs.get(this).edit().putBoolean("azan_" + prayer.toLowerCase(Locale.ROOT), checked).apply(); PrayerScheduler.scheduleUpcoming(this);
            });
            row.addView(azan);
            LinearLayout.LayoutParams rp = fullWidth(-2); rp.topMargin = dp(6); prayerList.addView(row, rp);
            if ("Fajr".equals(prayer)) {
                TextView sunrise = text("Sunrise (not a prayer)  ·  " + formatTime(times.get("Sunrise")), 10, MUTED, false);
                LinearLayout.LayoutParams sunriseLp = fullWidth(-2); sunriseLp.leftMargin = dp(14); sunriseLp.topMargin = dp(4);
                prayerList.addView(sunrise, sunriseLp);
            }
        }
    }

    private void updateLiveCountdown() {
        if (countdownView == null) return;
        ZonedDateTime now = ZonedDateTime.now();
        NextPrayer next = findNextPrayer(now);
        Duration duration = Duration.between(now, next.at);
        long seconds = Math.max(0L, duration.getSeconds());
        countdownView.setRemaining(seconds, next.name);
        nextPrayerText.setText("NEXT PRAYER  ·  " + next.name.toUpperCase(Locale.ROOT) + "  ·  " + formatTime(next.at));
        updateFastingCountdowns();
    }

    private void updateFastingCountdowns() {
        if (sehriText == null) return;
        ZonedDateTime now = ZonedDateTime.now();
        ZonedDateTime fajr = nearestFuturePrayer("Fajr", now);
        ZonedDateTime maghrib = nearestFuturePrayer("Maghrib", now);
        sehriText.setText("SEHRI CLOSES IN  ·  " + compactDuration(Duration.between(now, fajr)) + "  ·  " + formatTime(fajr));
        iftarText.setText("IFTAR IN  ·  " + compactDuration(Duration.between(now, maghrib)) + "  ·  " + formatTime(maghrib));
        if (cachedJafariMidnight != null) {
            midnightText.setText("Jafari Islamic midnight (approx.): " + formatTime(cachedJafariMidnight));
        } else {
            midnightText.setText("Islamic midnight: unavailable for this date/location");
        }
        HijrahDate h = currentHijri();
        boolean ramadan = h.get(ChronoField.MONTH_OF_YEAR) == 9;
        if (!ramadan) {
            sehriText.setText("NEXT FAJR IN  ·  " + compactDuration(Duration.between(now, fajr)) + "  ·  " + formatTime(fajr));
            iftarText.setText("NEXT MAGHRIB IN  ·  " + compactDuration(Duration.between(now, maghrib)) + "  ·  " + formatTime(maghrib));
        }
    }

    private NextPrayer findNextPrayer(ZonedDateTime now) {
        for (String name : prayers) {
            ZonedDateTime time = cachedToday.get(name);
            if (time != null && time.isAfter(now)) return new NextPrayer(name, time);
        }
        for (String name : prayers) {
            ZonedDateTime time = cachedTomorrow.get(name);
            if (time != null && time.isAfter(now)) return new NextPrayer(name, time);
        }
        ZonedDateTime tomorrowFajr = cachedTomorrow.get("Fajr");
        return new NextPrayer("Fajr", tomorrowFajr != null ? tomorrowFajr : now.plusHours(1));
    }

    private ZonedDateTime nearestFuturePrayer(String name, ZonedDateTime now) {
        ZonedDateTime today = cachedToday.get(name);
        if (today != null && today.isAfter(now)) return today;
        ZonedDateTime tomorrow = cachedTomorrow.get(name);
        return tomorrow != null ? tomorrow : now.plusHours(1);
    }

    private void refreshPrayerCache() {
        LocalDate today = LocalDate.now();
        ZoneId zone = ZoneId.systemDefault();
        ShiaPrayerCalculator.Method method = PrayerPrefs.method(this);
        int[] offsets = PrayerPrefs.offsets(this);
        String key = today + "|" + zone.getId() + "|" + latitude + "|" + longitude + "|"
                + method.name() + "|" + java.util.Arrays.toString(offsets);
        if (key.equals(cachedPrayerConfigKey)) return;
        cachedToday = ShiaPrayerCalculator.calculate(today, latitude, longitude, zone, method, offsets);
        cachedTomorrow = ShiaPrayerCalculator.calculate(today.plusDays(1), latitude, longitude, zone, method, offsets);
        ZonedDateTime maghrib = cachedToday.get("Maghrib");
        ZonedDateTime nextFajr = cachedTomorrow.get("Fajr");
        if (maghrib != null && nextFajr != null && nextFajr.isAfter(maghrib)) {
            cachedJafariMidnight = maghrib.plusSeconds(Duration.between(maghrib, nextFajr).getSeconds() / 2L);
        } else {
            cachedJafariMidnight = null;
        }
        cachedPrayerConfigKey = key;
    }

    private void updateProgress() {
        if (streakText == null) return;
        String today = LocalDate.now().toString();
        int completed = 0;
        for (String p : prayers) if (PrayerPrefs.get(this).getBoolean(PrayerPrefs.doneKey(today, p), false)) completed++;
        int streak = calculatePrayerStreak();
        int level = prayerLevel(streak);
        int next = nextPrayerLevel(streak);
        streakText.setText("" + streak + "-day prayer streak  ·  " + completed + "/5 today");
        levelText.setText("Level " + level + "  ·  " + (next > streak ? (next - streak) + " days to the next level" : "Top milestone reached"));
    }

    private int calculatePrayerStreak() {
        int streak = 0; LocalDate date = LocalDate.now();
        if (!isDayComplete(date)) date = date.minusDays(1);
        for (int i = 0; i < 1500; i++, date = date.minusDays(1)) {
            if (!isDayComplete(date)) break;
            streak++;
        }
        return streak;
    }

    private boolean isDayComplete(LocalDate date) {
        String keyDate = date.toString();
        for (String p : prayers) if (!PrayerPrefs.get(this).getBoolean(PrayerPrefs.doneKey(keyDate, p), false)) return false;
        return true;
    }

    private int prayerLevel(int streak) {
        int[] levels = {0, 1, 7, 14, 30, 40, 90, 180, 365, 1000};
        int level = 1; for (int i = 1; i < levels.length; i++) if (streak >= levels[i]) level = i + 1; else break;
        return level;
    }

    private int nextPrayerLevel(int streak) {
        int[] levels = {1, 7, 14, 30, 40, 90, 180, 365, 1000};
        for (int level : levels) if (streak < level) return level;
        return streak;
    }

    private void updateQibla() {
        if (qiblaText == null) return;
        qiblaBearing = bearingToKaaba(latitude, longitude);
        qiblaText.setText(String.format(Locale.getDefault(), "Kaaba bearing: %.1f° from true north", qiblaBearing));
        if (gravityValues == null || magneticValues == null) qiblaArrow.setRotation((float) qiblaBearing);
    }

    private static double bearingToKaaba(double lat, double lon) {
        double lat1 = Math.toRadians(lat), lat2 = Math.toRadians(21.4225), dLon = Math.toRadians(39.8262 - lon);
        double y = Math.sin(dLon) * Math.cos(lat2);
        double x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
        return (Math.toDegrees(Math.atan2(y, x)) + 360.0) % 360.0;
    }

    private void registerCompass() {
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sensorManager == null) return;
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        if (accelerometer != null) sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI);
        if (magnetometer != null) sensorManager.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_UI);
    }
    private void unregisterCompass() { if (sensorManager != null) sensorManager.unregisterListener(this); }
    @Override public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) gravityValues = event.values.clone();
        if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) magneticValues = event.values.clone();
        if (gravityValues == null || magneticValues == null || qiblaArrow == null) return;
        float[] rotation = new float[9], orientation = new float[3];
        if (SensorManager.getRotationMatrix(rotation, null, gravityValues, magneticValues)) {
            SensorManager.getOrientation(rotation, orientation);
            float azimuth = (float) Math.toDegrees(orientation[0]);
            android.hardware.GeomagneticField field = new android.hardware.GeomagneticField((float) latitude, (float) longitude,
                    (float) 0.0, System.currentTimeMillis());
            float trueHeading = azimuth + field.getDeclination();
            qiblaArrow.setRotation((float) (qiblaBearing - trueHeading));
        }
    }
    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    private void updateCalendar() {
        if (calendarGrid == null) return;
        calendarGrid.removeAllViews();
        String[] weekdays = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
        GridLayout header = new GridLayout(this); header.setColumnCount(7);
        for (String day : weekdays) { TextView v = text(day, 9, MUTED, true); v.setGravity(Gravity.CENTER); header.addView(v, new GridLayout.LayoutParams()); }
        calendarGrid.addView(header, fullWidth(-2));
        HijrahDate first = HijrahChronology.INSTANCE.date(calendarYear, calendarMonth, 1);
        int length = first.lengthOfMonth();
        LocalDate firstGregorian = LocalDate.ofEpochDay(first.toEpochDay() - PrayerPrefs.get(this).getInt(PrayerPrefs.HIJRI_OFFSET, 0));
        int start = firstGregorian.getDayOfWeek().getValue() % 7;
        GridLayout grid = new GridLayout(this); grid.setColumnCount(7);
        for (int i = 0; i < start; i++) grid.addView(calendarDay("", false), cellParams());
        for (int day = 1; day <= length; day++) {
            LocalDate gregorian = LocalDate.ofEpochDay(first.toEpochDay() + day - 1 - PrayerPrefs.get(this).getInt(PrayerPrefs.HIJRI_OFFSET, 0));
            boolean current = gregorian.equals(LocalDate.now());
            grid.addView(calendarDay(String.valueOf(day), current), cellParams());
        }
        calendarGrid.addView(grid, fullWidth(-2));
        TextView monthCaption = text(hijriMonthName(calendarMonth) + " " + calendarYear + " AH", 10, MUTED, false);
        monthCaption.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams mcp = fullWidth(-2); mcp.topMargin = dp(7); calendarGrid.addView(monthCaption, mcp);
    }

    private TextView calendarDay(String label, boolean current) {
        TextView day = text(label, 11, current ? WHITE : DARK, current);
        day.setGravity(Gravity.CENTER);
        day.setBackground(current ? round(GOLD, 9, GOLD) : round(Color.TRANSPARENT, 9, Color.TRANSPARENT));
        return day;
    }

    private GridLayout.LayoutParams cellParams() {
        GridLayout.LayoutParams p = new GridLayout.LayoutParams();
        p.width = getResources().getDisplayMetrics().widthPixels / 7 - dp(7);
        p.height = dp(37); p.setMargins(dp(1), dp(2), dp(1), dp(2));
        return p;
    }

    private void shiftCalendar(int delta, TextView title) {
        try {
            HijrahDate selected = HijrahChronology.INSTANCE.date(calendarYear, calendarMonth, 1).plus(delta, ChronoUnit.MONTHS);
            calendarYear = selected.get(ChronoField.YEAR); calendarMonth = selected.get(ChronoField.MONTH_OF_YEAR);
            title.setText(hijriMonthName(calendarMonth) + " " + calendarYear);
            updateCalendar();
        } catch (RuntimeException ex) { toast("Calendar range unavailable on this device"); }
    }

    private void updateEvents() {
        if (eventList == null) return;
        eventList.removeAllViews();
        List<IslamicEvent> events = upcomingEvents(PrayerPrefs.get(this).getInt(PrayerPrefs.HIJRI_OFFSET, 0));
        if (events.isEmpty()) { nextEventText.setText("No upcoming event found"); return; }
        IslamicEvent first = events.get(0);
        nextEventText.setText(first.name + " · in " + ChronoUnit.DAYS.between(LocalDate.now(), first.date) + " days");
        for (int i = 0; i < Math.min(8, events.size()); i++) {
            IslamicEvent event = events.get(i);
            TextView line = text(event.name + "  ·  " + event.date + "  ·  " + ChronoUnit.DAYS.between(LocalDate.now(), event.date) + "d", 11, MUTED, false);
            LinearLayout.LayoutParams lp = fullWidth(-2); lp.topMargin = dp(6); eventList.addView(line, lp);
        }
        String customName = PrayerPrefs.get(this).getString("custom_countdown_name", "");
        long customAt = PrayerPrefs.get(this).getLong("custom_countdown_at", 0L);
        if (!customName.isEmpty() && customAt > System.currentTimeMillis()) {
            TextView custom = text("Personal: " + customName + " · " + ChronoUnit.DAYS.between(LocalDate.now(),
                    java.time.Instant.ofEpochMilli(customAt).atZone(ZoneId.systemDefault()).toLocalDate()) + " days", 11, GOLD, true);
            LinearLayout.LayoutParams lp = fullWidth(-2); lp.topMargin = dp(8); eventList.addView(custom, lp);
        }
    }

    private List<IslamicEvent> upcomingEvents(int offset) {
        List<IslamicEvent> list = new ArrayList<>();
        HijrahDate now = currentHijri(); int year = now.get(ChronoField.YEAR);
        for (int hy = year; hy <= year + 1; hy++) {
            addEvent(list, hy, 1, 1, "Islamic New Year", offset);
            addEvent(list, hy, 1, 10, "Ashura", offset);
            addEvent(list, hy, 2, 20, "Arbaeen", offset);
            addEvent(list, hy, 3, 17, "Mawlid al-Nabi (Shia date)", offset);
            addEvent(list, hy, 7, 13, "Birth of Imam Ali (a)", offset);
            addEvent(list, hy, 8, 15, "Mid-Sha'ban", offset);
            addEvent(list, hy, 9, 1, "First day of Ramadan", offset);
            addEvent(list, hy, 9, 19, "Laylat al-Qadr (19 Ramadan)", offset);
            addEvent(list, hy, 9, 21, "Laylat al-Qadr (21 Ramadan)", offset);
            addEvent(list, hy, 9, 23, "Laylat al-Qadr (23 Ramadan)", offset);
            addEvent(list, hy, 10, 1, "Eid al-Fitr", offset);
            addEvent(list, hy, 12, 10, "Eid al-Adha", offset);
            addEvent(list, hy, 12, 18, "Eid al-Ghadir", offset);
        }
        list.sort(Comparator.comparing(e -> e.date));
        return list;
    }

    private void addEvent(List<IslamicEvent> list, int year, int month, int day, String name, int offset) {
        try {
            HijrahDate h = HijrahChronology.INSTANCE.date(year, month, day);
            LocalDate gregorian = LocalDate.ofEpochDay(h.toEpochDay() - offset);
            if (!gregorian.isBefore(LocalDate.now())) list.add(new IslamicEvent(name, gregorian));
        } catch (RuntimeException ignored) { }
    }

    private Map<String, ZonedDateTime> timesFor(LocalDate date) {
        return ShiaPrayerCalculator.calculate(date, latitude, longitude, ZoneId.systemDefault(),
                PrayerPrefs.method(this), PrayerPrefs.offsets(this));
    }

    private void showPrayerSettings() {
        String[] items = {"Prayer location", "Shia calculation preset", "Prayer time adjustments", "Hijri date adjustment", "Exact alarm access"};
        new AlertDialog.Builder(this).setTitle("Prayer settings").setItems(items, (dialog, which) -> {
            if (which == 0) showLocationOptions();
            else if (which == 1) chooseMethod();
            else if (which == 2) chooseOffsets();
            else if (which == 3) chooseHijriOffset();
            else openExactAlarmSettings();
        }).show();
    }

    private void showLocationOptions() {
        String[] options = {"Use current device location", "Enter coordinates manually", "Use Wah Cantt default"};
        new AlertDialog.Builder(this).setTitle("Prayer location").setItems(options, (dialog, which) -> {
            if (which == 0) requestCurrentLocation();
            else if (which == 1) manualLocationDialog();
            else {
                PrayerPrefs.get(this).edit().putFloat(PrayerPrefs.LAT, 33.7995f).putFloat(PrayerPrefs.LON, 72.7221f)
                        .putString(PrayerPrefs.LOCATION, "Wah Cantt, Pakistan (approximate default)").apply();
                locationUpdated();
            }
        }).show();
    }

    private void requestCurrentLocation() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION); return;
        }
        try {
            LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            if (lm == null) { toast("Location service is unavailable"); return; }
            Location best = null;
            for (String provider : lm.getProviders(true)) {
                try {
                    Location candidate = lm.getLastKnownLocation(provider);
                    if (candidate != null && (best == null || candidate.getTime() > best.getTime())) best = candidate;
                } catch (SecurityException ignored) { }
            }
            if (best != null && System.currentTimeMillis() - best.getTime() < 2L * 60L * 60L * 1000L) {
                saveLocation(best.getLatitude(), best.getLongitude(), "Last known device location");
                return;
            }
            stopLocationUpdates();
            pendingLocationManager = lm;
            pendingLocationListener = new LocationListener() {
                @Override public void onLocationChanged(Location location) {
                    if (location != null) {
                        stopLocationUpdates();
                        saveLocation(location.getLatitude(), location.getLongitude(), "Current device location");
                    }
                }
                @Override public void onProviderEnabled(String provider) { }
                @Override public void onProviderDisabled(String provider) { }
                @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
            };
            boolean requested = false;
            for (String provider : new String[]{LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER}) {
                try {
                    if (lm.isProviderEnabled(provider)) {
                        lm.requestLocationUpdates(provider, 1000L, 0f, pendingLocationListener, android.os.Looper.getMainLooper());
                        requested = true;
                    }
                } catch (SecurityException | IllegalArgumentException ignored) { }
            }
            if (requested) {
                toast("Getting a fresh location… keep location services enabled");
                locationTimeout = () -> { stopLocationUpdates(); toast("Location fix timed out. You can enter coordinates manually."); };
                handler.postDelayed(locationTimeout, 30000L);
            } else {
                stopLocationUpdates();
                toast("No location provider is enabled. Enter coordinates manually.");
            }
        } catch (SecurityException ex) { toast("Location permission is required"); }
    }

    private void stopLocationUpdates() {
        if (locationTimeout != null) { handler.removeCallbacks(locationTimeout); locationTimeout = null; }
        if (pendingLocationManager != null && pendingLocationListener != null) {
            try { pendingLocationManager.removeUpdates(pendingLocationListener); } catch (SecurityException ignored) { }
        }
        pendingLocationManager = null; pendingLocationListener = null;
    }

    private void manualLocationDialog() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18), dp(10), dp(18), dp(4));
        EditText lat = edit(String.valueOf(latitude), "Latitude (−90 to 90)");
        EditText lon = edit(String.valueOf(longitude), "Longitude (−180 to 180)");
        box.addView(lat); box.addView(lon);
        new AlertDialog.Builder(this).setTitle("Set prayer location").setView(box)
                .setNegativeButton("Cancel", null).setPositiveButton("Save", (d, w) -> {
                    try {
                        double la = Double.parseDouble(lat.getText().toString().trim());
                        double lo = Double.parseDouble(lon.getText().toString().trim());
                        if (la < -90 || la > 90 || lo < -180 || lo > 180) throw new NumberFormatException();
                        saveLocation(la, lo, "Manual coordinates");
                    } catch (Exception ex) { toast("Enter valid latitude and longitude"); }
                }).show();
    }

    private void saveLocation(double lat, double lon, String label) {
        PrayerPrefs.get(this).edit().putFloat(PrayerPrefs.LAT, (float) lat).putFloat(PrayerPrefs.LON, (float) lon)
                .putString(PrayerPrefs.LOCATION, label + String.format(Locale.getDefault(), " (%.4f, %.4f)", lat, lon)).apply();
        locationUpdated(); toast("Prayer location updated");
    }

    private void locationUpdated() { latitude = PrayerPrefs.latitude(this); longitude = PrayerPrefs.longitude(this); PrayerScheduler.scheduleUpcoming(this); refreshAll(); }

    private void chooseMethod() {
        ShiaPrayerCalculator.Method[] methods = ShiaPrayerCalculator.Method.values();
        String[] labels = new String[methods.length];
        for (int i = 0; i < methods.length; i++) labels[i] = methods[i].title;
        int selected = PrayerPrefs.method(this).ordinal();
        new AlertDialog.Builder(this).setTitle("Shia calculation preset").setSingleChoiceItems(labels, selected, (d, which) -> {
            PrayerPrefs.get(this).edit().putString(PrayerPrefs.METHOD, methods[which].name()).apply();
            d.dismiss(); PrayerScheduler.scheduleUpcoming(this); refreshAll();
        }).setNegativeButton("Cancel", null).show();
    }

    private void chooseOffsets() {
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(18), dp(8), dp(18), 0);
        String[] names = {"Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha"};
        int[] values = PrayerPrefs.offsets(this); EditText[] inputs = new EditText[names.length];
        for (int i = 0; i < names.length; i++) {
            TextView label = text(names[i] + " adjustment (−30 to +30 min)", 11, DARK, true); panel.addView(label);
            inputs[i] = edit(String.valueOf(values[i]), "Minutes"); panel.addView(inputs[i]);
        }
        new AlertDialog.Builder(this).setTitle("Prayer time adjustments").setView(panel)
                .setNegativeButton("Cancel", null).setPositiveButton("Save", (d, w) -> {
                    int[] offsets = new int[6];
                    try {
                        for (int i = 0; i < 6; i++) { offsets[i] = Integer.parseInt(inputs[i].getText().toString().trim()); if (offsets[i] < -30 || offsets[i] > 30) throw new NumberFormatException(); }
                        android.content.SharedPreferences.Editor e = PrayerPrefs.get(this).edit();
                        for (int i = 0; i < 6; i++) e.putInt(PrayerPrefs.OFFSET_KEYS[i], offsets[i]);
                        e.apply(); PrayerScheduler.scheduleUpcoming(this); refreshAll();
                    } catch (Exception ex) { toast("Each adjustment must be between −30 and +30 minutes"); }
                }).show();
    }

    private void chooseHijriOffset() {
        String[] options = {"−2 days", "−1 day", "0 days", "+1 day", "+2 days"};
        int current = PrayerPrefs.get(this).getInt(PrayerPrefs.HIJRI_OFFSET, 0);
        new AlertDialog.Builder(this).setTitle("Local moon-sighting adjustment").setSingleChoiceItems(options, current + 2, (d, which) -> {
            PrayerPrefs.get(this).edit().putInt(PrayerPrefs.HIJRI_OFFSET, which - 2).apply();
            HijrahDate h = currentHijri(); calendarYear = h.get(ChronoField.YEAR); calendarMonth = h.get(ChronoField.MONTH_OF_YEAR);
            d.dismiss(); refreshAll();
        }).setNegativeButton("Cancel", null).show();
    }

    private void chooseCustomCountdown() {
        Calendar now = Calendar.getInstance();
        EditText name = new EditText(this);
        name.setText("Personal event"); name.setHint("Countdown name"); name.setSingleLine(true);
        name.setTextSize(13); name.setTextColor(DARK); name.setHintTextColor(MUTED);
        new DatePickerDialog(this, (view, year, month, day) -> {
            Calendar picked = Calendar.getInstance(); picked.clear(); picked.set(year, month, day, 0, 0, 0);
            if (picked.getTimeInMillis() <= System.currentTimeMillis()) { toast("Choose a future date"); return; }
            new AlertDialog.Builder(this).setTitle("Countdown name").setView(name)
                    .setNegativeButton("Cancel", null).setPositiveButton("Save", (d, w) -> {
                        String event = name.getText().toString().trim(); if (event.isEmpty()) event = "My event";
                        PrayerPrefs.get(this).edit().putString("custom_countdown_name", event)
                                .putLong("custom_countdown_at", picked.getTimeInMillis()).apply(); updateEvents();
                    }).show();
        }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void openAudioPicker() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE); pick.setType("audio/*");
        startActivityForResult(pick, REQ_AUDIO);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_AUDIO && resultCode == RESULT_OK && data != null && data.getData() != null) copySelectedAudio(data.getData());
    }

    private void copySelectedAudio(android.net.Uri uri) {
        File target = new File(getFilesDir(), "user_azan_audio");
        File temp = new File(getFilesDir(), "user_azan_audio.tmp");
        try (InputStream in = getContentResolver().openInputStream(uri); FileOutputStream out = new FileOutputStream(temp)) {
            if (in == null) throw new IllegalStateException("Unable to read selected audio");
            byte[] buffer = new byte[8192]; int read; long total = 0;
            while ((read = in.read(buffer)) != -1) {
                total += read; if (total > 35L * 1024L * 1024L) throw new IllegalArgumentException("Audio file is larger than 35 MB");
                out.write(buffer, 0, read);
            }
            out.flush();
            if (total < 1024L) throw new IllegalArgumentException("Selected audio file appears empty or invalid");
            File backup = new File(getFilesDir(), "user_azan_audio.bak");
            if (backup.exists() && !backup.delete()) throw new IllegalStateException("Could not clear old audio backup");
            boolean hadTarget = target.exists();
            if (hadTarget && !target.renameTo(backup)) throw new IllegalStateException("Could not preserve previous audio before replacement");
            if (!temp.renameTo(target)) {
                if (hadTarget) backup.renameTo(target);
                throw new IllegalStateException("Could not save audio into app storage");
            }
            if (backup.exists()) backup.delete();
            PrayerPrefs.get(this).edit().putString(PrayerPrefs.AUDIO_PATH, target.getAbsolutePath()).apply();
            updateAudioStatus(); toast("New Azan audio saved");
        } catch (Exception ex) { temp.delete(); toast("Could not import audio: " + ex.getMessage()); }
    }

    private void previewAzan() {
        Intent play = new Intent(this, PrayerAzanService.class).setAction(PrayerAzanService.ACTION_PLAY).putExtra("prayer_name", "Preview");
        try { if (Build.VERSION.SDK_INT >= 26) startForegroundService(play); else startService(play); }
        catch (RuntimeException ex) { toast("Playback could not start. Check notification permission and volume."); }
    }

    private void stopAzanPlayback() {
        stopService(new Intent(this, PrayerAzanService.class));
        android.app.NotificationManager manager = (android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) { manager.cancel(PrayerNotifications.NOTIFICATION_ID); manager.cancel(PrayerNotifications.NOTIFICATION_ID + 1); }
    }

    private void updateAudioStatus() {
        if (audioText == null) return;
        String path = PrayerPrefs.audioPath(this);
        audioText.setText(path.isEmpty() ? "Current audio: your uploaded Azan (bundled default)" : "Current audio: custom Azan saved on this device");
        boolean notifications = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        boolean exact = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            android.app.AlarmManager alarm = (android.app.AlarmManager) getSystemService(ALARM_SERVICE);
            exact = alarm != null && alarm.canScheduleExactAlarms();
        }
        String lastError = PrayerPrefs.get(this).getString("azan_scheduler_error", "");
        String lastPrayer = PrayerPrefs.get(this).getString("azan_last_triggered_prayer", "");
        long lastAt = PrayerPrefs.get(this).getLong("azan_last_triggered_at", 0L);
        String last = lastPrayer.isEmpty() || lastAt == 0L ? "No recent Azan trigger recorded"
                : "Last trigger: " + lastPrayer + " · " + java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(new java.util.Date(lastAt));
        String status = (notifications ? "Notifications enabled" : "Allow notifications") + " · "
                + (exact ? "exact alarms enabled" : "EXACT ALARM ACCESS NEEDED — timing may be delayed")
                + "\n" + last
                + (lastError.isEmpty() ? "" : "\nScheduler status: " + lastError)
                + "\nCheck alarm volume, Do Not Disturb and battery restrictions if playback is silent.";
        reminderStatus.setText(status);
    }

    private void updateMethodLabel() {
        if (methodText == null) return;
        ShiaPrayerCalculator.Method m = PrayerPrefs.method(this);
        methodText.setText(m.title + ": Fajr " + m.fajrAngle + "° · Maghrib " + (Double.isNaN(m.maghribAngle) ? "sunset + 15 min" : m.maghribAngle + "°")
                + " · Isha " + m.ishaAngle + "° · Asr shadow factor 1");
    }

    private void openNotificationSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            startActivity(intent);
        } catch (Exception ex) {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    android.net.Uri.parse("package:" + getPackageName())));
        }
    }

    private void openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, android.net.Uri.parse("package:" + getPackageName()))); }
            catch (Exception ex) { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + getPackageName()))); }
        } else toast("Exact alarms are available on this Android version");
    }

    private void ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATION);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            boolean granted = false;
            for (int result : grantResults) if (result == PackageManager.PERMISSION_GRANTED) granted = true;
            if (granted) requestCurrentLocation();
            else toast("Location not granted; using saved prayer location");
        }
        if (requestCode == REQ_NOTIFICATION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) PrayerScheduler.scheduleUpcoming(this);
    }

    private void section(String title, String subtitle) {
        TextView head = text(title, 10, GOLD, true); head.setLetterSpacing(0.12f);
        LinearLayout.LayoutParams hp = fullWidth(-2); hp.topMargin = dp(19); content.addView(head, hp);
        TextView sub = text(subtitle, 10, MUTED, false); LinearLayout.LayoutParams sp = fullWidth(-2); sp.topMargin = dp(4); sp.bottomMargin = dp(8); content.addView(sub, sp);
    }

    private void addCard(View v) { LinearLayout.LayoutParams p = fullWidth(-2); p.topMargin = dp(10); content.addView(v, p); }
    private LinearLayout card() { LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(15), dp(15), dp(15), dp(15)); c.setBackground(round(WHITE, 20, 0xFF9B7024)); c.setElevation(dp(5)); return c; }
    private TextView text(String value, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); t.setTypeface(android.graphics.Typeface.DEFAULT, bold ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL); return t; }
    private Button smallButton(String label) { Button b = new Button(this); b.setText(label); b.setTextSize(10); b.setAllCaps(false); b.setTextColor(DARK); b.setBackground(round(0xFF33250F, 12, 0xFFFFC832)); b.setPadding(dp(8), 0, dp(8), 0); return b; }
    private EditText edit(String value, String hint) { EditText e = new EditText(this); e.setText(value); e.setHint(hint); e.setSingleLine(true); e.setTextSize(13); e.setTextColor(DARK); e.setHintTextColor(MUTED); e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED); return e; }
    private LinearLayout.LayoutParams fullWidth(int height) { return new LinearLayout.LayoutParams(-1, height); }
    private LinearLayout.LayoutParams fullWrap() { return new LinearLayout.LayoutParams(-2, -2); }
    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private android.graphics.drawable.GradientDrawable round(int color, int radius, int stroke) { android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); if (stroke != 0) d.setStroke(dp(1), stroke); return d; }
    private android.graphics.drawable.GradientDrawable gradient(int[] colors, int radius) { android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR, colors); d.setCornerRadius(dp(radius)); d.setStroke(dp(1), 0xFF8C6420); return d; }
    private String formatTime(ZonedDateTime time) { return time == null ? "—" : time.format(java.time.format.DateTimeFormatter.ofPattern("h:mm a", Locale.getDefault())); }
    private String compactDuration(Duration d) { long s = Math.max(0, d.getSeconds()); long h = s / 3600, m = (s % 3600) / 60, sec = s % 60; return h + "h " + m + "m " + sec + "s"; }
    private String hijriMonthName(int month) { String[] names = {"Muharram", "Safar", "Rabi al-Awwal", "Rabi al-Thani", "Jumada al-Ula", "Jumada al-Thaniyah", "Rajab", "Sha'ban", "Ramadan", "Shawwal", "Dhul Qa'dah", "Dhul Hijjah"}; return names[Math.max(1, Math.min(12, month)) - 1]; }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private static final class NextPrayer { final String name; final ZonedDateTime at; NextPrayer(String n, ZonedDateTime t) { name = n; at = t; } }
    private static final class IslamicEvent { final String name; final LocalDate date; IslamicEvent(String n, LocalDate d) { name = n; date = d; } }

    private final class PrayerCountdownView extends View {
        private final android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private long remaining; private String prayer = "Prayer";
        PrayerCountdownView(Context context) { super(context); }
        void setRemaining(long seconds, String name) { remaining = seconds; prayer = name; invalidate(); }
        @Override protected void onDraw(android.graphics.Canvas canvas) {
            super.onDraw(canvas); float cx = getWidth() / 2f, cy = getHeight() / 2f; float radius = Math.min(cx, cy) - dp(13);
            paint.setStyle(android.graphics.Paint.Style.STROKE); paint.setStrokeWidth(dp(9)); paint.setStrokeCap(android.graphics.Paint.Cap.ROUND); paint.setColor(0xFFE8DFC9);
            canvas.drawCircle(cx, cy, radius, paint);
            paint.setColor(GOLD); canvas.drawArc(cx - radius, cy - radius, cx + radius, cy + radius, -90, 275, false, paint);
            long s = Math.max(0, remaining); long days = s / 86400; long hours = (s % 86400) / 3600; long minutes = (s % 3600) / 60; long seconds = s % 60;
            paint.setStyle(android.graphics.Paint.Style.FILL); paint.setTextAlign(android.graphics.Paint.Align.CENTER); paint.setColor(DARK); paint.setTypeface(android.graphics.Typeface.create("sans-serif", 1)); paint.setTextSize(dp(13));
            canvas.drawText("TIME UNTIL " + prayer.toUpperCase(Locale.ROOT), cx, cy - dp(30), paint);
            paint.setTextSize(dp(24));
            String main = days > 0 ? days + "d " + hours + "h" : String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds);
            canvas.drawText(main, cx, cy + dp(8), paint);
            paint.setTextSize(dp(10)); paint.setTypeface(android.graphics.Typeface.DEFAULT); paint.setColor(MUTED);
            canvas.drawText(days > 0 ? String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds) : "HOURS : MINUTES : SECONDS", cx, cy + dp(29), paint);
        }
    }
}
