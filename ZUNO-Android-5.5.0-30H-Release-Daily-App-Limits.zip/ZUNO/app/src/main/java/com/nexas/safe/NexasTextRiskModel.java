package com.nexas.safe;

import android.content.Context;
import org.tensorflow.lite.Interpreter;
import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** 512-dimension FNV-1a text model. Synthetic-seed prototype; not a standalone block authority. */
final class NexasTextRiskModel implements AutoCloseable {
    private static final String SHA="af7b929fa07648d40a8e0e91f65ab82172b5dfe3da72f9175e5149395cf19d6c";
    private final Interpreter interpreter;
    NexasTextRiskModel(Context context) {
        Interpreter opened=null;
        try { File f=NexasModelAssets.install(context,"text_safety.tflite",SHA);
            if(f!=null) opened=new Interpreter(f,new Interpreter.Options().setNumThreads(2));
            if(opened!=null && (opened.getInputTensor(0).shape().length!=2 || opened.getInputTensor(0).shape()[1]!=512 || opened.getOutputTensor(0).shape()[1]!=2)) { opened.close(); opened=null; }
        } catch(Exception e) { if(opened!=null) opened.close(); opened=null; }
        interpreter=opened;
    }
    boolean isReady() { return interpreter != null; }

    NexasModelResult classify(String text) {
        if(interpreter==null) return new NexasModelResult(NexasModelResult.Decision.UNKNOWN,"Text model unavailable",0,"Missing or incompatible model");
        try {
            float[][] input=new float[1][512];
            for(String token:text.toLowerCase(Locale.ROOT).split("[^\\p{L}\\p{N}]+")) if(!token.isEmpty()) input[0][hash(token)]=1f;
            float[][] out=new float[1][2]; interpreter.run(input,out);
            if (!Float.isFinite(out[0][0]) || !Float.isFinite(out[0][1])) {
                return new NexasModelResult(NexasModelResult.Decision.UNKNOWN,
                        "Invalid text model output", 0f, "Model returned non-finite logits");
            }
            float risk=softmaxRisk(out[0][0],out[0][1]);
            return risk>=0.70f
                ? new NexasModelResult(NexasModelResult.Decision.FLAG,"Potential bullying, threat or scam wording",risk,"Prototype only; synthetic training data")
                : new NexasModelResult(NexasModelResult.Decision.SAFE_CANDIDATE,"No model flag",1f-risk,"Not proof of safety; English/Roman Urdu coverage is limited");
        } catch(Exception e) { return new NexasModelResult(NexasModelResult.Decision.UNKNOWN,"Text inference error",0,e.getMessage()==null?"Inference failed":e.getMessage()); }
    }
    private static int hash(String s) { int h=0x811c9dc5; for(byte b:s.getBytes(StandardCharsets.UTF_8)){h^=b&255;h*=0x01000193;} return (int)(Integer.toUnsignedLong(h)%512); }
    private static float softmaxRisk(float a,float b) { double m=Math.max(a,b), x=Math.exp(a-m), y=Math.exp(b-m); return (float)(y/(x+y)); }
    @Override public void close(){if(interpreter!=null)interpreter.close();}
}
