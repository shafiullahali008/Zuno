package com.nexas.safe;

import android.content.Context;
import org.tensorflow.lite.Interpreter;
import java.io.File;
import java.net.URI;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.util.Locale;

/** 20-feature URL-pattern prototype. Not a replacement for live reputation/threat feeds. */
final class NexasUrlRiskModel implements AutoCloseable {
    private static final String SHA="18738f18667a9fa78f0f2e8a068b0f337da46462c9d8565ddee63adaf4d85dea";
    private static final String[] TERMS={"login","verify","account","update","secure","wallet","bank","password","signin","bonus","free","gift","crypto","support"};
    private static final String[] SHORTENERS={"bit.ly","tinyurl.com","t.co","goo.gl","ow.ly","is.gd","buff.ly"};
    private final Interpreter interpreter;
    NexasUrlRiskModel(Context context) {
        Interpreter opened=null;
        try { File f=NexasModelAssets.install(context,"url_risk.tflite",SHA);
            if(f!=null) opened=new Interpreter(f,new Interpreter.Options().setNumThreads(2));
            if(opened!=null && (opened.getInputTensor(0).shape().length!=2 || opened.getInputTensor(0).shape()[1]!=20 || opened.getOutputTensor(0).shape()[1]!=2)){opened.close();opened=null;}
        } catch(Exception e){if(opened!=null)opened.close();opened=null;}
        interpreter=opened;
    }
    boolean isReady() { return interpreter != null; }

    NexasModelResult classify(String raw) {
        if(interpreter==null)return new NexasModelResult(NexasModelResult.Decision.UNKNOWN,"URL model unavailable",0,"Missing or incompatible model");
        try { float[][] out=new float[1][2]; interpreter.run(new float[][]{features(raw)},out);
            if (!Float.isFinite(out[0][0]) || !Float.isFinite(out[0][1])) {
                return new NexasModelResult(NexasModelResult.Decision.UNKNOWN,
                        "Invalid URL model output", 0f, "Model returned non-finite logits");
            }
            double m=Math.max(out[0][0],out[0][1]); double a=Math.exp(out[0][0]-m),b=Math.exp(out[0][1]-m); float risk=(float)(b/(a+b));
            return risk>=0.70f?new NexasModelResult(NexasModelResult.Decision.FLAG,"Suspicious URL pattern",risk,"Prototype only; check domain reputation"):
                new NexasModelResult(NexasModelResult.Decision.SAFE_CANDIDATE,"No URL model flag",1f-risk,"Not a safety guarantee; model is synthetic-seed prototype");
        }catch(Exception e){return new NexasModelResult(NexasModelResult.Decision.UNKNOWN,"URL inference error",0,e.getMessage()==null?"Inference failed":e.getMessage());}
    }
    private static float[] features(String raw) {
        String s=raw==null?"":raw.trim(), candidate=s.contains("://")?s:"http://"+s; URI u;
        try{u=URI.create(candidate);}catch(Exception e){u=URI.create("http://invalid");}
        String host=u.getHost()==null?"":u.getHost().toLowerCase(Locale.ROOT), path=u.getRawPath()==null?"":u.getRawPath(), query=u.getRawQuery()==null?"":u.getRawQuery();
        String[] parts=host.split("\\.",-1); boolean ip=isIpLiteral(host); int special=0,digits=0; for(char c:s.toCharArray()){if(!Character.isLetterOrDigit(c))special++;if(Character.isDigit(c))digits++;}
        int terms=0; for(String t:TERMS)if(s.toLowerCase(Locale.ROOT).contains(t))terms++; boolean shortener=false;for(String t:SHORTENERS)if(host.equals(t))shortener=true;
        float entropy=entropy(host); int length=Math.max(1,s.length());
        return new float[]{Math.min(s.length(),300)/300f,Math.min(host.length(),100)/100f,Math.min(path.length(),200)/200f,Math.min(query.length(),200)/200f,
            Math.min(count(s,'.'),10)/10f,Math.min(count(s,'-'),10)/10f,digits/(float)length,special/(float)length,
            "https".equalsIgnoreCase(u.getScheme())?1f:0f,ip?1f:0f,host.contains("xn--")?1f:0f,s.contains("@")?1f:0f,u.getRawFragment()!=null?1f:0f,(u.getPort()>0 && u.getPort()<=65535)?1f:0f,
            Math.min(Math.max(parts.length-2,0),5)/5f,Math.min(terms,5)/5f,Math.min(count(path,'/'),10)/10f,path.contains("//")?1f:0f,Math.min(entropy,5f)/5f,shortener?1f:0f};
    }
    private static boolean isIpLiteral(String host) {
        if (host == null || host.isEmpty()) return false;
        String value = host;
        if (value.startsWith("[") && value.endsWith("]")) {
            value = value.substring(1, value.length() - 1);
        }
        if (value.indexOf(':') >= 0) {
            try {
                return InetAddress.getByName(value) instanceof Inet6Address;
            } catch (Exception ignored) {
                return false;
            }
        }
        String[] octets = value.split("\\.", -1);
        if (octets.length != 4) return false;
        for (String octet : octets) {
            if (octet.isEmpty() || (octet.length() > 1 && octet.charAt(0) == '0')) return false;
            int number = 0;
            for (int i = 0; i < octet.length(); i++) {
                char ch = octet.charAt(i);
                if (ch < '0' || ch > '9') return false;
                number = number * 10 + (ch - '0');
                if (number > 255) return false;
            }
        }
        return true;
    }
    private static int count(String s,char c){int n=0;for(int i=0;i<s.length();i++)if(s.charAt(i)==c)n++;return n;}
    private static float entropy(String s){if(s.isEmpty())return 0;int[] c=new int[128];for(char x:s.toCharArray())if(x<128)c[x]++;double h=0;for(int n:c)if(n>0){double p=n/(double)s.length();h-=p*(Math.log(p)/Math.log(2));}return (float)h;}
    @Override public void close(){if(interpreter!=null)interpreter.close();}
}
