package com.nexas.safe;

/** Pure time arithmetic shared by the All-in-One streak timer and its unit tests. */
final class AllInOneTime {
    static final long DAY_MS = 86_400_000L;
    static final long MIN_DURATION_MS = 60_000L;
    static final long MAX_DURATION_MS = 3650L * DAY_MS;

    private AllInOneTime() { }

    static boolean isValidDuration(long durationMs) {
        return durationMs >= MIN_DURATION_MS && durationMs <= MAX_DURATION_MS;
    }

    static long elapsed(long startedAt, long now) {
        if (startedAt <= 0L || now <= startedAt) return 0L;
        return now - startedAt;
    }

    /** Displayed day number: the first day starts immediately at activation. */
    static int currentStreakDay(long elapsedMs) {
        long safe = Math.max(0L, elapsedMs);
        return (int) Math.min(3651L, safe / DAY_MS + 1L);
    }

    /** Number of full 24-hour periods completed. */
    static int completedDays(long elapsedMs) {
        return (int) Math.min(3650L, Math.max(0L, elapsedMs) / DAY_MS);
    }
}
