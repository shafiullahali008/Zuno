package com.nexas.safe;

import android.content.Context;
import android.content.SharedPreferences;

final class PrayerPrefs {
    static final String NAME = "vyra_prayer_settings";
    static final String LAT = "latitude", LON = "longitude", LOCATION = "location_label";
    static final String METHOD = "calculation_method", AZAN_ENABLED = "azan_enabled";
    static final String HIJRI_OFFSET = "hijri_offset", AUDIO_PATH = "azan_audio_path";
    static final String[] OFFSET_KEYS = {"offset_fajr", "offset_sunrise", "offset_dhuhr", "offset_asr", "offset_maghrib", "offset_isha"};
    private PrayerPrefs() { }
    static SharedPreferences get(Context context) { return context.getSharedPreferences(NAME, Context.MODE_PRIVATE); }
    static double latitude(Context c) { return get(c).getFloat(LAT, 33.7995f); }
    static double longitude(Context c) { return get(c).getFloat(LON, 72.7221f); }
    static String location(Context c) { return get(c).getString(LOCATION, "Wah Cantt, Pakistan (default location)"); }
    static ShiaPrayerCalculator.Method method(Context c) {
        String name = get(c).getString(METHOD, ShiaPrayerCalculator.Method.JAFARI_QOM.name());
        try { return ShiaPrayerCalculator.Method.valueOf(name); }
        catch (Exception ignored) { return ShiaPrayerCalculator.Method.JAFARI_QOM; }
    }
    static int[] offsets(Context c) {
        int[] values = new int[6]; SharedPreferences p = get(c);
        for (int i = 0; i < values.length; i++) values[i] = p.getInt(OFFSET_KEYS[i], 0);
        return values;
    }
    static boolean azanEnabled(Context c) { return get(c).getBoolean(AZAN_ENABLED, true); }
    static boolean prayerAzanEnabled(Context c, String prayer) {
        return azanEnabled(c) && get(c).getBoolean("azan_" + prayer.toLowerCase(java.util.Locale.ROOT), true);
    }
    static String audioPath(Context c) { return get(c).getString(AUDIO_PATH, ""); }
    static String doneKey(String date, String prayer) { return "done_" + date + "_" + prayer.toLowerCase(java.util.Locale.ROOT); }
}
