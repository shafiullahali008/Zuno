package com.nexas.safe;

import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/** Foreground media-playback service so scheduled Azan can continue while the display is locked. */
public class PrayerAzanService extends Service {
    public static final String ACTION_PLAY = "com.nexas.safe.PLAY_AZAN";
    private MediaPlayer player;
    private PowerManager.WakeLock wakeLock;
    private AudioManager audioManager;
    private AudioFocusRequest focusRequest;
    private String prayerName = "Prayer";

    @Override public void onCreate() {
        super.onCreate();
        PrayerNotifications.createChannel(this);
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || !ACTION_PLAY.equals(intent.getAction())) { stopPlayback(); stopSelf(startId); return START_NOT_STICKY; }
        prayerName = intent.getStringExtra("prayer_name");
        if (prayerName == null) prayerName = "Prayer";
        try {
            android.app.NotificationManager manager = (android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) manager.cancel(PrayerNotifications.NOTIFICATION_ID + 1);
            startForeground(PrayerNotifications.NOTIFICATION_ID, PrayerNotifications.build(this, prayerName, true));
            startPlayback();
        } catch (Exception ex) {
            PrayerNotifications.showFallback(this, prayerName);
            stopPlayback(); stopSelf(startId);
        }
        return START_NOT_STICKY;
    }

    private void startPlayback() throws Exception {
        stopPlayerOnly();
        releaseWakeLock();
        acquireWakeLock();
        requestAudioFocus();
        player = new MediaPlayer();
        player.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build());
        player.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
        String customPath = PrayerPrefs.audioPath(this);
        File selected = !customPath.isEmpty() ? new File(customPath) : null;
        if (selected != null && selected.isFile() && selected.length() > 0) {
            player.setDataSource(selected.getAbsolutePath());
        } else {
            File bundled = new File(getFilesDir(), "bundled_azan.mp3");
            if (!bundled.isFile() || bundled.length() == 0) {
                try (InputStream in = getAssets().open("azan_default.mp3");
                     java.io.FileOutputStream out = new java.io.FileOutputStream(bundled)) {
                    byte[] buffer = new byte[8192]; int count;
                    while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                    out.flush();
                }
            }
            player.setDataSource(bundled.getAbsolutePath());
        }
        player.setOnPreparedListener(mp -> {
            try { mp.start(); } catch (RuntimeException ex) { stopPlayback(); stopSelf(); }
        });
        player.setOnCompletionListener(mp -> { stopPlayback(); stopSelf(); });
        player.setOnErrorListener((mp, what, extra) -> { stopPlayback(); stopSelf(); return true; });
        player.prepareAsync();
    }

    private void requestAudioFocus() {
        if (audioManager == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            focusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                    .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setOnAudioFocusChangeListener(change -> {
                        if (change == AudioManager.AUDIOFOCUS_LOSS) { stopPlayback(); stopSelf(); }
                    })
                    .build();
            audioManager.requestAudioFocus(focusRequest);
        } else {
            //noinspection deprecation
            audioManager.requestAudioFocus(null, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
        }
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ZUNO:PrayerAzan");
                wakeLock.acquire(15L * 60L * 1000L);
            }
        } catch (RuntimeException ignored) { }
    }

    private void stopPlayerOnly() {
        if (player != null) {
            try { if (player.isPlaying()) player.stop(); } catch (RuntimeException ignored) { }
            try { player.reset(); player.release(); } catch (RuntimeException ignored) { }
            player = null;
        }
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) { try { wakeLock.release(); } catch (RuntimeException ignored) { } }
        wakeLock = null;
    }

    private void stopPlayback() {
        stopPlayerOnly();
        if (audioManager != null) {
            try {
                if (Build.VERSION.SDK_INT >= 26 && focusRequest != null) audioManager.abandonAudioFocusRequest(focusRequest);
                else { //noinspection deprecation
                    audioManager.abandonAudioFocus(null);
                }
            } catch (RuntimeException ignored) { }
        }
        focusRequest = null;
        releaseWakeLock();
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else { //noinspection deprecation
            stopForeground(true);
        }
    }

    @Override public void onDestroy() { stopPlayback(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
