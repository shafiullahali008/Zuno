package com.nexas.safe;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

final class PrayerNotifications {
    static final String CHANNEL_ID = "vyra_prayer_azan";
    static final int NOTIFICATION_ID = 8740;
    private PrayerNotifications() { }
    static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null && manager.getNotificationChannel(CHANNEL_ID) == null) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Prayer Azan", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Azan playback status and stop control");
            channel.setSound(null, null);
            channel.enableVibration(false);
            manager.createNotificationChannel(channel);
        }
    }
    static Notification build(Context context, String prayer, boolean ongoing) {
        createChannel(context);
        Intent stop = new Intent(context, PrayerStopReceiver.class).setAction(PrayerStopReceiver.ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getBroadcast(context, 8741, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent open = new Intent(context, PrayerActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(context, 8742, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, CHANNEL_ID) : new Notification.Builder(context);
        builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("ZUNO • " + prayer + " Azan")
                .setContentText(ongoing ? "Azan is playing · Tap Stop to end playback" : "Prayer time has started")
                .setContentIntent(content)
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(ongoing)
                .setAutoCancel(!ongoing)
                .setOnlyAlertOnce(true);
        android.graphics.drawable.Icon actionIcon = android.graphics.drawable.Icon.createWithResource(context, android.R.drawable.ic_media_pause);
        if (ongoing) builder.addAction(new Notification.Action.Builder(actionIcon, "Stop Azan", stopPending).build());
        else builder.addAction(new Notification.Action.Builder(actionIcon, "Open Prayer Times", content).build());
        return builder.build();
    }
    static void showFallback(Context context, String prayer) {
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            try { manager.notify(NOTIFICATION_ID + 1, build(context, prayer, false)); }
            catch (SecurityException ignored) { }
        }
    }
}
