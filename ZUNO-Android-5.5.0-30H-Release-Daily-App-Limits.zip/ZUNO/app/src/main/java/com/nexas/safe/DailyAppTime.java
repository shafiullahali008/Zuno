package com.nexas.safe;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Daily app budgets are counted locally from the user-enabled Accessibility foreground-window events. */
final class DailyAppTime {
    private static final String LIMIT_PREFIX = "daily_app_limit_min_";
    private static final String USAGE_PREFIX = "daily_app_usage_ms_";
    private static final String LABEL_PREFIX = "daily_app_label_";
    private DailyAppTime() { }

    static String todayKey() {
        return new SimpleDateFormat("yyyyMMdd", Locale.ROOT).format(new Date());
    }
    static String limitKey(String pkg) { return LIMIT_PREFIX + pkg; }
    static String labelKey(String pkg) { return LABEL_PREFIX + pkg; }
    static String usageKey(String pkg) { return USAGE_PREFIX + todayKey() + "_" + pkg; }
    static int limitMinutes(Context c, String pkg) {
        return ProtectionPrefs.prefs(c).getInt(limitKey(pkg), 0);
    }
    static long usedMillis(Context c, String pkg) {
        return ProtectionPrefs.prefs(c).getLong(usageKey(pkg), 0L);
    }
    static void addMillis(Context c, String pkg, long delta) {
        if (pkg == null || pkg.isEmpty() || delta <= 0L) return;
        SharedPreferences p = ProtectionPrefs.prefs(c);
        String key = usageKey(pkg);
        p.edit().putLong(key, Math.max(0L, p.getLong(key, 0L)) + delta).apply();
    }
    static boolean isOverLimit(Context c, String pkg) {
        int limit = limitMinutes(c, pkg);
        return limit > 0 && usedMillis(c, pkg) >= limit * 60_000L;
    }
    static String formatDuration(long millis) {
        long seconds = Math.max(0L, millis) / 1000L;
        long hours = seconds / 3600L;
        long minutes = (seconds % 3600L) / 60L;
        long remainder = seconds % 60L;
        return hours > 0L ? String.format(Locale.ROOT, "%dh %02dm", hours, minutes)
                : String.format(Locale.ROOT, "%dm %02ds", minutes, remainder);
    }
    static boolean isProtectedSystemPackage(String pkg) {
        if (pkg == null) return true;
        return pkg.equals("android") || pkg.equals("com.android.systemui")
                || pkg.equals("com.android.settings") || pkg.equals("com.android.phone")
                || pkg.equals("com.android.dialer") || pkg.equals("com.google.android.dialer")
                || pkg.equals("com.android.contacts") || pkg.equals("com.google.android.contacts")
                || pkg.equals("com.samsung.android.contacts")
                || pkg.equals("com.android.server.telecom") || pkg.equals("com.android.emergency")
                || pkg.equals("com.google.android.apps.emergencyassist")
                || pkg.equals("com.android.permissioncontroller")
                || pkg.equals("com.google.android.permissioncontroller")
                || pkg.equals("com.android.packageinstaller")
                || pkg.equals("com.google.android.packageinstaller");
    }
}
