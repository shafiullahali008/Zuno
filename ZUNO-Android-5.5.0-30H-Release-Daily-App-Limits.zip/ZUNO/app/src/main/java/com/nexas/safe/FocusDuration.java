package com.nexas.safe;

import java.time.Duration;
import java.time.Instant;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Locale;

/** Calendar-aware helpers for timed Focus locks. No Android dependencies; safe to unit test. */
final class FocusDuration {
    private FocusDuration() { }

    static long calculateEndAtMillis(long startMillis, ZoneId zone,
                                     int years, int months, int days, int hours, int minutes) {
        if (zone == null) throw new IllegalArgumentException("A time zone is required.");
        if (years < 0 || years > 25 || months < 0 || months > 11
                || days < 0 || days > 30 || hours < 0 || hours > 23
                || minutes < 0 || minutes > 59) {
            throw new IllegalArgumentException("The requested lock duration is outside the supported range.");
        }
        if (years == 0 && months == 0 && days == 0 && hours == 0 && minutes == 0) {
            throw new IllegalArgumentException("The lock duration must be greater than zero.");
        }
        ZonedDateTime start = Instant.ofEpochMilli(startMillis).atZone(zone);
        ZonedDateTime end = start.plusYears(years).plusMonths(months).plusDays(days)
                .plusHours(hours).plusMinutes(minutes);
        long endMillis = end.toInstant().toEpochMilli();
        if (endMillis <= startMillis) throw new IllegalArgumentException("The lock end time must be after its start time.");
        return endMillis;
    }

    static String formatRemaining(long nowMillis, long endMillis, ZoneId zone) {
        if (zone == null) throw new IllegalArgumentException("A time zone is required.");
        ZonedDateTime now = Instant.ofEpochMilli(nowMillis).atZone(zone);
        ZonedDateTime end = Instant.ofEpochMilli(endMillis).atZone(zone);
        if (!end.isAfter(now)) return "0 years · 0 months · 0 days\n00:00:00 remaining";
        Period period = calendarPeriod(now, end);
        ZonedDateTime anchor = now.plus(period);
        long seconds = Math.max(0L, Duration.between(anchor, end).getSeconds());
        long hours = seconds / 3600L;
        long minutes = (seconds % 3600L) / 60L;
        long secs = seconds % 60L;
        return String.format(Locale.ROOT, "%d years · %d months · %d days\n%02d:%02d:%02d remaining",
                period.getYears(), period.getMonths(), period.getDays(), hours, minutes, secs);
    }

    static String formatCompactRemaining(long nowMillis, long endMillis, ZoneId zone) {
        if (zone == null) throw new IllegalArgumentException("A time zone is required.");
        ZonedDateTime now = Instant.ofEpochMilli(nowMillis).atZone(zone);
        ZonedDateTime end = Instant.ofEpochMilli(endMillis).atZone(zone);
        if (!end.isAfter(now)) return "00:00";
        Period period = calendarPeriod(now, end);
        ZonedDateTime anchor = now.plus(period);
        long seconds = Math.max(0L, Duration.between(anchor, end).getSeconds());
        long hours = seconds / 3600L;
        long minutes = (seconds % 3600L) / 60L;
        if (period.getYears() > 0) return period.getYears() + "y " + period.getMonths() + "m";
        if (period.getMonths() > 0) return period.getMonths() + "m " + period.getDays() + "d";
        if (period.getDays() > 0) return period.getDays() + "d " + hours + "h";
        long totalSeconds = Math.max(0L, Duration.between(now, end).getSeconds());
        return String.format(Locale.ROOT, "%02d:%02d", totalSeconds / 60L, totalSeconds % 60L);
    }

    private static Period calendarPeriod(ZonedDateTime start, ZonedDateTime end) {
        Period period = Period.between(start.toLocalDate(), end.toLocalDate());
        ZonedDateTime anchor = start.plus(period);
        while (anchor.isAfter(end) && !period.isZero() && !period.isNegative()) {
            period = period.minusDays(1);
            anchor = start.plus(period);
        }
        return period;
    }
}
