# VYRA Arcade — Current scope

The current source contains two real-time OpenGL ES 2.0 playable prototypes:

- **Temple Sprint 3D:** procedural runner course, lane switching, jump / slide controls, obstacles and collectible scoring.
- **Orbit Roll 3D:** lane steering, rolling-orb visuals, collectible scoring, obstacles and progressive distance.

They are offline prototypes, not finished commercial games. There are no licensed Temple Run or Angry Birds assets; names and visuals are original concepts. Production readiness would require original rigged character / environment assets, sound, level design, device-tier profiling, accessibility controls, QA and crash testing.

The existing brain-training activities remain simple offline mini-games. A full 4K asset pipeline or a AAA physics simulation is outside the scope of this Java-only update.
