# ZUNO 5.0.0 — Islamic Wellness & Digital Protection

## Brand and design update
- Rebranded the user-facing application from VYRA to **ZUNO**.
- Full product name: **ZUNO — Islamic Wellness & Digital Protection**.
- Replaced the launcher identity and in-app brand mark with the user-provided ZUNO mosque/crescent logo.
- Rebuilt the application theme around midnight black, charcoal surfaces, warm gold and ivory typography.
- Applied the dark/gold direction to the main dashboard, onboarding, focus blocker, prayer/calendar, guide and arcade screens.
- Updated status/navigation bars and app theme to match the dark palette.
- Preserved applicationId `com.nexas.safe`, existing preference keys, notification channel IDs and Java package/class names to maintain upgrade compatibility.

## Existing features retained
- Focus timer, All-in-One commitment and streak/level tracking.
- Selected-app restrictions, accessibility-based text checks, adult-domain filtering and optional image scanning.
- Shia prayer calculation presets, Azan playback and upload/restore controls, Qibla, Hijri calendar, Islamic occasion countdowns and prayer streaks.
- Existing TFLite models and offline games.

## Verification limitations
- Source archive and resources should be checked in CI with Android SDK 35, AGP 8.7.3, Gradle 8.9 and JDK 17.
- Full Gradle build and physical Android 16 visual verification are not claimed by this rebrand package.
