# ZUNO source cleanup report

## Completed

- Removed the imported third-party blocker runtime and its app-side integration.
- Removed the imported visual classifier model, adult-domain hash database and keyword hash database.
- Removed image/video scanning buttons, pickers and scanner callbacks that depended on the removed visual model.
- Kept the custom block-screen image picker; it is independent of the removed visual scanner.
- Renamed the retained user-owned model adapters to `NexasTextRiskModel`, `NexasUrlRiskModel`, `NexasModelAssets` and `NexasModelResult`.
- Regenerated the two retained TFLite models from the included NEXAS training scripts and bundled synthetic seed data. Updated Java SHA-256 pins and the model checksum manifest.
- Removed optional third-party model download/provisioning scripts from the model toolkit. The Android runtime and toolkit now retain only the two NEXAS-owned text/URL models.
- Preserved Focus Mode, selected-app restrictions, custom block screen, All-in-One timer, streaks, milestones, points, levels, games, Islamic prayer/Azan module and calendar.

## Checks completed

- Removed-component reference scan: clean.
- Python source AST parse: passed.
- JSON and Android XML parse: passed.
- Java delimiter/static source scan: passed.
- Context-aware text-rule smoke tests: 4 passed.
- TFLite structure and embedded-weight smoke tests: passed for both models.
- Model SHA-256 pins and checksum manifest: synchronized.
- ZIP integrity check: passed.

## Not verified

A complete Android Gradle unit-test/build could not be run here. The Gradle 8.9 wrapper attempted to download its distribution, but outbound DNS/network access to `services.gradle.org` was unavailable. Use the included GitHub Actions workflow or an Android SDK-equipped machine for the definitive APK build.

The two retained models remain synthetic-data prototypes. Their smoke tests verify file structure and embedded weights, not real-world accuracy. Their results remain advisory; `SAFE_CANDIDATE` is not a guarantee of safety.
