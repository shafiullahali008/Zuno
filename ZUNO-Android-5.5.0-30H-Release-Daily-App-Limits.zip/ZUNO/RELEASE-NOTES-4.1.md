# VYRA 4.1.0 — Release notes

- 3D chrome / cyan / violet shield emblem and wordmark.
- Updated onboarding logo and Android adaptive launcher icon.
- Optional live visual screening via Android MediaProjection.
- Native per-session Android permission flow; no silent screen-capture start.
- Persistent foreground notification with Stop protection action.
- Local-only image processing; captured frames are transient and not saved or uploaded.
- Automatic Home action and VYRA block screen via the enabled Accessibility service on supported screens.
- Best-effort near-0.5s frame sampling target; real latency depends on device and model.
