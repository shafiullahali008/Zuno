# ZUNO 5.4.0 — Premium settings and focus UI

- Reorganised Settings into dedicated Focus & Protection, Islamic & Azan, Block Screen Appearance, Daily Routine, Android Permissions, Privacy & Recovery, and About sections.
- Added functional NEXAS protection and strict-session switches. Strict mode is enabled by default after the upgrade and cannot be changed during an active focus session.
- Added a global Automatic Azan switch and individual Fajr, Dhuhr, Asr, Maghrib and Isha switches. Each change reschedules prayer alarms.
- Added a full-screen block-image upload/remove area. Uploaded images use center-crop by default and remain full-screen behind a readability gradient.
- Added edge-to-edge immersive display for the block screen. Android navigation gestures, Back and critical system controls remain available.
- Refined the focus countdown dial with a metallic outer bezel, deeper centre surface and thicker luminous progress ring.
- Retained 12 source-led Twelver Shia Waqiat from the existing Islamic Library.
- Recovery remains protected by Android device credentials or a timed typed phrase fallback. Instagram messaging is not used as an authentication channel.

## Android platform boundary
ZUNO does not force-close Accessibility or Device Admin settings, trap users in the app, disable emergency calling, or make the app undeletable. Permission status refreshes when the user returns to ZUNO. Strict focus enforcement works within Android's supported APIs and the permissions the device owner enables.

## Validation
Manifest XML parsed, Java source sanity checks and ZIP integrity checks passed. Full Android Gradle compilation remains to be confirmed by GitHub Actions.
