# ZUNO 5.3.0 — UI and Islamic Library update

- Custom uploaded block-screen image now renders as a full-screen, center-cropped background with a dark readability scrim rather than a small thumbnail.
- Added a dedicated Ahlul Bayt / Islamic Waqiat reading library with 12 entries and named Twelver Shia source references.
- Added historical-source caution notes: source citations identify where a report is discussed and do not imply every wording or chain is equally authentic.
- Refined the Automatic Azan switch tinting to match the gold UI.
- Existing Focus Mode, NEXAS models, prayer tracking, timer and safety recovery behavior remain in place.

## Platform boundary
ZUNO does not trap the user inside Android Accessibility or Device Admin settings, force-close those system screens, or prevent the device owner from revoking permissions. Android system permission controls remain under the user's control. Strict Mode can enforce the app's own configured focus rules only within Android's supported APIs.

## Validation
- AndroidManifest.xml parsed successfully.
- Static source/reference checks passed.
- Full Gradle compilation was not run: the Gradle 8.9 wrapper download failed because this environment could not resolve services.gradle.org. Run the repository's GitHub Actions workflow to perform the actual Android build.
