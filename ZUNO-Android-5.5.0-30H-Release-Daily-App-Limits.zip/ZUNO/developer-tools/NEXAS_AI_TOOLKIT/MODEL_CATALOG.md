# NEXAS AI — owned model catalog

| Model | Included | Purpose | Limitation |
|---|---|---|---|
| `text_safety.tflite` | Yes | Prototype text-risk screening for bullying, threats and scam-like wording | Synthetic-seed training only; not production-grade and limited language coverage |
| `url_risk.tflite` | Yes | Prototype suspicious-URL-pattern screening | Synthetic URL patterns only; not a live reputation or threat-intelligence service |

Both models run locally in ZUNO through the NEXAS Java adapters. They report advisory signals only and do not independently trigger automatic blocking. Missing, incompatible or failed inference returns `UNKNOWN`. `SAFE_CANDIDATE` is not a guarantee of safety.

No third-party visual, audio, OCR, ASR, image moderation or deepfake model is provisioned by this toolkit. The Android runtime uses only the two NEXAS model files listed above.
