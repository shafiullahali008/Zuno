#!/usr/bin/env python3
"""Train small on-device linear screening models from disclosed synthetic seed data.

These are reproducible prototypes, NOT production-grade moderation models.
The seed corpus is synthetic and intentionally limited to non-explicit risk
signals (bullying/threats/scams) and synthetic URL patterns in reserved domains.
"""
from __future__ import annotations
import csv, hashlib, ipaddress, json, math, pathlib, random, re, sys
from urllib.parse import urlparse
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix
from write_linear_tflite import make_linear_tflite
from sync_model_hashes import sync_hashes



def find_project_root() -> pathlib.Path:
    """Find the VYRA root when this toolkit is nested under developer-tools/."""
    script = pathlib.Path(__file__).resolve()
    for parent in script.parents:
        if (parent / "settings.gradle").is_file() and (parent / "app/src/main/assets/models").is_dir():
            return parent
    raise RuntimeError("Could not locate the VYRA project root (expected settings.gradle and app/src/main/assets/models)")

TOOLKIT_ROOT = pathlib.Path(__file__).resolve().parents[1]
PROJECT_ROOT = find_project_root()

OUT = PROJECT_ROOT / "app/src/main/assets/models"
DATA = TOOLKIT_ROOT / "data"
TEXT_DIM = 512
SUSPICIOUS = ("login", "verify", "account", "update", "secure", "wallet", "bank", "password", "signin", "bonus", "free", "gift", "crypto", "support")
SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly"}


def hashed_token(token: str) -> int:
    h = 2166136261
    for byte in token.encode("utf-8"):
        h ^= byte
        h = (h * 16777619) & 0xffffffff
    return h % TEXT_DIM


def text_features(text: str) -> np.ndarray:
    out = np.zeros(TEXT_DIM, dtype=np.float32)
    for token in re.findall(r"[^\W_]+", str(text).lower(), flags=re.UNICODE):
        out[hashed_token(token)] = 1.0
    return out


def url_features(value: str) -> list[float]:
    raw = str(value).strip()
    candidate = raw if "://" in raw else "http://" + raw
    try:
        p = urlparse(candidate)
        host = (p.hostname or "").lower()
        port = p.port or 0
    except Exception:
        host, port, p = "", 0, urlparse("http://invalid")
    host_body = host.split(".")
    try:
        ipaddress.ip_address(host)
        is_ip = 1.0
    except ValueError:
        is_ip = 0.0
    specials = sum(not c.isalnum() for c in raw)
    counts = [host.count(c) for c in set(host)]
    n = max(1, len(host))
    entropy = -sum((k / n) * math.log2(k / n) for k in counts if k)
    return [
        min(len(raw), 300) / 300, min(len(host), 100) / 100,
        min(len(p.path), 200) / 200, min(len(p.query), 200) / 200,
        min(raw.count("."), 10) / 10, min(raw.count("-"), 10) / 10,
        sum(c.isdigit() for c in raw) / max(1, len(raw)),
        specials / max(1, len(raw)), float(p.scheme == "https"), is_ip,
        float("xn--" in host), float("@" in raw), float(bool(p.fragment)),
        float(port != 0), min(max(0, len(host_body) - 2), 5) / 5,
        min(sum(w in raw.lower() for w in SUSPICIOUS), 5) / 5,
        min(p.path.count("/"), 10) / 10, float("//" in p.path),
        min(entropy, 5) / 5, float(host in SHORTENERS)
    ]


def make_text_rows(seed=42, per_template=35):
    rng = random.Random(seed)
    safe_templates = [
        "hi {name}, are we meeting at {time}?", "please send me the {subject} notes",
        "thank you for helping me with {subject}", "kal {time} class hai, please confirm",
        "mujhe {subject} ki homework mein help chahiye", "shukriya, tumhari help kaafi useful thi",
        "I disagree with that idea, can we discuss it?", "your presentation was clear and helpful",
        "please call me when you are free", "the assignment is due on {day}",
        "aaj library mein milte hain", "I will share the project file this evening",
        "can you explain this {subject} question?", "good morning, hope your day goes well",
        "please check the timetable and let me know", "we should review the chapter together",
        "tumhara kaam achha hai, thanks for sharing", "I have a question about the school portal",
        "the meeting has moved to {time}", "please use the official class group for updates"
    ]
    risk_templates = [
        "I will hurt you if you do not stop", "I am going to hurt you after school",
        "you are useless and nobody wants you here", "tum bilkul bekaar ho aur tum se kuch nahi hota",
        "everyone should avoid {name}, they do not belong here", "stop bullying me or I will report this",
        "send your password now to verify your account", "apna password bhejo warna account band ho jayega",
        "enter your login code to claim a free prize", "pay this fee immediately to unlock your reward",
        "your account will be closed unless you share the verification code", "click this suspicious link and enter your bank details",
        "tumhein nuksan pohanchane ki dhamki de raha hoon", "I will keep threatening you until you obey",
        "share your one time code with me for account verification", "you are stupid and everyone is laughing at you",
        "send private account details to claim the bonus", "do this now or I will make trouble for you",
        "fake support team asking for your password", "you deserve to be bullied by everyone"
    ]
    names = ["Ali", "Sara", "Ahmed", "Ayesha", "Hamza", "Noor"]
    times = ["8 am", "10:30", "after lunch", "tomorrow", "Friday"]
    subjects = ["maths", "physics", "computer science", "statistics", "English"]
    days = ["Monday", "Tuesday", "Thursday", "Friday"]
    rows = []
    for label, templates in [(0, safe_templates), (1, risk_templates)]:
        for i in range(per_template * len(templates)):
            template = templates[i % len(templates)]
            text = template.format(name=rng.choice(names), time=rng.choice(times), subject=rng.choice(subjects), day=rng.choice(days))
            # Small benign context variations; no explicit or graphic material.
            prefix = rng.choice(["", "Please, ", "Hi, ", "Honestly, ", "Kal, "])
            suffix = rng.choice(["", " please.", " right now.", " thanks.", " I mean it."])
            rows.append((prefix + text + suffix, label))
    rng.shuffle(rows)
    return rows


def make_url_rows(seed=73, per_template=80):
    rng = random.Random(seed)
    benign = [
        "https://example.com/article/{n}", "https://www.wikipedia.org/wiki/{slug}",
        "https://docs.python.org/3/library/{slug}.html", "https://university.edu.pk/student-portal/{n}",
        "https://shop.example.com/products/{slug}", "https://developer.android.com/guide/{slug}",
        "https://www.mozilla.org/en-US/{slug}/", "https://news.example.org/world/{n}",
        "https://support.example.com/help/{slug}", "https://school.example.edu.pk/timetable?term={n}"
    ]
    risky = [
        "http://198.51.100.{ip}/verify-account/login?session={n}",
        "http://{word}-account-check-{n}.example.test/login?verify={n}",
        "https://secure-{word}-update.example.test/confirm-password/{n}",
        "http://claim-bonus-gift.example.test/wallet?code={n}",
        "http://bank-support-{n}.example.test/signin/verify?account={n}",
        "https://{word}-{word}-{n}.example.test/free-reward/claim?token={n}",
        "http://example.test@198.51.100.{ip}/secure-login", 
        "http://xn--{word}-{n}.example.test/update?password={n}",
        "http://verify.account.{word}.{n}.example.test/login//continue"
    ]
    words = ["secure", "account", "gift", "wallet", "support", "verify", "member", "bonus", "signin", "update"]
    slugs = ["getting-started", "student-resources", "release-notes", "privacy-policy", "lesson-plans", "product-guide"]
    rows = []
    for label, templates in [(0, benign), (1, risky)]:
        for i in range(per_template * len(templates)):
            t = templates[i % len(templates)]
            url = t.format(n=rng.randint(100, 999999), slug=rng.choice(slugs), word=rng.choice(words), ip=rng.randint(1, 254))
            rows.append((url, label))
    rng.shuffle(rows)
    return rows


def save_csv(path: pathlib.Path, header, rows):
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)


def evaluate(y_true, y_pred):
    precision, recall, f1, _ = precision_recall_fscore_support(y_true, y_pred, average="binary", zero_division=0)
    return {
        "accuracy_synthetic_holdout": round(float(accuracy_score(y_true, y_pred)), 4),
        "precision_synthetic_holdout": round(float(precision), 4),
        "recall_synthetic_holdout": round(float(recall), 4),
        "f1_synthetic_holdout": round(float(f1), 4),
        "confusion_matrix": confusion_matrix(y_true, y_pred).tolist(),
        "warning": "Metrics are from generated synthetic examples, not a representative real-world validation set."
    }


def export_model(model, input_size, filename, description):
    coef = model.coef_[0].astype(np.float32)
    intercept = float(model.intercept_[0])
    weights = np.zeros((2, input_size), dtype=np.float32)
    bias = np.asarray([0.0, intercept], dtype=np.float32)
    weights[1, :] = coef
    target = OUT / filename
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(make_linear_tflite(weights, bias, input_size, description))
    return target


def main():
    random.seed(42)
    np.random.seed(42)
    DATA.mkdir(parents=True, exist_ok=True)
    OUT.mkdir(parents=True, exist_ok=True)

    text_rows = make_text_rows()
    save_csv(DATA / "synthetic_text_safety.csv", ["text", "label"], text_rows)
    xt = np.stack([text_features(text) for text, _ in text_rows])
    yt = np.asarray([label for _, label in text_rows], dtype=np.int32)
    xtr, xte, ytr, yte = train_test_split(xt, yt, test_size=0.2, random_state=42, stratify=yt)
    text_model = LogisticRegression(C=2.0, max_iter=1000, class_weight="balanced", random_state=42)
    text_model.fit(xtr, ytr)
    text_pred = text_model.predict(xte)
    text_smoke_input = xte[0].astype(float).tolist()
    text_logits = np.asarray([0.0, float(xte[0] @ text_model.coef_[0] + text_model.intercept_[0])], dtype=np.float32)
    text_metrics = evaluate(yte, text_pred)
    text_metrics.update({"training_rows": int(len(xtr)), "test_rows": int(len(xte)), "input_shape": [1, TEXT_DIM],
                         "output": ["benign_candidate_logit", "risk_flag_logit"],
                         "labels": {"0": "benign candidate", "1": "potential bullying, threat, or scam"},
                         "training_data": "synthetic_text_safety.csv"})
    (OUT / "text_safety.tflite").write_bytes(make_linear_tflite(
        np.vstack([np.zeros(TEXT_DIM, np.float32), text_model.coef_[0].astype(np.float32)]),
        np.asarray([0.0, float(text_model.intercept_[0])], dtype=np.float32),
        TEXT_DIM, "NEXAS AI synthetic-seed text risk linear classifier; logits output."))
    (OUT / "text_safety_metrics.json").write_text(json.dumps(text_metrics, indent=2), encoding="utf-8")
    (OUT / "text_model_config.json").write_text(json.dumps({"input_shape": [1, TEXT_DIM], "feature": "FNV-1a token hashing", "vocab_size": TEXT_DIM, "threshold": 0.70, "output": "raw logits; apply softmax", "purpose": "bullying/threat/scam screening prototype"}, indent=2), encoding="utf-8")

    url_rows = make_url_rows()
    save_csv(DATA / "synthetic_url_risk.csv", ["url", "label"], url_rows)
    xu = np.asarray([url_features(url) for url, _ in url_rows], dtype=np.float32)
    yu = np.asarray([label for _, label in url_rows], dtype=np.int32)
    xtr, xte, ytr, yte = train_test_split(xu, yu, test_size=0.2, random_state=42, stratify=yu)
    url_model = LogisticRegression(C=2.0, max_iter=1000, class_weight="balanced", random_state=42)
    url_model.fit(xtr, ytr)
    url_pred = url_model.predict(xte)
    url_smoke_input = xte[0].astype(float).tolist()
    url_logits = np.asarray([0.0, float(xte[0] @ url_model.coef_[0] + url_model.intercept_[0])], dtype=np.float32)
    url_metrics = evaluate(yte, url_pred)
    url_metrics.update({"training_rows": int(len(xtr)), "test_rows": int(len(xte)), "input_shape": [1, 20],
                        "feature_order": ["url_length", "host_length", "path_length", "query_length", "dot_count", "hyphen_count", "digit_ratio", "special_ratio", "https", "ip_host", "punycode", "at_sign", "fragment", "port", "subdomain_depth", "suspicious_terms", "path_slashes", "double_slash_path", "host_entropy", "shortener"],
                        "output": ["benign_candidate_logit", "risk_flag_logit"],
                        "labels": {"0": "benign candidate", "1": "suspicious URL pattern"},
                        "training_data": "synthetic_url_risk.csv"})
    (OUT / "url_risk.tflite").write_bytes(make_linear_tflite(
        np.vstack([np.zeros(20, np.float32), url_model.coef_[0].astype(np.float32)]),
        np.asarray([0.0, float(url_model.intercept_[0])], dtype=np.float32),
        20, "NEXAS AI synthetic-seed URL risk linear classifier; logits output."))
    (OUT / "url_risk_metrics.json").write_text(json.dumps(url_metrics, indent=2), encoding="utf-8")

    sync_hashes()  # Keep runtime SHA pins and the manifest aligned with regenerated weights.

    smoke = {
        "text": {"input": text_smoke_input, "expected_logits": text_logits.astype(float).tolist()},
        "url": {"input": url_smoke_input, "expected_logits": url_logits.astype(float).tolist()}
    }
    (OUT / "smoke_test_vectors.json").write_text(json.dumps(smoke), encoding="utf-8")

    summary = {
        "model_bundle_version": "0.3.1",
        "trained_models": ["text_safety.tflite", "url_risk.tflite"],
        "training_method": "scikit-learn LogisticRegression converted to a single TFLite FULLY_CONNECTED op",
        "validation": "synthetic holdout only; no real-world benchmark",
        "artifact_validation": "FlatBuffer structure and embedded fully-connected weight smoke tests passed; LiteRT interpreter and Android runtime were not available in this environment",
        "assets": {
            "text_safety.tflite": {"bytes": (OUT / "text_safety.tflite").stat().st_size, "metrics": "text_safety_metrics.json"},
            "url_risk.tflite": {"bytes": (OUT / "url_risk.tflite").stat().st_size, "metrics": "url_risk_metrics.json"},
            "smoke_test_vectors.json": {"bytes": (OUT / "smoke_test_vectors.json").stat().st_size, "purpose": "embedded weight consistency test"},
        },
        "production_notice": "Do not use synthetic seed models as a reliable protection boundary. Replace or fine-tune using lawful, representative labelled datasets and evaluate false positives/negatives on held-out real data."
    }
    (TOOLKIT_ROOT / "TRAINING_REPORT.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps({"text": text_metrics, "url": url_metrics, "assets": summary["assets"]}, indent=2))

if __name__ == "__main__":
    main()
