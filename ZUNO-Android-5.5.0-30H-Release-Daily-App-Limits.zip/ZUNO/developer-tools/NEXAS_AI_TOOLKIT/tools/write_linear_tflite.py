#!/usr/bin/env python3
"""Minimal FlatBuffer writer for a single FLOAT32 FULLY_CONNECTED TFLite graph.

This writes a deliberately small, dependency-free TFLite model for linear
classifiers. Validate with the LiteRT/TFLite interpreter on the target runtime
before shipping; this helper is scoped to the exact model schema emitted here.
"""
from __future__ import annotations
import struct
from typing import Callable, Iterable

class FlatBuffer:
    def __init__(self) -> None:
        self.buf = bytearray(b"\x00\x00\x00\x00TFL3")

    def _pad_content(self, alignment: int) -> None:
        # FlatBuffers vectors put their length prefix immediately before the
        # contents; align the first element, not just the length prefix.
        target = (len(self.buf) + 4 + alignment - 1) // alignment * alignment
        start = target - 4
        if start < len(self.buf):
            start += alignment
        self.buf.extend(b"\x00" * (start - len(self.buf)))

    def scalar_vector(self, values: Iterable[int], fmt: str = "i") -> int:
        vals = list(values)
        size = struct.calcsize("<" + fmt)
        self._pad_content(max(4, size))
        pos = len(self.buf)
        self.buf.extend(struct.pack("<I", len(vals)))
        for value in vals:
            self.buf.extend(struct.pack("<" + fmt, value))
        return pos

    def byte_vector(self, data: bytes, force_alignment: int = 1) -> int:
        self._pad_content(max(4, force_alignment))
        pos = len(self.buf)
        self.buf.extend(struct.pack("<I", len(data)))
        self.buf.extend(data)
        return pos

    def string(self, value: str) -> int:
        raw = value.encode("utf-8")
        self._pad_content(4)
        pos = len(self.buf)
        self.buf.extend(struct.pack("<I", len(raw)))
        self.buf.extend(raw)
        self.buf.append(0)
        return pos

    def table(self, field_count: int, fields: dict[int, tuple[str, object]]) -> int:
        """Write a table; scalar formats: b/B/i/I/?; child field format: o."""
        cursor = 4  # signed vtable offset at the beginning of the table
        offsets = [0] * field_count
        positions: dict[int, int] = {}
        child_fields: list[int] = []
        for index in range(field_count):
            if index not in fields:
                continue
            fmt, _value = fields[index]
            if fmt == "o":
                alignment, size = 4, 4
            else:
                size = struct.calcsize("<" + fmt)
                alignment = min(size, 4)
            cursor = (cursor + alignment - 1) // alignment * alignment
            offsets[index] = cursor
            positions[index] = cursor
            cursor += size
            if fmt == "o":
                child_fields.append(index)
        object_size = (cursor + 3) // 4 * 4
        vtable_size = 4 + 2 * field_count
        if len(self.buf) % 2:
            self.buf.append(0)
        vtable_pos = len(self.buf)
        self.buf.extend(struct.pack("<HH", vtable_size, object_size))
        for offset in offsets:
            self.buf.extend(struct.pack("<H", offset))
        while len(self.buf) % 4:
            self.buf.append(0)
        table_pos = len(self.buf)
        self.buf.extend(b"\x00" * object_size)
        struct.pack_into("<i", self.buf, table_pos, table_pos - vtable_pos)
        for index, (fmt, value) in fields.items():
            field_pos = table_pos + positions[index]
            if fmt == "o":
                continue
            struct.pack_into("<" + fmt, self.buf, field_pos, value)
        for index in child_fields:
            field_pos = table_pos + positions[index]
            writer = fields[index][1]
            target = writer()
            if target <= field_pos:
                raise ValueError("FlatBuffer offsets must point forward")
            struct.pack_into("<I", self.buf, field_pos, target - field_pos)
        return table_pos

    def table_vector(self, writers: list[Callable[[], int]]) -> int:
        self._pad_content(4)
        pos = len(self.buf)
        self.buf.extend(struct.pack("<I", len(writers)))
        slots = []
        for _ in writers:
            slots.append(len(self.buf))
            self.buf.extend(b"\x00\x00\x00\x00")
        for slot, writer in zip(slots, writers):
            target = writer()
            if target <= slot:
                raise ValueError("FlatBuffer vector offsets must point forward")
            struct.pack_into("<I", self.buf, slot, target - slot)
        return pos


def make_linear_tflite(weights, bias, input_size: int, description: str) -> bytes:
    """Create a FLOAT32 [1,input_size] -> [1,2] FC model; weights shape [2,input_size]."""
    import numpy as np
    w = np.asarray(weights, dtype="<f4").reshape(2, input_size)
    b = np.asarray(bias, dtype="<f4").reshape(2)
    fb = FlatBuffer()

    def tensor(shape, name, buffer_index):
        def build():
            fields = {
                0: ("o", lambda: fb.scalar_vector(shape, "i")),
                1: ("b", 0),             # TensorType.FLOAT32
                2: ("I", buffer_index),
                3: ("o", lambda: fb.string(name)),
            }
            return fb.table(8, fields)
        return build

    def fc_options():
        # FullyConnectedOptions: default NONE activation, DEFAULT weight format,
        # keep_num_dims=false, asymmetric_quantize_inputs=false.
        return fb.table(5, {})

    def operator():
        return fb.table(5, {
            0: ("I", 0),
            1: ("o", lambda: fb.scalar_vector([0, 1, 2], "i")),
            2: ("o", lambda: fb.scalar_vector([3], "i")),
            3: ("B", 8),  # BuiltinOptions.FullyConnectedOptions
            4: ("o", fc_options),
        })

    def subgraph():
        tensors = [
            tensor([1, input_size], "input", 0),
            tensor([2, input_size], "weights", 1),
            tensor([2], "bias", 2),
            tensor([1, 2], "logits", 0),
        ]
        return fb.table(5, {
            0: ("o", lambda: fb.table_vector(tensors)),
            1: ("o", lambda: fb.scalar_vector([0], "i")),
            2: ("o", lambda: fb.scalar_vector([3], "i")),
            3: ("o", lambda: fb.table_vector([operator])),
            4: ("o", lambda: fb.string("main")),
        })

    def op_code():
        # FULLY_CONNECTED=9. Deprecated int8 code is retained for old readers;
        # current schemas also read builtin_code as int32.
        return fb.table(4, {
            0: ("b", 9),
            2: ("i", 1),
            3: ("i", 9),
        })

    def buffer(data: bytes, alignment: int = 1):
        return fb.table(1, {0: ("o", lambda: fb.byte_vector(data, alignment))})

    root = fb.table(5, {
        0: ("I", 3),
        1: ("o", lambda: fb.table_vector([op_code])),
        2: ("o", lambda: fb.table_vector([subgraph])),
        3: ("o", lambda: fb.string(description)),
        4: ("o", lambda: fb.table_vector([
            lambda: buffer(b""),
            lambda: buffer(w.tobytes(), 16),
            lambda: buffer(b.tobytes(), 16),
        ])),
    })
    struct.pack_into("<I", fb.buf, 0, root)
    return bytes(fb.buf)
