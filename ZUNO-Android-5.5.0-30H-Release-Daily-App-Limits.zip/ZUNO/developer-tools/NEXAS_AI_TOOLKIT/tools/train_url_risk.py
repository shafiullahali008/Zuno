#!/usr/bin/env python3
"""Train url_risk.tflite from labelled URL rows (url,label; 0=benign, 1=suspicious)."""
from __future__ import annotations
import json, pathlib, sys
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix
from train_seed_models import url_features
from write_linear_tflite import make_linear_tflite
from sync_model_hashes import sync_hashes



def find_project_root() -> pathlib.Path:
    """Find the VYRA root when this toolkit is nested under developer-tools/."""
    script = pathlib.Path(__file__).resolve()
    for parent in script.parents:
        if (parent / "settings.gradle").is_file() and (parent / "app/src/main/assets/models").is_dir():
            return parent
    raise RuntimeError("Could not locate the VYRA project root (expected settings.gradle and app/src/main/assets/models)")

TOOLKIT_ROOT = pathlib.Path(__file__).resolve().parents[1]
PROJECT_ROOT = find_project_root()

OUT = PROJECT_ROOT / "app/src/main/assets/models"


def main(csv_path: str) -> int:
    df = pd.read_csv(csv_path)
    if not {"url", "label"}.issubset(df.columns):
        raise ValueError("CSV must contain url,label columns")
    df = df.dropna(subset=["url", "label"])
    y = df.label.astype(int).to_numpy()
    if len(df) < 200 or set(np.unique(y)) != {0, 1}: raise ValueError("Need >=200 labelled rows and labels 0 and 1")
    x = np.asarray([url_features(u) for u in df.url], dtype=np.float32)
    xtr, xte, ytr, yte = train_test_split(x, y, test_size=0.2, random_state=42, stratify=y)
    model = LogisticRegression(C=2.0, max_iter=1500, class_weight="balanced", random_state=42)
    model.fit(xtr, ytr)
    pred = model.predict(xte)
    p, r, f, _ = precision_recall_fscore_support(yte, pred, average="binary", zero_division=0)
    weights = np.vstack([np.zeros(20, np.float32), model.coef_[0].astype(np.float32)])
    bias = np.asarray([0.0, float(model.intercept_[0])], dtype=np.float32)
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "url_risk.tflite").write_bytes(make_linear_tflite(weights, bias, 20, "NEXAS AI trained URL risk linear model; logits."))
    sync_hashes()  # Update the Java model pin and shared checksum manifest.
    metrics = {"training_rows": len(xtr), "test_rows": len(xte), "accuracy": float(accuracy_score(yte, pred)),
               "precision": float(p), "recall": float(r), "f1": float(f), "confusion_matrix": confusion_matrix(yte, pred).tolist(),
               "input_shape": [1,20], "labels": {"0":"benign candidate", "1":"suspicious"},
               "feature_order": ["url_length", "host_length", "path_length", "query_length", "dot_count", "hyphen_count", "digit_ratio", "special_ratio", "https", "ip_host", "punycode", "at_sign", "fragment", "port", "subdomain_depth", "suspicious_terms", "path_slashes", "double_slash_path", "host_entropy", "shortener"]}
    (OUT / "url_risk_metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(json.dumps(metrics, indent=2))
    return 0

if __name__ == "__main__":
    if len(sys.argv) != 2: raise SystemExit("Usage: python tools/train_url_risk.py path/to/urls.csv")
    raise SystemExit(main(sys.argv[1]))
