#!/usr/bin/env python3
"""Synchronize or verify SHA-256 pins for the generated text and URL TFLite assets.

Training scripts regenerate model weights. This tool keeps the Java runtime pins and
asset checksum manifest aligned, preventing freshly trained models from being rejected.
"""
from __future__ import annotations

import argparse
import hashlib
import pathlib
import re
import sys


def find_project_root() -> pathlib.Path:
    script = pathlib.Path(__file__).resolve()
    for parent in script.parents:
        if (parent / "settings.gradle").is_file() and (parent / "app/src/main/assets/models").is_dir():
            return parent
    raise RuntimeError("Could not locate VYRA project root")


PROJECT_ROOT = find_project_root()
MODELS = PROJECT_ROOT / "app/src/main/assets/models"
CHECKSUMS = MODELS / "MODEL_SHA256SUMS.txt"
TARGETS = {
    "text_safety.tflite": PROJECT_ROOT / "app/src/main/java/com/nexas/safe/NexasTextRiskModel.java",
    "url_risk.tflite": PROJECT_ROOT / "app/src/main/java/com/nexas/safe/NexasUrlRiskModel.java",
}


def sha256(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sync_hashes(check_only: bool = False) -> bool:
    computed: dict[str, str] = {}
    for name in TARGETS:
        model = MODELS / name
        if not model.is_file() or model.stat().st_size < 100:
            raise RuntimeError(f"Missing or incomplete model: {model}")
        with model.open("rb") as stream:
            header = stream.read(8)
        if len(header) != 8 or header[4:8] != b"TFL3":
            raise RuntimeError(f"Invalid TFLite signature: {model}")
        computed[name] = sha256(model)

    manifest_lines = CHECKSUMS.read_text(encoding="utf-8").splitlines()
    manifest_by_name: dict[str, str] = {}
    for line in manifest_lines:
        parts = line.split(maxsplit=1)
        if len(parts) == 2:
            manifest_by_name[pathlib.Path(parts[1].strip()).name] = parts[0]

    java_mismatches: list[str] = []
    updated_sources: dict[pathlib.Path, str] = {}
    for name, java_path in TARGETS.items():
        source = java_path.read_text(encoding="utf-8")
        pattern = re.compile(r'(private\s+static\s+final\s+String\s+SHA\s*=\s*")[0-9a-fA-F]{64}("\s*;)')
        replacement = rf'\g<1>{computed[name]}\2'
        updated, count = pattern.subn(replacement, source, count=1)
        if count != 1:
            raise RuntimeError(f"Could not find exactly one SHA-256 pin in {java_path}")
        if updated != source:
            java_mismatches.append(f"{java_path.relative_to(PROJECT_ROOT)}: SHA mismatch")
            updated_sources[java_path] = updated
        if manifest_by_name.get(name) != computed[name]:
            java_mismatches.append(f"MODEL_SHA256SUMS.txt: {name} checksum mismatch")

    if check_only:
        if java_mismatches:
            print("\n".join(java_mismatches), file=sys.stderr)
            return False
        print("Runtime SHA pins and MODEL_SHA256SUMS.txt are synchronized.")
        return True

    for path, content in updated_sources.items():
        temp = path.with_suffix(path.suffix + ".tmp")
        temp.write_text(content, encoding="utf-8")
        temp.replace(path)

    seen: set[str] = set()
    new_lines: list[str] = []
    for line in manifest_lines:
        parts = line.split(maxsplit=1)
        if len(parts) == 2:
            name = pathlib.Path(parts[1].strip()).name
            if name in computed:
                new_lines.append(f"{computed[name]}  {parts[1].strip()}")
                seen.add(name)
                continue
        new_lines.append(line)
    for name in TARGETS:
        if name not in seen:
            new_lines.append(f"{computed[name]}  {name}")
    CHECKSUMS.write_text("\n".join(new_lines).rstrip() + "\n", encoding="utf-8")
    print("Synchronized model hashes:")
    for name, digest in computed.items():
        print(f"  {name}: {digest}")
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="verify pins without modifying files")
    args = parser.parse_args()
    try:
        return 0 if sync_hashes(check_only=args.check) else 1
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
