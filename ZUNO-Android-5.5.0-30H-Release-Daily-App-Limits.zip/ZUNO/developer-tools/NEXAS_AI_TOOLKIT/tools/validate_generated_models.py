#!/usr/bin/env python3
"""Structural sanity checks for the hand-built TFLite FlatBuffers.

This checks the TFL3 identifier, root/subgraph/tensor/op/buffer offsets, and
embedded float constants. It does not replace running a LiteRT interpreter.
"""
from __future__ import annotations
import json, pathlib, struct, sys
import numpy as np



def find_project_root() -> pathlib.Path:
    """Find the VYRA root when this toolkit is nested under developer-tools/."""
    script = pathlib.Path(__file__).resolve()
    for parent in script.parents:
        if (parent / "settings.gradle").is_file() and (parent / "app/src/main/assets/models").is_dir():
            return parent
    raise RuntimeError("Could not locate the VYRA project root (expected settings.gradle and app/src/main/assets/models)")

TOOLKIT_ROOT = pathlib.Path(__file__).resolve().parents[1]
PROJECT_ROOT = find_project_root()

MODELS = PROJECT_ROOT / "app/src/main/assets/models"

def u16(b, p): return struct.unpack_from("<H", b, p)[0]
def u32(b, p): return struct.unpack_from("<I", b, p)[0]
def i32(b, p): return struct.unpack_from("<i", b, p)[0]
def table_field(b, table, field):
    vtable = table - i32(b, table)
    vsize = u16(b, vtable)
    entry = vtable + 4 + field * 2
    if entry + 2 > vtable + vsize: return 0
    off = u16(b, entry)
    return table + off if off else 0
def target(b, field_pos): return field_pos + u32(b, field_pos)
def vector_items(b, vector_pos):
    n = u32(b, vector_pos)
    return [vector_pos + 4 + 4 * i for i in range(n)]
def vector_uoffset_targets(b, vector_pos): return [target(b, p) for p in vector_items(b, vector_pos)]
def read_string(b, pos):
    n = u32(b, pos)
    return b[pos+4:pos+4+n].decode("utf-8")

def validate(path, expected_input):
    b = path.read_bytes()
    assert b[4:8] == b"TFL3", f"{path.name}: missing TFL3 file identifier"
    root = u32(b, 0)
    assert 8 <= root < len(b)
    # Model.version and root vectors.
    version_pos = table_field(b, root, 0)
    assert version_pos and u32(b, version_pos) == 3
    opcodes_pos = target(b, table_field(b, root, 1))
    subgraphs_pos = target(b, table_field(b, root, 2))
    buffers_pos = target(b, table_field(b, root, 4))
    assert u32(b, opcodes_pos) == 1 and u32(b, subgraphs_pos) == 1 and u32(b, buffers_pos) == 3
    opcode = vector_uoffset_targets(b, opcodes_pos)[0]
    builtin_pos = table_field(b, opcode, 3)
    assert builtin_pos and struct.unpack_from("<i", b, builtin_pos)[0] == 9
    sg = vector_uoffset_targets(b, subgraphs_pos)[0]
    tensors_pos = target(b, table_field(b, sg, 0))
    inputs_pos = target(b, table_field(b, sg, 1))
    outputs_pos = target(b, table_field(b, sg, 2))
    ops_pos = target(b, table_field(b, sg, 3))
    tensors = vector_uoffset_targets(b, tensors_pos)
    assert len(tensors) == 4
    tensor_shapes = []
    for tensor in tensors:
        sh = target(b, table_field(b, tensor, 0))
        count = u32(b, sh)
        tensor_shapes.append([struct.unpack_from("<i", b, sh + 4 + 4*j)[0] for j in range(count)])
    assert tensor_shapes[0] == [1, expected_input], tensor_shapes
    assert tensor_shapes[1] == [2, expected_input], tensor_shapes
    assert tensor_shapes[2] == [2] and tensor_shapes[3] == [1, 2], tensor_shapes
    assert u32(b, inputs_pos) == 1 and struct.unpack_from("<i", b, inputs_pos+4)[0] == 0
    assert u32(b, outputs_pos) == 1 and struct.unpack_from("<i", b, outputs_pos+4)[0] == 3
    op = vector_uoffset_targets(b, ops_pos)[0]
    in_vec = target(b, table_field(b, op, 1))
    out_vec = target(b, table_field(b, op, 2))
    assert [struct.unpack_from("<i", b, p)[0] for p in vector_items(b, in_vec)] == [0,1,2]
    assert [struct.unpack_from("<i", b, p)[0] for p in vector_items(b, out_vec)] == [3]
    union_type_pos = table_field(b, op, 3)
    assert union_type_pos and b[union_type_pos] == 8
    buffers = vector_uoffset_targets(b, buffers_pos)
    data_vecs = [target(b, table_field(b, buf, 0)) for buf in buffers]
    assert u32(b, data_vecs[1]) == 2 * expected_input * 4
    assert u32(b, data_vecs[2]) == 2 * 4
    weights = np.frombuffer(b, dtype="<f4", count=2 * expected_input, offset=data_vecs[1] + 4).reshape(2, expected_input)
    bias = np.frombuffer(b, dtype="<f4", count=2, offset=data_vecs[2] + 4)
    return {"file": path.name, "bytes": len(b), "input": [1, expected_input], "output": [1,2],
            "structural_check": "passed", "weights": weights, "bias": bias}

def main():
    results = [
        validate(MODELS / "text_safety.tflite", 512),
        validate(MODELS / "url_risk.tflite", 20),
    ]
    smoke = json.loads((MODELS / "smoke_test_vectors.json").read_text(encoding="utf-8"))
    for key, result in zip(("text", "url"), results):
        x = np.asarray(smoke[key]["input"], dtype=np.float32)
        expected = np.asarray(smoke[key]["expected_logits"], dtype=np.float32)
        got = result["weights"] @ x + result["bias"]
        assert np.allclose(got, expected, rtol=1e-4, atol=1e-4), f"{key}: embedded model weights failed smoke test: {got} vs {expected}"
        result.pop("weights")
        result.pop("bias")
        result["embedded_weight_smoke_test"] = "passed"
    print(results)

if __name__ == "__main__": main()
