@echo off
setlocal
cd /d %~dp0
where py >nul 2>nul
if errorlevel 1 (
  echo Python Launcher was not found. Install Python 3.11 or 3.12 first.
  pause
  exit /b 1
)
py -3.11 -c "import sys" >nul 2>nul
if not errorlevel 1 (
  set PYVER=3.11
) else (
  py -3.12 -c "import sys" >nul 2>nul
  if errorlevel 1 (
    echo Install Python 3.11 or 3.12 first.
    pause
    exit /b 1
  )
  set PYVER=3.12
)
py -%PYVER% -m pip install -r requirements-training.txt
if errorlevel 1 goto fail
py -%PYVER% tools\train_seed_models.py
if errorlevel 1 goto fail
py -%PYVER% tools\validate_generated_models.py
if errorlevel 1 goto fail
echo Trained prototype TFLite files are in app\src\main\assets\models.
pause
exit /b 0
:fail
echo Training failed. See the error above.
pause
exit /b 1
