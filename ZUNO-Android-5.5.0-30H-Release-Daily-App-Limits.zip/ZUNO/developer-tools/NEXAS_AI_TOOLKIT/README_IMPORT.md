# NEXAS AI model toolkit

This folder contains the NEXAS text/URL model training scripts, synthetic seed data, hash synchronizer and model validator. It is developer tooling only; it is not a second Android app and is not part of the Android Gradle runtime.

The `text_safety.tflite` and `url_risk.tflite` model files are in `app/src/main/assets/models/` and are used by ZUNO's NEXAS Java adapters. Both are synthetic-seed prototypes and their live output is advisory only.

Only these two NEXAS-owned TFLite models are part of the Android app. The toolkit does not include third-party model download/provisioning scripts.
