# VYRA 4.2.2 — Build and source audit revision

- Incremented Android app version to 4.2.2 (versionCode 17).
- Removed duplicated/stale workflow copies from the app project.
- Added one canonical reference workflow with current GitHub Actions major versions.
- Separated APK assembly and unit tests so a test-only failure cannot suppress a successfully built APK.
- Added CI log artifacts so a future Android compile failure can be diagnosed from the actual Gradle message.
- Reduced Gradle parallelism and heap allocation for more predictable CI memory use.
- Existing app UI, focus, protection, image scanning, local classifiers, assets and games are retained.

This revision is statically audited, but an Android SDK build and device test are still required.
