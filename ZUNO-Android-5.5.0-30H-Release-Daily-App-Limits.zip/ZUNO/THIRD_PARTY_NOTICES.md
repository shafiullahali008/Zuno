# Third-party notices

The Android app uses TensorFlow Lite for on-device inference of the bundled NEXAS Text Safety and URL Risk models. The model weights and training assets are part of the NEXAS AI project files. Their current training data is synthetic/prototype-level; they are not validated as production safety classifiers.

No imported third-party blocker code, model weights, adult-domain hash list, or imported keyword hash list is included in this cleaned source package.
