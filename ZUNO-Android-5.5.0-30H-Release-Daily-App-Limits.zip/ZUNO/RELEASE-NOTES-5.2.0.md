# ZUNO 5.2.0 — Dashboard, Focus Clarity and Prayer Reliability

## Home dashboard
- Replaced the long home list with a compact status card, quick controls and three workspace shortcuts.
- Added working ON/OFF switches for NEXAS text protection and automatic Azan.
- Kept the full prayer timetable, Qibla, calendar and prayer checklist in the dedicated Prayer & Calendar screen.

## Focus and permissions
- Clarified the active-session end control as `END SESSION / SAFETY EXIT`.
- Strict mode keeps its deliberate confirmation step. Android Accessibility and Device Admin remain user-controlled system permissions; ZUNO does not hijack Android Settings or trap users away from system controls.

## Azan scheduling
- Uses exact `setExactAndAllowWhileIdle` alarms when Android grants exact-alarm access.
- Keeps a clearly identified inexact fallback when exact-alarm access is unavailable; Android may defer these alarms during Doze.
- Gives each prayer/date a distinct PendingIntent data URI, reducing alarm identity collisions.
- Records the most recent prayer trigger and scheduler errors for in-app diagnostics.
- Re-checks scheduling on app open, device boot, time changes and exact-alarm permission changes.

## Prayer checklist refresh
- Each day's checklist uses a date-specific key, so it naturally starts fresh at local midnight while previous days remain available for streak calculations.

## Important Android limits
- Exact prayer-time delivery requires the user to grant Android's exact-alarm access where required. Android 14+ does not pre-grant this access to many newly installed apps.
- Notification permission, alarm volume, Do Not Disturb and OEM battery restrictions can affect audible playback. ZUNO cannot guarantee playback when Android or the user blocks it.
- The build was not compiled in this container because the Gradle distribution host was unreachable. Run the repository's GitHub Actions workflow to perform the Android build.
