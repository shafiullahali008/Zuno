# VYRA 4.2.3 — Full source audit revision

## App identity
- Android versionName: 4.2.3
- Android versionCode: 18
- Application ID remains `com.nexas.safe` for package compatibility.

## Fixes
- Corrected the Android SDK workflow input: `setup-android` receives one package name; Android 35 and Build Tools are installed via separate `sdkmanager --install` calls with retries.
- Reordered CI so ZIP extraction happens before Gradle setup, allowing the Gradle action to detect the project build files.
- Split APK assembly and unit tests; a successful APK is uploaded before unit-test status is evaluated.
- Added diagnostic artifact upload for Gradle assembly and test logs.
- Fixed visual detection block-screen cooldown ordering and the first-event uptime edge case.
- Capped the visual capture surface at 960 pixels on its longest dimension.
- Replaced padded ImageReader bitmap copying with row-stride-aware RGBA copying to avoid buffer underflow on padded rows.
- Stop live screen scanning if the user revokes VYRA Accessibility permission during the session.
- Reused TFLite input/output buffers and validated one-input/one-output model tensor shapes and data types; buffer allocation failures now close the interpreter and release partial resources.
- Included the exposed male-chest signal class in the configured visual-filter class list.
- Moved custom block-screen image decoding off the UI thread and downsampled images before display.
- Improved model-file replacement so a failed move does not delete a previously valid model first.
- Fixed GL renderer state visibility and queued renderer mutations on the GL thread; remove UI ticker callbacks when Arcade activity is destroyed.
- Added visible error handling if Android refuses to start the MediaProjection foreground service.

## Verification completed
- Archive integrity check.
- Java parser: all 15 Java source files parsed with zero syntax diagnostics.
- XML parser: all 11 Android XML files parsed.
- Manifest component-to-source checks.
- Resource reference check (system `android.R` references excluded).
- Classifier unit tests: all 8 tests passed in a local Java harness.
- Workflow YAML and embedded Bash blocks parsed; package argument separation, action order and expected ZIP/workflow paths checked.
- CI workflow action ordering and SDK package arguments reviewed against actual failed GitHub job logs.

## Verification not completed
- Full Android Gradle compilation / APK assembly.
- Android SDK resource linking / D8 / packaging through AGP.
- Physical-device testing, memory profiling, screen-capture permission testing, and detector accuracy/latency tests.

These cannot be inferred from Java syntax parsing or pure-Java classifier tests. GitHub Actions and a real Android device are still required to validate the final APK.


## Post-audit compiler corrections — 2026-11-25

The GitHub Actions job `139055111313` reached `:app:compileDebugJavaWithJavac` and reported 10 diagnostics from four source statements in `MainActivity.java`. The statements at the visual-protection UI (lines 512, 514 and 517) declared `LinearLayout` variables for values returned by helpers that actually return `LinearLayout.LayoutParams`. Those declarations now use `LinearLayout.LayoutParams`. The inactive-journey calculation now adds the saved elapsed-millisecond value with `ZonedDateTime.plus(Duration.ofMillis(savedDuration))`; `savedDuration` is stored in milliseconds when a journey ends.

The reference CI workflow now also checks that `MainActivity.java` exists after ZIP extraction. The existing Gradle 8.9 / Android Gradle Plugin 8.7.3 / JDK 17 / SDK 35 configuration is retained because the failed job successfully completed project configuration, dependency resolution, resource processing and duplicate-class checks before Java compilation.

**Verification boundary:** the source corrections are applied, and archive/static checks are run when packaging this revision. A new GitHub Actions build has not yet run against this revised ZIP, so APK assembly, unit-test execution, D8 and final APK creation remain unverified.
