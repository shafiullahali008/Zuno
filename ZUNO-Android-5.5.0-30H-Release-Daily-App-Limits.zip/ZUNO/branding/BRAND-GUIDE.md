# VYRA Light Brand System

- Primary canvas: porcelain `#F6F8FB`
- Surfaces: white `#FFFFFF`
- Main text: ink `#1C2739`
- Secondary text: slate `#67758A`
- Primary accent: deep teal `#277D8D`
- Secondary accent: muted violet `#6F59B7`
- Support accent: warm amber `#A87022`
- Borders: cool grey `#DCE2EB`

The refreshed mark uses a compact shield silhouette with a white V monogram and a restrained aqua highlight. UI surfaces use rounded corners, restrained elevation, motion on navigation and short micro-interactions. Avoid neon gradients, dark canvases and excessive glass effects.
