# Prayer Module Implementation and Verification — VYRA 4.7.0

## Package changes
- New `PrayerActivity.java` UI reachable from the MainActivity Home quick-access list.
- New `ShiaPrayerCalculator.java` offline astronomical calculation engine.
- New `PrayerPrefs.java`, `PrayerScheduler.java`, `PrayerAlarmReceiver.java`, `PrayerNotifications.java`, `PrayerStopReceiver.java`, and `PrayerAzanService.java`.
- New uploaded default audio asset `app/src/main/assets/azan_default.mp3`.
- Added location, foreground media playback, wake-lock, and media playback service declarations in AndroidManifest.
- BootReceiver now re-schedules prayer alarms after boot/time/time-zone/exact-alarm permission events.
- App version updated to 4.7.0 / versionCode 25.
- Added `ShiaPrayerCalculatorTest.java` unit tests.

## Shia prayer method presets
| Preset | Fajr | Maghrib | Isha | Asr |
|---|---:|---:|---:|---|
| Jafari/Qom default | 16° | 4° | 14° | Shadow factor 1 |
| University of Tehran | 17.7° | 4.5° | 14° | Shadow factor 1 |
| Islamic Centre of England | 15° | Sunset + 15 min | 14° | Shadow factor 1 |

The calculation engine uses local device time-zone offset, solar declination, equation of time, longitude, sunrise/sunset altitude, and the standard shadow-factor-1 Asr calculation. It offers angle-based fallbacks where a solar angle is unreachable at high latitudes. The Jafari midnight estimate is the midpoint between current Maghrib and next Fajr. Users can apply up to ±30 minutes per prayer/sunrise and a ±2-day Hijri adjustment.

## Prayer and calendar functionality
- 5 daily prayer times and next-prayer HH:MM:SS countdown.
- Ramadan daily Fajr/Sehri and Maghrib/Iftar countdowns; outside Ramadan the UI labels these as next Fajr/Maghrib.
- Qibla bearing from selected coordinates, with sensor heading when both accelerometer and magnetometer are available.
- Hijri calendar month grid, listed Shia observances and countdowns, user-defined future date countdown.
- Per-prayer checkmarks and streaks based on days where all five prayers have been marked complete.
- Per-prayer/global Azan configuration, default audio preview, replacing audio via Android Storage Access Framework, and restoring the bundled recording.
- Prayer alarms scheduled for the next three days, refreshed after prayer trigger, app resume, boot, clock/time-zone changes and exact-alarm permission state changes. Prayer times are cached and recalculated only when date, time zone, location, method or offsets change.
- Foreground media player and public lock-screen notification with a Stop Azan action.

## Verification performed
- Parsed all 37 Java source/test files with JDK compiler parser: zero syntax errors. Added a missing Android `Color` import discovered during source review.
- Parsed all Android XML resources and manifest: 12 files passed.
- Compiled the pure Java prayer calculator with JDK 21.
- Ran a local harness against Wah Cantt approximate coordinates across five seasonal dates and all three presets (15 date/method combinations); all six calculated times were chronologically ordered.
- Checked the Jafari midnight result lies after Maghrib and before next Fajr.
- Verified prayer offsets change the requested time by the configured minute count (unit test added).
- Inspected uploaded MP3 metadata: MPEG Layer III, 44.1 kHz, stereo, duration 333.61 seconds.
- Added unit tests for time ordering, minute offsets, and Jafari midnight. Fixed and re-tested equation-of-time wrap-around observed near the March equinox.

## Not verified here
- Full Android Gradle compile/test/APK assembly: not run. `./gradlew --no-daemon tasks --offline` attempted to fetch Gradle 8.9 and failed because `services.gradle.org` DNS/network access is unavailable; no Android SDK is installed in this environment.
- Real Android 16 tests for exact alarm access, background service start, notification action, audio focus, locked-screen playback, app standby, and OEM power management are pending.
- Prayer accuracy is not certified by a Marja or local mosque. The default Wah Cantt location is approximate. Users should select their actual location and compare with a trusted Shia timetable.

## Android delivery requirements
- `POST_NOTIFICATIONS` permission is needed for visible notification controls.
- `SCHEDULE_EXACT_ALARM` special access is needed for exact-time delivery on modern Android. Without it, the code falls back to `setAndAllowWhileIdle` and Android may delay alarms.
- The app cannot override Do Not Disturb, system volume, user force-stop, device power policy, manufacturer restrictions or Android's own process management.


## Uploaded Azan asset integrity
- Source upload: `Best-Azan-in-the-world.MP3`
- Bundled path: `app/src/main/assets/azan_default.mp3`
- SHA-256: `b63875f3d82ee3df7b99e07e42b7698afd7b12b4937140e9af9fa06ae5cb9f55`
- Audio metadata: MP3, 44.1 kHz, stereo, 333.61 seconds.

## Final source-validation status (2026-11-25)
- Re-parsed all 37 Java source/test files after final edits: 0 syntax errors.
- Parsed all 12 Android XML files; checked required notification, exact-alarm, boot, location, wake-lock and media-playback permissions plus prayer Activity/service/receiver registrations.
- Re-ran the standalone Java prayer-calculation harness: 15 seasonal-date/preset combinations passed, along with chronological ordering, Jafari midnight range, minute offsets and finite high-latitude values.
- Verified SHA-256 manifests for all three bundled TFLite models.
- Verified that the bundled Azan asset SHA-256 matches the uploaded audio and that the audio remains a 44.1 kHz stereo MP3 with a 333.61-second duration.
- Re-attempted `./gradlew --no-daemon testDebugUnitTest assembleDebug --offline`; Gradle wrapper could not obtain Gradle 8.9 because `services.gradle.org` could not resolve in this environment. An Android SDK is also not installed here, so no APK or real-device test is claimed.
- Added Android 15/16 edge-to-edge insets to the prayer screen, cached daily calculations, and safe audio replacement rollback.
