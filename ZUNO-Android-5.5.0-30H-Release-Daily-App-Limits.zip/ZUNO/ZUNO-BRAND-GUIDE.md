# ZUNO Brand Guide

**Full product name:** ZUNO — Islamic Wellness & Digital Protection

The user-provided ZUNO mosque/crescent logo is the primary app and launcher identity.

## Palette
- Midnight black: `#101012`
- Charcoal surface: `#211F1D`
- Warm gold: `#DDB56B`
- Soft ivory: `#F5E8D0`
- Muted warm stone: `#BEB195`

## Visual direction
Dark Islamic-inspired surfaces, restrained gold dividers, crescent/mosque identity, ivory typography, and readable contrast. Avoid teal/purple gradients and cool white cards.

## Compatibility
The Android application ID remains `com.nexas.safe` to preserve upgrade compatibility, local data, permissions and existing installations. Internal Java class names and legacy preference/channel IDs remain unchanged; all user-visible branding is ZUNO.
