# VYRA 4.7.0 — Shia Prayer, Azan and Islamic Calendar

## Added
- Home shortcut to the Prayer & Islamic Calendar activity.
- Offline Jafari/Qom solar calculation preset (Fajr 16°, Maghrib 4°, Isha 14°; Asr shadow factor 1), plus Tehran and Islamic Centre of England presets.
- Local prayer-time offsets, location selection by device location or manual coordinates, and Wah Cantt approximate fallback.
- Five prayer-time rows, upcoming prayer countdown, Fajr/Sehri countdown, Maghrib/Iftar countdown and Jafari midpoint Islamic midnight estimate.
- Qibla bearing and sensor-based compass indicator.
- Hijri month grid, adjustable ±2-day date offset, common Shia religious occasion dates and countdowns, and custom date countdown.
- Prayer-completion checkmarks, full-day prayer streak, milestone level display.
- Bundled uploaded Azan MP3, replace/restore audio import, preview, per-prayer and global Azan switches.
- Prayer AlarmManager scheduling, foreground media playback service, wake lock, and notification Stop Azan action.
- Boot/time/time-zone/exact-alarm-permission recovery scheduling.

## Technical notes and limitations
- The default Jafari/Qom prayer angles are based on published Pray Times method documentation; Tehran and Islamic Centre of England presets are also exposed. Local Marja/mosque schedules and Maghrib definitions may differ. Manual offsets are provided; users should verify with their trusted local authority.
- Hijri date and religious occasion calculations use Android's built-in Hijri chronology and are estimates. Local moon-sighting can differ; a ±2-day offset is available.
- For best scheduled playback, the user must allow notifications and exact alarms. If exact-alarm access is not granted, Android inexact alarms are used. Do Not Disturb, battery restrictions, force-stop, reboot behavior and OEM background limits can affect delivery.
- Azan plays through a foreground media-playback service. The lock-screen notification exposes Stop Azan; stopping from the notification ends the service.
- Replaced audio is stored in app-private files. The bundled MP3 is the user-provided recording; it is not independently licensed.
- Full Android Gradle build, APK generation, and Android 16 device playback remain unverified in this environment due to unavailable Gradle distribution download and Android SDK. GitHub Actions is included to run `clean testDebugUnitTest assembleDebug` after push.
