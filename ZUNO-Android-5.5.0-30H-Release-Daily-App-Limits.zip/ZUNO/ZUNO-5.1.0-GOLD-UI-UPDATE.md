# ZUNO 5.1.0 — Gold UI refresh

## Visual direction
Applied the supplied reference's premium near-black and bright metallic yellow/champagne gold palette, with ivory typography, dark rounded panels, gold borders, gradient primary actions and restrained glow/elevation. The user's uploaded ZUNO mosque/crescent artwork is used for the in-app logo and launcher artwork.

## Updated surfaces
- Main dashboard, navigation, home action cards, headings, focus and All-in-One timers.
- Shia prayer and Azan screen, Hijri calendar, Qibla and prayer streak surfaces.
- First-run welcome/onboarding screens and primary buttons.
- Adult-content/focus block screen and its primary action.
- Offline guide and its composer.
- Arcade controls and game environment.
- Android colors, native accent and system bars.

## Source correction
`WelcomeActivity.renderStage()` now safely handles an uninitialized optional artwork helper instead of dereferencing it on first launch.

## Preserved
Existing app id, navigation destinations, prayer calculations, uploaded Azan audio, model assets, focus/blocking logic, progress and arcade functionality.

## Validation scope
This release is checked for ZIP integrity, Java syntax parsing, Android XML well-formedness, required drawable/manifest/resource references and included-asset presence. Full Gradle assembly and physical-device screenshot QA must still be run in GitHub Actions / Android device before publishing.
