# ZUNO 5.5.0 Patch Report

Implemented:
- Replaced all direct credential/password/phrase emergency release routes with one 30-hour delayed-release request.
- Added a 30-second Undo window immediately after creating the request.
- Persisted the request and its release deadline; it is restored on reboot, clock changes, app updates, and exact-alarm permission changes.
- A release request is cleared when the active session ends normally before the 30-hour deadline, avoiding a stale release request affecting a later session.
- Added a per-app daily foreground-usage budget (0–1,440 minutes) and local-midnight date rollover.
- Enforced reached app budgets with a dedicated daily-limit block screen.
- Excluded Android Settings, System UI, permission/install surfaces, dialer, phone, emergency-assistance and Contacts packages from app caps.
- Usage tracking pauses while the screen is off or keyguard is locked.

Checks completed:
- Java syntax parsing for all source files.
- AndroidManifest and Accessibility-service XML parsing.
- ZIP integrity and Gradle wrapper/project structure checks.

Full Android Gradle compilation was attempted but could not run because the environment could not resolve `services.gradle.org` to download Gradle 8.9. The GitHub Actions workflow can perform the full build when the ZIP is uploaded to the repository.

Timing note: Android can defer the 30-hour release if Exact Alarms access is not granted. With Exact Alarms access, ZUNO requests an exact idle-allowed alarm.
