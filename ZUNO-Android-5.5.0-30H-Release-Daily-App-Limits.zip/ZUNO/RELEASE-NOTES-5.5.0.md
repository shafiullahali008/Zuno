# ZUNO 5.5.0 — Delayed Release & Daily App Budgets

- Replaced device-password / phrase based early recovery with a scheduled 30-hour release request.
- The release request has a one-time 30-second Undo window. After it closes, the request remains scheduled.
- The pending release survives app restarts and is restored after reboot or time / exact-alarm setting changes.
- Added per-app daily foreground-time budgets, configurable from 0 (off) to 1,440 minutes.
- When a configured daily cap is reached, ZUNO displays a daily-limit block screen for that app; usage keys roll over at local midnight.
- App usage counting and enforcement depend on the user-enabled ZUNO Accessibility service.
- Emergency calling, system UI, Android Settings, permission controllers, package installation surfaces and critical phone components are excluded from app caps and remain available.

## Timing note

Android can defer inexact alarms when the app does not have Exact Alarms access. With that access granted, ZUNO schedules an exact idle-allowed alarm. Without it, the 30-hour release may occur later than the target time.
