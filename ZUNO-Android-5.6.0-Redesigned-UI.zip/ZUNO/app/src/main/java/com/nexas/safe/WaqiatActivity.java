package com.nexas.safe;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Curated reading cards. Historical reports are identified by source and are not presented as equally authenticated. */
public final class WaqiatActivity extends Activity {
    private static final int BG = Color.rgb(5, 5, 7);
    private static final int INK = Color.rgb(255, 247, 225);
    private static final int MUTED = Color.rgb(190, 177, 151);
    private static final int GOLD = Color.rgb(255, 200, 50);
    private static final int PANEL = Color.rgb(25, 24, 22);
    private static final int OUTLINE = Color.rgb(132, 96, 35);
    private LinearLayout list;

    private static final String[][] STORIES = {
        {"01 · Laylat al-Mabit — the night of migration", "When the Prophet prepared to leave Makkah, Imam Ali (a) is reported in Shia accounts to have slept in the Prophet’s bed, accepting a grave risk so the Prophet could depart safely. The episode is remembered for loyalty, courage and putting another person’s safety before one’s own. The Qur’anic connection is discussed in Shia tafsir, while the historical details are preserved in early sira and later Imami compilations.", "Shia references: al-Shaykh al-Mufid, al-Irshad (life of Imam Ali); al-Tabrisi, I‘lam al-Wara; Bihar al-Anwar, historical sections. Qur’anic discussion: 2:207. Details vary across historical reports."},
        {"02 · Ghadir Khumm", "On the return from the Farewell Pilgrimage, the Prophet addressed the gathering at Ghadir Khumm. Twelver Shia tradition understands the declaration ‘man kuntu mawlahu fa-hadha Aliyyun mawlahu’ as the public designation of Imam Ali. The event is central to Shia memory and is discussed through hadith collections and historical works. Readers should distinguish the shared report of the statement from later debates over the meaning of mawla.", "Shia references: al-Kulayni, al-Kafi, Kitab al-Hujjah; al-Mufid, al-Irshad; al-Tabrisi, I‘lam al-Wara; al-Amini, al-Ghadir. Qur’anic context discussed by exegetes: 5:67."},
        {"03 · Mubahala", "The event of Mubahala is connected with the delegation from Najran and the challenge to invoke God’s curse upon the party that knowingly persisted in falsehood. Shia reports identify the Prophet’s chosen members of his household as Ali, Fatima, Hasan and Husayn. The episode is remembered as a public affirmation of the spiritual standing of the Ahl al-Bayt.", "Primary Qur’anic passage: 3:61. Shia references: al-Mufid, al-Irshad; al-Tabrisi, Majma‘ al-Bayan (commentary on 3:61); al-Tabrisi, I‘lam al-Wara."},
        {"04 · Imam Ali and the care of the vulnerable", "The ethical portrait of Imam Ali in Shia literature repeatedly joins worship with public responsibility: justice in governance, care for orphans and the poor, and restraint toward personal wealth. His instructions to Malik al-Ashtar urge a governor to treat people with mercy and to remember that they are either brothers in faith or equals in humanity. This is a moral and political teaching, not merely a story of personal piety.", "Reference: Nahj al-Balagha, Letter 53 to Malik al-Ashtar. Nahj al-Balagha is a selected compilation by al-Sharif al-Radi; individual reports should be studied with source-critical care."},
        {"05 · The patience and treaty of Imam Hasan", "After Imam Ali’s martyrdom, Imam Hasan assumed leadership amid military and political division. Shia historical accounts describe his treaty with Muawiya as a decision made under severe pressure to prevent further bloodshed and preserve the community. The episode is often studied as an example of strategic patience; the terms and chronology should be read from historical sources rather than reduced to slogans.", "Shia references: al-Mufid, al-Irshad (life of Imam Hasan); al-Tabrisi, I‘lam al-Wara; al-Majlisi, Bihar al-Anwar, sections on Imam Hasan. Reports differ on some treaty clauses."},
        {"06 · Imam Husayn refuses an unjust pledge", "In the accounts of the events leading to Karbala, Imam Husayn refuses to give allegiance to Yazid. His departure from Madinah and later movement toward Iraq are presented in Shia memory as a stand against legitimising oppression. The central lesson is the moral cost of refusing to normalise injustice, while the precise wording of speeches differs among historical transmitters.", "Shia references: al-Mufid, al-Irshad (Imam Husayn); Abu Mikhnaf’s material as preserved in early histories; Muhammad Baqir al-Majlisi, Bihar al-Anwar. For source-critical reconstruction: Muhammad Muhammadi Rayshahri, Chronicles of the Martyrdom of Imam Husayn."},
        {"07 · Karbala and the companions", "On 10 Muharram 61 AH, Imam Husayn and a small group of family members and companions were killed at Karbala. Shia remembrance emphasises their steadfastness despite isolation, thirst and overwhelming military force. The story is not only a record of loss; it is also a study of loyalty, truthfulness, courage and refusing to abandon principle under pressure.", "Sources: al-Mufid, al-Irshad; al-Tabari’s historical account (with earlier transmitters); al-Majlisi, Bihar al-Anwar. A modern source-critical Shia study: Muhammad Muhammadi Rayshahri, Chronicles of the Martyrdom of Imam Husayn (ICAS Press)."},
        {"08 · Lady Zaynab after Karbala", "After the tragedy, Lady Zaynab (a) became a central voice in the public remembrance of Karbala. Shia sources preserve sermons attributed to her in Kufa and the court of Damascus. These accounts portray eloquence and moral courage in the face of captivity, and show how the survivors challenged the attempt to control the meaning of the event.", "Shia references: al-Tabrisi, al-Ihtijaj; al-Majlisi, Bihar al-Anwar; later maqtal literature. Sermon wording and transmission differ between compilations; quotations should be checked against a chosen edition."},
        {"09 · Imam Sajjad and the language of prayer", "Imam Ali ibn al-Husayn, known as Zayn al-Abidin, is associated with the al-Sahifa al-Sajjadiyya, a collection of supplications that joins spiritual refinement with concern for family, neighbours, the vulnerable and the wider community. Its prayers teach that devotion should shape character and social conduct, not remain detached from everyday responsibilities.", "Reference: al-Sahifa al-Sajjadiyya, especially Supplications 20 (Makarim al-Akhlaq) and 24 (for parents). The collection’s transmission and individual supplications have their own scholarly discussions."},
        {"10 · Imam Muhammad al-Baqir and the revival of learning", "Imam Muhammad al-Baqir is remembered in Twelver Shia tradition for explaining religious knowledge and laying foundations for the scholarly circle that expanded under his son, Imam Ja‘far al-Sadiq. Reports about his teaching emphasise careful understanding of Qur’an, law and ethics. The lesson is the importance of learning with discipline and transmitting knowledge responsibly.", "Shia references: al-Kulayni, al-Kafi, Kitab al-‘Ilm and sections on the Imams; al-Mufid, al-Irshad; al-Najashi, Rijal (bibliographical context). Individual narrations require hadith grading."},
        {"11 · Imam Ja‘far al-Sadiq and the pursuit of knowledge", "The period of Imam Ja‘far al-Sadiq is associated with a major expansion of teaching in jurisprudence, theology and other disciplines. Shia biographical and hadith works preserve reports from his lessons and from students who transmitted his teachings. The account encourages asking careful questions, verifying reports and recognising that scholarship requires both knowledge and integrity.", "Shia references: al-Kulayni, al-Kafi; al-Mufid, al-Irshad; al-Tusi, al-Amali; al-Najashi, Rijal. Narrations vary in chain strength and should not all be treated as equally authentic."},
        {"12 · Imam Ali’s justice and the public trust", "In the letters and sermons attributed to Imam Ali, public office is described as a trust rather than a personal privilege. The ruler is instructed to avoid favouritism, listen to ordinary people, restrain officials from exploitation and protect the weak. This account connects spiritual accountability with practical standards for leadership and administration.", "Reference: Nahj al-Balagha, Letter 53 and selected sermons. The collection omits most chains of transmission; parallel attestations and scholarly commentaries should be consulted for detailed historical or hadith claims."}
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(34));
        root.setBackgroundColor(BG);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.addView(root);

        TextView back = text("‹   BACK TO PRAYER", 11, GOLD, true);
        back.setLetterSpacing(0.08f);
        back.setPadding(dp(13), dp(10), dp(13), dp(10));
        back.setBackground(round(PANEL, 30, OUTLINE));
        back.setOnClickListener(v -> finish());
        root.addView(back, lp());

        TextView eyebrow = text("THE AHLUL BAYT LIBRARY", 10, GOLD, true);
        eyebrow.setLetterSpacing(0.15f);
        LinearLayout.LayoutParams ep = lp(); ep.topMargin = dp(21); root.addView(eyebrow, ep);

        TextView title = text("Ahlul Bayt • Waqiat", 28, INK, true);
        title.setTypeface(Typeface.create("serif", Typeface.BOLD));
        title.setLineSpacing(dp(3), 1.02f);
        LinearLayout.LayoutParams titleLp = lp(); titleLp.topMargin = dp(7); root.addView(title, titleLp);

        TextView intro = text("A source-led reading collection of key events and lessons from Twelver Shia tradition. Each card names its source family so you can follow up in the original text.", 13, MUTED, false);
        intro.setLineSpacing(dp(4), 1.06f);
        LinearLayout.LayoutParams ip = lp(); ip.topMargin = dp(9); root.addView(intro, ip);

        LinearLayout noteCard = new LinearLayout(this);
        noteCard.setOrientation(LinearLayout.VERTICAL);
        noteCard.setPadding(dp(15), dp(14), dp(15), dp(14));
        noteCard.setBackground(round(Color.rgb(40, 31, 17), 17, OUTLINE));
        TextView noteHeading = text("RESEARCH NOTE", 10, GOLD, true);
        noteHeading.setLetterSpacing(0.12f);
        noteCard.addView(noteHeading, lp());
        TextView note = text("Historical reports differ in wording, chains and detail. A book reference does not mean every version is equally authentic. Check the original Arabic/Persian/Urdu edition and scholarly grading before quoting a narration as certain.", 11, INK, false);
        note.setLineSpacing(dp(3), 1.04f);
        LinearLayout.LayoutParams noteLp = lp(); noteLp.topMargin = dp(7); noteCard.addView(note, noteLp);
        LinearLayout.LayoutParams np = lp(); np.topMargin = dp(16); root.addView(noteCard, np);

        TextView collectionLabel = text("12 READINGS  •  SOURCE REFERENCES", 10, GOLD, true);
        collectionLabel.setLetterSpacing(0.11f);
        LinearLayout.LayoutParams clp = lp(); clp.topMargin = dp(23); root.addView(collectionLabel, clp);

        list = root;
        for (String[] story : STORIES) addStory(story);
        setContentView(scroll);
        SystemBarInsets.apply(scroll);
    }

    private void addStory(String[] item) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(round(PANEL, 19, OUTLINE));
        card.setElevation(dp(3));
        LinearLayout.LayoutParams cp = lp(); cp.topMargin = dp(13); list.addView(card, cp);

        TextView heading = text(item[0], 17, INK, true);
        heading.setLineSpacing(dp(2), 1.03f);
        card.addView(heading, lp());

        View rule = new View(this);
        rule.setBackgroundColor(Color.rgb(76, 59, 31));
        LinearLayout.LayoutParams ruleLp = new LinearLayout.LayoutParams(-1, dp(1));
        ruleLp.topMargin = dp(11);
        card.addView(rule, ruleLp);

        TextView body = text(item[1], 13, MUTED, false);
        body.setLineSpacing(dp(4), 1.06f);
        LinearLayout.LayoutParams bp = lp(); bp.topMargin = dp(12); card.addView(body, bp);

        TextView sourceLabel = text("SOURCE REFERENCES", 9, GOLD, true);
        sourceLabel.setLetterSpacing(0.12f);
        LinearLayout.LayoutParams slp = lp(); slp.topMargin = dp(14); card.addView(sourceLabel, slp);
        TextView source = text(item[2], 11, INK, false);
        source.setLineSpacing(dp(3), 1.05f);
        LinearLayout.LayoutParams sp = lp(); sp.topMargin = dp(5); card.addView(source, sp);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private GradientDrawable round(int color, int radius) { return round(color, radius, OUTLINE); }

    private GradientDrawable round(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }
    private LinearLayout.LayoutParams lp() { return new LinearLayout.LayoutParams(-1, -2); }
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
}
