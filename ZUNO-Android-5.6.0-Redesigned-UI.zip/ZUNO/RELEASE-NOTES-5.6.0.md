# ZUNO 5.6.0 — Dashboard UI Rebuild

- Rebuilt the home dashboard as a vertically stacked set of clearly separated category cards.
- Removed the cramped two-column quick-control tiles from the home screen; detailed controls remain inside their dedicated workspaces/settings.
- Added distinct entry cards for Focus, NEXAS Protection, Prayer & Calendar, Progress & Arcade, and Settings.
- Increased text wrapping and spacing so titles and descriptions do not clip or sit behind adjacent controls.
- Reduced the oversized page-heading typography and improved line spacing for narrow phone displays.
- Updated Android version to 5.6.0 (versionCode 31).

This release changes the home/dashboard presentation. It does not intentionally change focus, protection, prayer, alarm, or app-limit logic.
