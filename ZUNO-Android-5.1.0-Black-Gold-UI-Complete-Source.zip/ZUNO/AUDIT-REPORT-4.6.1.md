# VYRA 4.6.1 — source audit and fixes

## Scope

Reviewed the Android app source and resources, Gradle project files, GitHub Actions workflow, model assets and checksum metadata, and the NEXAS PUREVIEW Python/Windows tooling. Automated syntax and integrity checks were run over the packaged Java, Python, XML, JSON and YAML sources. Targeted tests were run for the pure Java timer/focus/text/domain logic and for model generation/hash synchronization.

## Findings fixed

1. **Missing Gradle wrapper in the original 4.6.0 archive.** Added the Gradle 8.9 wrapper files. The project uses Android Gradle Plugin 8.7.3, JDK 17, compile/target SDK 35 and min SDK 26.
2. **No automated Android build workflow.** Added `.github/workflows/android-ci.yml` to install JDK 17 and Android SDK 35, run unit tests and `assembleDebug`, and upload the debug APK. A separate job compiles Python tools, validates generated TFLite FlatBuffers/smoke vectors, checks model checksums and verifies runtime SHA pins.
3. **Incorrect Python project-root discovery.** Fixed toolkit scripts so they locate the VYRA root by finding `settings.gradle` and the app model-assets directory. Training, provisioning and validation now target the actual Android asset tree.
4. **Whisper provisioning report path used an undefined variable.** Replaced it with the detected project root.
5. **Model retraining could invalidate runtime hashes.** Added `sync_model_hashes.py`; the training scripts now refresh Java SHA-256 pins and `MODEL_SHA256SUMS.txt` after rewriting the text/URL TFLite files. CI checks the pins without modifying source.
6. **Training scripts gave poor errors for malformed CSV headers.** They now validate required columns before calling `dropna`.
7. **URL model feature parity edge cases.** Java URL inference now recognizes valid IPv4 and IPv6 literals, matches Python's valid-port behavior and preserves trailing-dot host depth when splitting labels.
8. **All-in-One display and runtime edge cases.** Increased the dial view height to prevent bottom-label clipping; the block screen now shows the live remaining countdown; non-finite text/URL model outputs return `UNKNOWN`; reminder scheduling checks notification permission and retains its reschedule fallback.
9. **Android 15/16 edge-to-edge layout risk.** Added a guarded system-bar/display-cutout inset helper and applied it to each Activity's root view for target-SDK-35 devices, preventing top/bottom controls from sitting underneath system bars.
10. **Stale build instructions and generated Python cache files.** Updated README/build notes, added cache exclusions and removed generated `__pycache__` content from the source archive.

## Checks completed in this environment

- Java parser: all Java source/test files parsed with zero syntax errors.
- Python: all developer-tool scripts passed `compileall`.
- Android resources: XML files parsed successfully.
- JSON metadata and GitHub Actions YAML: parsed successfully.
- Bundled TFLite assets: `TFL3` signatures, expected tensor shapes and SHA-256 checksums verified.
- Prototype text/URL FlatBuffers: structural checks and embedded-weight smoke vectors passed.
- Java model/business-logic harness: AllInOneTime, FocusDuration, ContextAwareTextClassifier and AdultDomainBlocklist tests passed.
- URL-model adapter was compiled against isolated Android/TFLite API stubs; IPv4, IPv6, invalid IPv4, port-zero and trailing-dot host-depth cases passed.
- Model retraining path: isolated seed-model regeneration and TFLite structural validation passed; hash sync was tested separately.
- ZIP integrity: checked after final packaging.

## Not verified / residual risk

- **No full Android Gradle build or APK was produced here.** The environment has no Android SDK/`android.jar`, no cached Gradle distribution, and could not resolve `services.gradle.org` to download Gradle 8.9. The wrapper and GitHub Actions workflow are included, but the actual workflow must pass on GitHub before claiming build success.
- Android framework type-checking, resource linking, DEX packaging, signing and Android 16 device behavior were not exercised locally.
- The custom TFLite prototype models passed structural FlatBuffer checks and arithmetic smoke tests, but were not loaded by the real TensorFlow Lite Interpreter here. GitHub CI currently performs the custom structural checks, not a LiteRT device inference test.
- Accessibility scanning depends on text/URLs exposed by the selected app/browser and is not system-wide DNS filtering or continuous screen capture.
- The text and URL model training examples are synthetic. They are advisory prototypes and must not be treated as reliable detection or blocking authorities without representative, lawfully sourced datasets and real held-out evaluation.
- Android cannot guarantee that an ordinary app is impossible to stop, disable or uninstall. Emergency release and user-controlled Android settings remain available by design.

## Build command after opening the repository on GitHub or a machine with Android SDK 35

```bash
./gradlew --no-daemon clean testDebugUnitTest assembleDebug
```

Use JDK 17. If GitHub Actions fails, use the first failing task and stack trace to make the next targeted fix; this audit does not claim that unexecuted build tasks have passed.
