# ZUNO 4.4.0 — Build and verification status

## Integrated source changes
- Bundled NudeNet 320n TFLite weights and first-use installation into private app storage with SHA-256 asset verification; arbitrary model replacement/import was removed to keep the tensor shape fixed.
- Replaced the previous 640n tensor assumptions with the bundled model's validated `[1,320,320,3]` input and `[1,22,2100]` output. The class-selection logic follows NudeNet's per-anchor highest-class decoder before thresholds are applied.
- Added local image and selected-video sampling scans; sampled frames are capped at 60 and downscaled before inference when needed.
- Added 76,798-entry hashed domain index and 437-entry hashed phrase index. Sensitive strings are not shipped as readable index files.
- Connected the indexes to the supported-browser Accessibility text path.
- Preserved ZUNO Focus, 7-Layer controls, existing game source, light UI, and no-screen-capture design.
- Set application version to 4.4.0 (versionCode 21).

## Verification completed
- ZIP and source assets inspected; model TFLite header and expected tensor dimensions checked from source/model metadata.
- Hashed domain and keyword indexes parsed and checked against source counts and hash values.
- Targeted Java compilation and local probe for the domain and keyword index classes completed with Android/TFLite API stubs.
- Manifest/XML parsing and no-Internet/no-MediaProjection checks completed.

## Not verified
- Full Android Gradle build and APK generation were not run because this environment lacks Android SDK/Gradle.
- Physical Android 16 launch, inference throughput, accessibility behavior, and games crash behavior were not tested on-device. In particular, the reported white-screen/force-stop game issue cannot be called fixed from static source checks alone.
- Video scanning is sampled (maximum 60 frames), not frame-complete or live monitoring. Browser checks depend on text/URL exposed to Accessibility.
