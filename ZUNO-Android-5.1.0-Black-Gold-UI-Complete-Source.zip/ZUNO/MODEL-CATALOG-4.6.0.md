# VYRA 4.6.0 model catalog

| Model / subsystem | Package state | Runtime role | Limitations |
|---|---|---|---|
| NudeNet 320n (`nudenet_320n_fp16.tflite`) | Bundled | Existing selected-image and sampled-video visual screening | Probabilistic visual screening; not live screen capture or exhaustive video scan |
| Text Safety (`text_safety.tflite`) | Bundled, wired to Accessibility scan | Advisory text-risk signal | Synthetic seed training/holdout only; not production-grade, especially for Urdu/Roman Urdu |
| URL Risk (`url_risk.tflite`) | Bundled, wired to supported-browser visible URL/hostname scan | Advisory URL-pattern signal | Synthetic URL patterns only; no reputation feed, DNS firewall or threat-intelligence lookup |
| Hashed adult-domain index | Bundled | Existing browser-visible text/domain blocking | Depends on exposed browser text/URL; not system-wide DNS filtering |
| Bundled/custom keyword signals | Bundled | Existing context-aware phrase filtering | Heuristic/contextual rules; false positives and misses possible |
| NSFW MobileNetV2 | Not present | Optional image classifier adapter source only in NEXAS toolkit | Actual weights missing from the supplied ZIP |
| YAMNet + class labels | Not present | Optional 521-class audio-event adapter source only in toolkit | Actual weights/labels missing; sound events are not speech moderation |
| Whisper Tiny LiteRT-LM | Not present | Optional ASR provisioning notes only | Bundle missing; separate LiteRT-LM Omni runtime/integration required |
| Deepfake detection | Not implemented | None | No selected model or validated dataset supplied |

Missing, incompatible or failed specialist models must remain `UNKNOWN`; `SAFE_CANDIDATE` is not a guarantee. The Text Safety and URL Risk prototypes are advisory only and are not used as automatic blocking authorities.

All bundled app model files and their SHA-256 values are listed in `app/src/main/assets/models/MODEL_SHA256SUMS.txt`.
