# VYRA 4.6.1 — audit and build-tooling fixes

- Bumped the Android source version to 4.6.1 (versionCode 24).
- Added the Gradle 8.9 wrapper and GitHub Actions workflow for JDK 17 / Android SDK 35.
- Fixed the NEXAS toolkit project-root discovery used by model training, provisioning and validation scripts.
- Fixed the optional Whisper provisioning report path.
- Added model hash synchronization after model retraining and a CI check for model/Java SHA alignment.
- Improved malformed CSV handling in the text and URL training commands.
- Aligned Java URL-model feature extraction with Python training for valid IPv4/IPv6 host literals, valid ports and trailing-dot host depth.
- Fixed the All-in-One dial layout height and countdown text, notification-permission fallback, non-finite model-output handling, and target-SDK-35 system-bar insets on Android 15/16.
- Added Python bytecode/cache exclusions to `.gitignore`.

The archive has not been fully compiled with Android Gradle in this authoring environment: Gradle 8.9 could not be downloaded because outbound DNS/network access was unavailable, and Android SDK 35 / `android.jar` were not installed. GitHub Actions is configured to perform the definitive Android build and unit tests. Do not treat the source package as a verified APK until that workflow passes.
