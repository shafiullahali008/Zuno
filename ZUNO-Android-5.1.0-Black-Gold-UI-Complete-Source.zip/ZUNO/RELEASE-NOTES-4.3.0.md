# VYRA 4.3.0 — Light UI, Arcade Stability and Capture Removal

## Included source changes
- Applied the light porcelain theme to the main app, onboarding, block screen, guide and arcade activity.
- Replaced the previous launcher mark with a simplified VYRA shield/V vector icon and updated SVG/PNG brand assets.
- Added additional top padding to the main app shell and retained safe top spacing on standalone screens.
- Added page transitions with subtle perspective rotation, scale and fade; cards use a short 3D tilt/settle entrance; buttons retain press motion.
- Replaced the OpenGL ES / EGL game activity with a Canvas-based perspective renderer for Temple Sprint and Orbit Roll. It no longer requires a particular EGL configuration or GPU OpenGL setup. It includes swipe movement, jump/slide, score, lives, pause and retry.
- Removed MediaProjection service, permissions, capture controls and capture-dependent service integration. No screen sharing, screenshot capture or screen recording is requested.
- Updated PUREVIEW wording to distinguish page-text checks, user-selected image classification and the limits of Android Accessibility.
- Listed seven real local detection stages in the Protection page without claiming live visual inspection of other apps.

## Important limitations
- This package does not include the third-party `.tflite` model binary. The app imports a separately supplied local file and has no Internet permission or model-download path. Once imported, selected-image inference runs locally. The archive alone cannot supply weights, so visual AI is unavailable on a clean install until the model file is provided.
- Background checking is limited to supported text and app events exposed by Android Accessibility after the user manually enables the service. It cannot scan pixels from other apps or inspect live video after MediaProjection was removed.
- The built-in Guide is a local rule/response helper, not a generative AI assistant.
- The 7-layer Focus/Strictness panel remains separate from the 7-stage PUREVIEW detection pipeline. Ordinary Android app restrictions still cannot make VYRA undeletable or override system recovery/settings.

## Verification status
- Android manifest/resources are being statically checked for XML validity and removed capture references.
- Java source is being checked for structural/symbol consistency.
- A full Gradle Android build, APK install, and physical-device game test are **not available in this environment** (no local Gradle distribution/Android SDK and network access for dependency resolution is unavailable). Do not treat this archive as a verified release APK until GitHub Actions and device testing pass.
