package com.nexas.safe;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.view.View;

import java.util.Locale;

/** Gold elapsed-time dial for the All-in-One commitment. Time is derived from persisted wall-clock timestamps. */
final class AllInOneDial extends View {
    private static final int GOLD = Color.rgb(255, 199, 48);
    private static final int GOLD_LIGHT = Color.rgb(255, 239, 168);
    private static final int TRACK = Color.rgb(55, 44, 25);
    private static final int INK = Color.rgb(255, 247, 225);
    private static final int MUTED = Color.rgb(190, 177, 151);

    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint secondary = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF bounds = new RectF();
    private long startedAt;
    private long endAt;
    private long savedElapsed;
    private boolean active;

    AllInOneDial(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeCap(Paint.Cap.ROUND);
        track.setColor(TRACK);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeCap(Paint.Cap.ROUND);
        text.setColor(INK);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        secondary.setColor(MUTED);
        secondary.setTextAlign(Paint.Align.CENTER);
        secondary.setTypeface(android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL));
        setContentDescription("All-in-One commitment elapsed-time streak timer");
    }

    void setSession(long start, long end, boolean running, long saved) {
        startedAt = Math.max(0L, start);
        endAt = Math.max(0L, end);
        active = running && startedAt > 0L && endAt > startedAt;
        savedElapsed = Math.max(0L, saved);
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float density = getResources().getDisplayMetrics().density;
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float radius = Math.min(getWidth(), getHeight()) * 0.385f;
        float stroke = 11f * density;
        long now = System.currentTimeMillis();
        long elapsed = active ? Math.max(0L, now - startedAt) : savedElapsed;
        long days = elapsed / 86_400_000L;
        long hours = (elapsed / 3_600_000L) % 24L;
        long minutes = (elapsed / 60_000L) % 60L;
        long seconds = (elapsed / 1_000L) % 60L;

        track.setStrokeWidth(stroke);
        ring.setStrokeWidth(stroke);
        bounds.set(cx - radius, cy - radius, cx + radius, cy + radius);
        Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
        halo.setStyle(Paint.Style.STROKE);
        halo.setStrokeWidth(18f * density);
        halo.setColor(Color.argb(active ? 35 : 18, 255, 199, 48));
        canvas.drawCircle(cx, cy, radius, halo);
        canvas.drawCircle(cx, cy, radius, track);

        float fraction = 0f;
        if (active && endAt > startedAt) {
            fraction = Math.min(1f, (float) (elapsed / (double) (endAt - startedAt)));
        } else if (!active && savedElapsed > 0L) {
            fraction = 1f;
        }
        ring.setShader(new SweepGradient(cx, cy,
                new int[]{GOLD, GOLD_LIGHT, GOLD}, new float[]{0f, 0.72f, 1f}));
        canvas.save();
        canvas.rotate(-90f, cx, cy);
        if (fraction > 0f) canvas.drawArc(bounds, 0f, 360f * fraction, false, ring);
        canvas.restore();
        ring.setShader(null);

        Paint tick = new Paint(Paint.ANTI_ALIAS_FLAG);
        tick.setStrokeWidth(1.2f * density);
        for (int i = 0; i < 48; i++) {
            double angle = Math.toRadians(i * 7.5d - 90d);
            float inner = radius + (i % 4 == 0 ? 8f : 10f) * density;
            float outer = radius + (i % 4 == 0 ? 15f : 12f) * density;
            tick.setColor(i % 4 == 0 ? GOLD : Color.rgb(132, 96, 35));
            canvas.drawLine(cx + (float) Math.cos(angle) * inner,
                    cy + (float) Math.sin(angle) * inner,
                    cx + (float) Math.cos(angle) * outer,
                    cy + (float) Math.sin(angle) * outer, tick);
        }

        secondary.setTextSize(10f * density);
        canvas.drawText(active ? "ALL-IN-ONE STREAK" : (savedElapsed > 0L ? "LAST STREAK" : "STREAK TIMER"),
                cx, cy - 35f * density, secondary);

        text.setTextSize(35f * density);
        text.setTypeface(android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD));
        canvas.drawText(String.format(Locale.ROOT, "%d", days), cx, cy + 5f * density, text);
        secondary.setTextSize(10f * density);
        canvas.drawText(days == 1 ? "DAY" : "DAYS", cx, cy + 23f * density, secondary);

        text.setTextSize(15f * density);
        text.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        canvas.drawText(String.format(Locale.ROOT, "%02d : %02d : %02d", hours, minutes, seconds),
                cx, cy + 57f * density, text);
        secondary.setTextSize(8f * density);
        canvas.drawText("HOURS       MINUTES       SECONDS", cx, cy + 73f * density, secondary);

        if (active) {
            secondary.setTextSize(9f * density);
            canvas.drawText("LOCK PROGRESS  " + Math.round(fraction * 100f) + "%", cx,
                    cy + radius + 35f * density, secondary);
        } else {
            secondary.setTextSize(9f * density);
            canvas.drawText(savedElapsed > 0L ? "COMMITMENT PAUSED / COMPLETED" : "START TO BEGIN YOUR STREAK",
                    cx, cy + radius + 35f * density, secondary);
        }
    }
}
