package com.nexas.safe;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class PrayerAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String prayer = intent.getStringExtra("prayer_name");
        if (prayer == null || prayer.trim().isEmpty()) return;
        if (PrayerPrefs.prayerAzanEnabled(context, prayer)) {
            Intent play = new Intent(context, PrayerAzanService.class)
                    .setAction(PrayerAzanService.ACTION_PLAY)
                    .putExtra("prayer_name", prayer);
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(play);
                else context.startService(play);
            } catch (RuntimeException ex) {
                PrayerNotifications.showFallback(context, prayer);
            }
        }
        PrayerScheduler.scheduleUpcoming(context);
    }
}
