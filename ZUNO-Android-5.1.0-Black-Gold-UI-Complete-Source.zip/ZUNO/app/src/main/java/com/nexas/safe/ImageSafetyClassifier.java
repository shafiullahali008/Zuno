package com.nexas.safe;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import org.tensorflow.lite.DataType;
import org.tensorflow.lite.Interpreter;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Offline NudeNet 320n YOLOv8n image classifier. This processes only a user-selected local image/video
 * frame. It never captures the device screen, starts screen sharing, or uploads media.
 */
final class ImageSafetyClassifier implements Closeable {
    private static final int[] EXPLICIT_CLASS_IDS = {2, 3, 4, 6, 14};
    private static final int[] STRICT_COVERED_CLASS_IDS = {0, 17};
    private static final float[] BALANCED_THRESHOLDS = {0.60f, 0.55f, 0.55f, 0.55f, 0.75f};
    private static final float[] STRICT_THRESHOLDS = {0.45f, 0.40f, 0.40f, 0.40f, 0.65f};
    private static final String[] EXPLICIT_LABELS = {
            "buttocks exposed", "female breast exposed", "female genitalia exposed",
            "anus exposed", "male genitalia exposed"
    };
    private static final String[] STRICT_COVERED_LABELS = {
            "female genitalia covered", "buttocks covered"
    };

    private final Interpreter interpreter;
    private final int inputSize;
    private final int outputChannels;
    private final int anchors;
    private final boolean strict;
    private final Bitmap letterboxedBitmap;
    private final Canvas bitmapCanvas;
    private final ByteBuffer inputBuffer;
    private final int[] pixelBuffer;
    private final float[][][] outputBuffer;
    private final Paint resizePaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final RectF destination = new RectF();
    private boolean closed;

    static final class Result {
        final boolean flagged;
        final float confidence;
        final String label;
        Result(boolean flagged, float confidence, String label) {
            this.flagged = flagged;
            this.confidence = confidence;
            this.label = label;
        }
    }

    ImageSafetyClassifier(File model) throws IOException { this(model, false); }

    ImageSafetyClassifier(File model, boolean strict) throws IOException {
        if (model == null || !model.isFile() || model.length() < 5_000_000L) {
            throw new IOException("Bundled offline AI model is missing or incomplete");
        }
        Interpreter opened = null;
        Bitmap bitmap = null;
        try {
            opened = new Interpreter(model, new Interpreter.Options().setNumThreads(2));
            if (opened.getInputTensorCount() != 1 || opened.getOutputTensorCount() != 1) {
                throw new IOException("Unsupported NudeNet model tensor count");
            }
            int[] in = opened.getInputTensor(0).shape();
            int[] out = opened.getOutputTensor(0).shape();
            boolean valid = in.length == 4 && in[0] == 1 && in[1] == 320 && in[2] == 320 && in[3] == 3
                    && opened.getInputTensor(0).dataType() == DataType.FLOAT32
                    && out.length == 3 && out[0] == 1 && out[1] == 22 && out[2] == 2100
                    && opened.getOutputTensor(0).dataType() == DataType.FLOAT32;
            if (!valid) throw new IOException("Model tensor layout mismatch; expected float32 [1,320,320,3] and [1,22,2100]");
            inputSize = in[1];
            outputChannels = out[1];
            anchors = out[2];
            bitmap = Bitmap.createBitmap(inputSize, inputSize, Bitmap.Config.ARGB_8888);
            letterboxedBitmap = bitmap;
            bitmapCanvas = new Canvas(bitmap);
            inputBuffer = ByteBuffer.allocateDirect(inputSize * inputSize * 3 * 4).order(ByteOrder.nativeOrder());
            pixelBuffer = new int[inputSize * inputSize];
            outputBuffer = new float[1][outputChannels][anchors];
            interpreter = opened;
            this.strict = strict;
        } catch (IOException ex) {
            closeInterpreter(opened);
            throw ex;
        } catch (RuntimeException | OutOfMemoryError ex) {
            closeInterpreter(opened);
            if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            throw new IOException("Could not initialise the offline NudeNet model", ex);
        }
    }

    synchronized Result classify(Bitmap source) {
        if (closed || source == null || source.isRecycled() || source.getWidth() <= 0 || source.getHeight() <= 0) {
            return new Result(false, 0f, "none");
        }
        bitmapCanvas.drawColor(Color.BLACK);
        float scale = Math.min((float) inputSize / source.getWidth(), (float) inputSize / source.getHeight());
        float width = source.getWidth() * scale;
        float height = source.getHeight() * scale;
        // Match the upstream NudeNet/PureView convention: aspect-preserving image in the
        // top-left corner, with the unused right/bottom area left black.
        destination.set(0f, 0f, width, height);
        bitmapCanvas.drawBitmap(source, null, destination, resizePaint);
        letterboxedBitmap.getPixels(pixelBuffer, 0, inputSize, 0, 0, inputSize, inputSize);

        inputBuffer.clear();
        for (int pixel : pixelBuffer) {
            inputBuffer.putFloat(((pixel >> 16) & 0xFF) / 255f);
            inputBuffer.putFloat(((pixel >> 8) & 0xFF) / 255f);
            inputBuffer.putFloat((pixel & 0xFF) / 255f);
        }
        inputBuffer.flip();
        interpreter.run(inputBuffer, outputBuffer);

        float bestScore = 0f;
        String bestLabel = "none";
        float[] thresholds = strict ? STRICT_THRESHOLDS : BALANCED_THRESHOLDS;
        for (int i = 0; i < EXPLICIT_CLASS_IDS.length; i++) {
            float score = bestScoreForClass(EXPLICIT_CLASS_IDS[i]);
            if (score >= thresholds[i] && score > bestScore) {
                bestScore = score;
                bestLabel = EXPLICIT_LABELS[i];
            }
        }
        if (strict) {
            for (int i = 0; i < STRICT_COVERED_CLASS_IDS.length; i++) {
                float score = bestScoreForClass(STRICT_COVERED_CLASS_IDS[i]);
                float threshold = i == 0 ? 0.60f : 0.65f;
                if (score >= threshold && score > bestScore) {
                    bestScore = score;
                    bestLabel = STRICT_COVERED_LABELS[i];
                }
            }
        }
        return new Result(!"none".equals(bestLabel), bestScore, bestLabel);
    }

    /** Mirrors NudeNet's decoder: each anchor contributes only its highest-scoring class. */
    private float bestScoreForClass(int targetClassId) {
        float best = 0f;
        for (int anchor = 0; anchor < anchors; anchor++) {
            int bestClass = 0;
            float bestClassScore = safeScore(outputBuffer[0][4][anchor]);
            for (int classId = 1; classId < 18; classId++) {
                float score = safeScore(outputBuffer[0][4 + classId][anchor]);
                if (score > bestClassScore) {
                    bestClass = classId;
                    bestClassScore = score;
                }
            }
            if (bestClass == targetClassId && bestClassScore > best) best = bestClassScore;
        }
        return best;
    }

    private static float safeScore(float value) {
        return Float.isFinite(value) && value > 0f ? value : 0f;
    }

    @Override public synchronized void close() {
        if (closed) return;
        closed = true;
        closeInterpreter(interpreter);
        if (!letterboxedBitmap.isRecycled()) letterboxedBitmap.recycle();
    }

    private static void closeInterpreter(Interpreter value) {
        if (value != null) try { value.close(); } catch (RuntimeException ignored) { }
    }
}
