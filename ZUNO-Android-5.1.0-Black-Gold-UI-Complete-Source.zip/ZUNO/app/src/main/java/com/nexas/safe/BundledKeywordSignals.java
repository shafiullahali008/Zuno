package com.nexas.safe;

import android.content.Context;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Hash-only whole-token keyword matcher; no readable sensitive terms are packaged in the APK. */
final class BundledKeywordSignals {
    private static volatile long[] hashes = new long[0];
    private static volatile int maxTokens = 1;
    private BundledKeywordSignals() { }

    static synchronized void load(Context context) throws IOException {
        if (hashes.length > 0) return;
        try (InputStream stream = context.getAssets().open("pureview_keyword_hashes.bin");
             DataInputStream data = new DataInputStream(stream)) {
            byte[] magic = new byte[4];
            data.readFully(magic);
            if (!Arrays.equals(magic, new byte[]{'V','K','H','1'})) throw new IOException("Unknown keyword index format");
            int max = data.readInt();
            int count = data.readInt();
            if (max < 1 || max > 8 || count < 1 || count > 10_000) throw new IOException("Invalid keyword index size");
            long[] values = new long[count];
            for (int i = 0; i < count; i++) values[i] = data.readLong();
            if (data.read() != -1) throw new IOException("Unexpected data after keyword index");
            for (int i = 1; i < values.length; i++) if (values[i] < values[i - 1]) throw new IOException("Keyword index is not sorted");
            maxTokens = max;
            hashes = values;
        }
    }

    /** Returns the number of distinct blocked phrases found, capped at two. */
    static int distinctHits(String text) {
        long[] dictionary = hashes;
        if (text == null || text.isEmpty() || dictionary.length == 0) return 0;
        String decoded;
        try { decoded = URLDecoder.decode(text, StandardCharsets.UTF_8.name()); }
        catch (Exception ignored) { decoded = text.replace('+', ' '); }
        String prepared = decoded.toLowerCase(Locale.ROOT).replace('@', 'a').replace('$', 's');
        String[] tokens = prepared.split("[^a-z0-9]+");
        Set<Long> hits = new HashSet<>();
        for (int start = 0; start < tokens.length; start++) {
            if (tokens[start].isEmpty()) continue;
            StringBuilder phrase = new StringBuilder();
            for (int length = 1; length <= maxTokens && start + length <= tokens.length; length++) {
                String token = normalizeLeet(tokens[start + length - 1]);
                if (token.isEmpty()) break;
                if (phrase.length() > 0) phrase.append(' ');
                phrase.append(token);
                long phraseHash = hash(phrase.toString());
                boolean matched = Arrays.binarySearch(dictionary, phraseHash) >= 0;
                // Preserve PureView's whole-word singular/plural rule for single-token entries.
                if (!matched && length == 1 && tokens[start].length() >= 5 && tokens[start].endsWith("s")) {
                    matched = Arrays.binarySearch(dictionary, hash(normalizeLeet(tokens[start].substring(0, tokens[start].length() - 1)))) >= 0;
                }
                if (matched) {
                    hits.add(phraseHash);
                    if (hits.size() >= 2) return 2;
                }
            }
        }
        return hits.size();
    }

    static int size() { return hashes.length; }

    private static String normalizeLeet(String token) {
        boolean hasDigit = false, hasLetter = false;
        for (int i = 0; i < token.length(); i++) {
            char c = token.charAt(i);
            hasDigit |= c >= '0' && c <= '9';
            hasLetter |= c >= 'a' && c <= 'z';
        }
        if (!hasDigit || !hasLetter) return token;
        StringBuilder out = new StringBuilder(token.length());
        for (int i = 0; i < token.length(); i++) {
            char c = token.charAt(i);
            switch (c) {
                case '0': c = 'o'; break;
                case '1': c = 'i'; break;
                case '3': c = 'e'; break;
                case '4': c = 'a'; break;
                case '5': c = 's'; break;
                case '7': c = 't'; break;
                default: break;
            }
            out.append(c);
        }
        return out.toString();
    }

    private static long hash(String value) {
        long result = 0xcbf29ce484222325L;
        for (int i = 0; i < value.length(); i++) {
            result ^= value.charAt(i);
            result *= 0x100000001b3L;
        }
        return result;
    }
}
