package com.nexas.safe;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Map;

final class PrayerScheduler {
    private static final int REQUEST_BASE = 8100;
    private PrayerScheduler() { }

    static void scheduleUpcoming(Context context) {
        android.content.SharedPreferences prefs = PrayerPrefs.get(context);
        if (!prefs.getBoolean(PrayerPrefs.AZAN_ENABLED, true)) { cancelUpcoming(context); return; }
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;
        ZoneId zone = ZoneId.systemDefault();
        double lat = PrayerPrefs.latitude(context), lon = PrayerPrefs.longitude(context);
        int[] offsets = PrayerPrefs.offsets(context);
        ShiaPrayerCalculator.Method method = PrayerPrefs.method(context);
        LocalDate today = LocalDate.now(zone);
        cancelRange(context, today.minusDays(2), today.plusDays(2));
        for (int day = 0; day <= 2; day++) {
            LocalDate date = today.plusDays(day);
            Map<String, ZonedDateTime> times = ShiaPrayerCalculator.calculate(date, lat, lon, zone, method, offsets);
            String[] prayers = {"Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"};
            for (int i = 0; i < prayers.length; i++) {
                ZonedDateTime at = times.get(prayers[i]);
                if (at.toInstant().toEpochMilli() <= System.currentTimeMillis() + 1000L) continue;
                if (!PrayerPrefs.prayerAzanEnabled(context, prayers[i])) continue;
                PendingIntent pending = alarmIntent(context, date, prayers[i], i);
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && manager.canScheduleExactAlarms()) {
                        manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at.toInstant().toEpochMilli(), pending);
                    } else {
                        manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at.toInstant().toEpochMilli(), pending);
                    }
                } catch (SecurityException ex) {
                    try { manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at.toInstant().toEpochMilli(), pending); }
                    catch (RuntimeException ignored) { }
                }
            }
        }
    }

    static void cancelUpcoming(Context context) {
        LocalDate today = LocalDate.now(); cancelRange(context, today.minusDays(3), today.plusDays(4));
    }

    private static void cancelRange(Context context, LocalDate from, LocalDate to) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;
        for (LocalDate date = from; !date.isAfter(to); date = date.plusDays(1)) {
            String[] names = {"Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"};
            for (int i = 0; i < names.length; i++) manager.cancel(alarmIntent(context, date, names[i], i));
        }
    }

    private static PendingIntent alarmIntent(Context context, LocalDate date, String prayer, int index) {
        Intent intent = new Intent(context, PrayerAlarmReceiver.class)
                .setAction("com.nexas.safe.PRAYER_ALARM." + prayer)
                .putExtra("prayer_name", prayer)
                .putExtra("prayer_date", date.toString());
        int request = REQUEST_BASE + Math.floorMod(date.getDayOfYear(), 366) * 5 + index;
        return PendingIntent.getBroadcast(context, request, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
