package com.nexas.safe;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.ComponentName;
import android.provider.Settings;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

final class ProtectionPrefs {
    static final String PREFS = "nexas_safe_v2";
    static final String KEY_FOCUS_UNTIL = "focus_until";
    static final String KEY_BLOCKED_PACKAGES = "blocked_packages";
    static final String KEY_KEYWORD_PROTECTION = "keyword_protection";
    static final String KEY_CUSTOM_KEYWORDS = "custom_keywords";
    static final String KEY_REMINDER_HOUR = "reminder_hour";
    static final String KEY_REMINDER_MINUTE = "reminder_minute";
    static final String KEY_REMINDER_MESSAGE = "reminder_message";
    static final String KEY_REMINDER_ENABLED = "reminder_enabled";
    static final String KEY_CURRENT_PACKAGE = "current_package";
    static final String KEY_LIVE_SCAN = "live_scan";
    static final String KEY_STRICT_MODE = "strict_mode";
    static final String KEY_BLOCK_SCREEN_TEXT = "block_screen_text";
    static final String KEY_BLOCK_SCREEN_IMAGE = "block_screen_image";
    static final String KEY_STREAK_COUNT = "streak_count";
    static final String KEY_BEST_STREAK = "best_streak";
    static final String KEY_FOCUS_POINTS = "focus_points";
    static final String KEY_LAST_COMPLETED_DAY = "last_completed_day";
    static final String KEY_LAST_COMPLETED_UNTIL = "last_completed_until";
    static final String KEY_FOCUS_DURATION = "focus_duration";
    static final String KEY_FOCUS_STARTED_AT = "focus_started_at";
    static final String KEY_FOCUS_DURATION_LABEL = "focus_duration_label";
    static final String KEY_LAST_SYSTEM_RECOVERY_AT = "last_system_recovery_at";
    static final String KEY_LAST_SYSTEM_RECOVERY_ACTION = "last_system_recovery_action";
    static final String KEY_DAILY_INTENTION = "daily_intention";
    static final String KEY_DAILY_GOAL_MINUTES = "daily_goal_minutes";
    static final String KEY_FOCUS_DAY_KEY = "focus_day_key";
    static final String KEY_TODAY_FOCUS_MINUTES = "today_focus_minutes";
    static final String KEY_FOCUS_JOURNEY_ACTIVE = "focus_journey_active";
    static final String KEY_FOCUS_JOURNEY_STARTED_AT = "focus_journey_started_at";
    static final String KEY_FOCUS_JOURNEY_LAST_MS = "focus_journey_last_ms";
    static final String KEY_FOCUS_JOURNEY_BEST_LEVEL = "focus_journey_best_level";
    static final String KEY_ALL_IN_ONE_ACTIVE = "all_in_one_active";
    static final String KEY_ALL_IN_ONE_STARTED_AT = "all_in_one_started_at";
    static final String KEY_ALL_IN_ONE_END_AT = "all_in_one_end_at";
    static final String KEY_ALL_IN_ONE_DURATION_MS = "all_in_one_duration_ms";
    static final String KEY_ALL_IN_ONE_LAST_ELAPSED_MS = "all_in_one_last_elapsed_ms";
    static final String KEY_ALL_IN_ONE_DURATION_LABEL = "all_in_one_duration_label";
    static final String KEY_TEXT_MODEL_STATE = "text_model_state";
    static final String KEY_URL_MODEL_STATE = "url_model_state";
    static final String KEY_TEXT_MODEL_LAST_RESULT = "text_model_last_result";
    static final String KEY_URL_MODEL_LAST_RESULT = "url_model_last_result";
    static final String KEY_TEXT_MODEL_LAST_AT = "text_model_last_at";
    static final String KEY_URL_MODEL_LAST_AT = "url_model_last_at";

    private ProtectionPrefs() { }

    static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static boolean isJourneyActive(Context context) {
        return prefs(context).getBoolean(KEY_FOCUS_JOURNEY_ACTIVE, false);
    }

    static boolean isAllInOneActive(Context context) {
        return prefs(context).getBoolean(KEY_ALL_IN_ONE_ACTIVE, false);
    }

    static void recordSystemRecovery(Context context, String action) {
        prefs(context).edit()
                .putLong(KEY_LAST_SYSTEM_RECOVERY_AT, System.currentTimeMillis())
                .putString(KEY_LAST_SYSTEM_RECOVERY_ACTION, action == null ? "unknown" : action)
                .apply();
    }

    static boolean isFocusActive(Context context) {
        SharedPreferences saved = prefs(context);
        // All-in-One combines an elapsed streak with a fixed lock deadline. The deadline
        // takes precedence over the legacy open-ended journey flag.
        if (isAllInOneActive(context)) {
            return saved.getLong(KEY_ALL_IN_ONE_END_AT, 0L) > System.currentTimeMillis();
        }
        if (isJourneyActive(context)) return true;
        long until = saved.getLong(KEY_FOCUS_UNTIL, 0L);
        return until > System.currentTimeMillis();
    }

    static long focusUntil(Context context) {
        SharedPreferences saved = prefs(context);
        if (isAllInOneActive(context)) return saved.getLong(KEY_ALL_IN_ONE_END_AT, 0L);
        if (isJourneyActive(context)) return Long.MAX_VALUE;
        return saved.getLong(KEY_FOCUS_UNTIL, 0L);
    }

    static boolean isStrictMode(Context context) {
        return prefs(context).getBoolean(KEY_STRICT_MODE, false);
    }

    static Set<String> blockedPackages(Context context) {
        String raw = prefs(context).getString(KEY_BLOCKED_PACKAGES, "");
        if (raw == null || raw.trim().isEmpty()) return Collections.emptySet();
        Set<String> result = new HashSet<>();
        for (String item : raw.split("[,\\n; ]+")) {
            String pkg = item.trim().toLowerCase(Locale.ROOT);
            if (pkg.matches("[a-z0-9_]+(\\.[a-z0-9_]+)+") && !pkg.equals(context.getPackageName())) result.add(pkg);
        }
        return result;
    }

    static void saveBlockedPackages(Context context, Set<String> packages) {
        StringBuilder builder = new StringBuilder();
        for (String pkg : packages) {
            if (pkg == null || pkg.equals(context.getPackageName())) continue;
            if (builder.length() > 0) builder.append(',');
            builder.append(pkg);
        }
        prefs(context).edit().putString(KEY_BLOCKED_PACKAGES, builder.toString()).apply();
    }


    static boolean isAccessibilityEnabled(Context context) {
        String enabled = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        String target = new ComponentName(context, ProtectionAccessibilityService.class).flattenToString();
        for (String item : enabled.split(":")) if (target.equalsIgnoreCase(item)) return true;
        return false;
    }

    static String defaultKeywords() {
        return "porn video, porn videos, hentai video, hentai gallery, nude gallery, explicit photo gallery";
    }

    static boolean keywordProtectionEnabled(Context context) {
        return prefs(context).getBoolean(KEY_KEYWORD_PROTECTION, true);
    }

    static Set<String> keywords(Context context) {
        String raw = prefs(context).getString(KEY_CUSTOM_KEYWORDS, defaultKeywords());
        Set<String> result = new HashSet<>();
        if (raw == null) return result;
        for (String word : raw.toLowerCase(Locale.ROOT).split("[,\\n;]+")) {
            String value = word.trim();
            if (value.length() >= 3 && value.length() <= 40) result.add(value);
        }
        return result;
    }
}
