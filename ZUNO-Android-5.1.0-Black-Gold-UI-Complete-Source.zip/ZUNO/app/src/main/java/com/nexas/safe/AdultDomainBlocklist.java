package com.nexas.safe;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Offline adult-domain matcher. The bundled list is stored as hashes, not readable hostnames. */
final class AdultDomainBlocklist {
    private static final Pattern HOST_PATTERN = Pattern.compile("(?i)(?:https?://)?(?:www\\.)?([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+)");
    private volatile long[] hashes = new long[0];
    private volatile int domainCount;

    void load(InputStream input) throws IOException {
        try (DataInputStream data = new DataInputStream(input)) {
            byte[] magic = new byte[4];
            data.readFully(magic);
            if (!Arrays.equals(magic, new byte[]{'V','D','H','1'})) throw new IOException("Unknown domain index format");
            int sourceCount = data.readInt();
            int hashCount = data.readInt();
            if (sourceCount < 0 || hashCount < 0 || hashCount > 500_000) throw new IOException("Invalid domain index size");
            long[] values = new long[hashCount];
            for (int i = 0; i < hashCount; i++) values[i] = data.readLong();
            if (data.read() != -1) throw new IOException("Unexpected data after domain index");
            // The on-disk index is already sorted; verify once to prevent a corrupt silent allow-list.
            for (int i = 1; i < values.length; i++) {
                if (values[i] < values[i - 1]) throw new IOException("Domain index is not sorted");
            }
            hashes = values;
            domainCount = sourceCount;
        }
    }

    int domainCount() { return domainCount; }

    boolean containsBlockedDomain(String text) {
        if (text == null || text.isEmpty()) return false;
        Matcher matcher = HOST_PATTERN.matcher(text);
        while (matcher.find()) {
            String host = matcher.group(1).toLowerCase(java.util.Locale.ROOT);
            while (host.endsWith(".")) host = host.substring(0, host.length() - 1);
            if (matchesHost(host)) return true;
        }
        return false;
    }

    private boolean matchesHost(String host) {
        long[] current = hashes;
        String part = host;
        while (part.indexOf('.') > 0) {
            if (Arrays.binarySearch(current, hash(part)) >= 0) return true;
            int dot = part.indexOf('.');
            part = part.substring(dot + 1);
        }
        return false;
    }

    private static long hash(String value) {
        long result = 0xcbf29ce484222325L;
        for (int i = 0; i < value.length(); i++) {
            result ^= value.charAt(i);
            result *= 0x100000001b3L;
        }
        return result;
    }
}
