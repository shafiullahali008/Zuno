package com.nexas.safe;

import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

/** Installs the exact bundled NudeNet model locally; model downloads and arbitrary replacement are disabled. */
final class ModelManager {
    static final String MODEL_NAME = "nudenet_320n_fp16.tflite";
    private static final String ASSET_NAME = MODEL_NAME;
    private static final long MIN_SIZE = 5_000_000L;
    private static final long MAX_SIZE = 8_000_000L;
    private static final String EXPECTED_SHA256 = "b709083047bdf4b238aaaed24b5ec2a1e9e25647158e98c73e551969aaf39eff";
    private static volatile String verifiedPath = "";
    private static volatile long verifiedLength = -1L;
    private static volatile long verifiedModified = -1L;

    private ModelManager() { }

    static File modelFile(Context context) {
        File dir = new File(context.getNoBackupFilesDir(), "models");
        if (!dir.exists() && !dir.mkdirs() && !dir.isDirectory()) {
            throw new IllegalStateException("Could not create the local model directory");
        }
        return new File(dir, MODEL_NAME);
    }

    /** Ensures the bundled model is installed in private storage. Safe to call repeatedly. */
    static synchronized boolean isReady(Context context) {
        File target = null;
        File temp = null;
        try {
            target = modelFile(context);
            if (isValid(target)) return true;
            temp = new File(target.getParentFile(), MODEL_NAME + ".tmp");
            try (InputStream in = context.getAssets().open(ASSET_NAME);
                 FileOutputStream out = new FileOutputStream(temp, false)) {
                byte[] buffer = new byte[64 * 1024];
                int read;
                long count = 0L;
                while ((read = in.read(buffer)) != -1) {
                    count += read;
                    if (count > MAX_SIZE) throw new IllegalStateException("Bundled AI model exceeds supported size");
                    out.write(buffer, 0, read);
                }
                out.flush();
                out.getFD().sync();
            }
            if (!isValid(temp)) throw new IllegalStateException("Bundled AI model failed its integrity check");
            try {
                Files.move(temp.toPath(), target.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (Exception unsupported) {
                Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
            return isValid(target);
        } catch (Exception ex) {
            if (temp != null && temp.exists()) temp.delete();
            return false;
        }
    }

    private static boolean isValid(File file) {
        if (file == null || !file.isFile() || file.length() < MIN_SIZE || file.length() > MAX_SIZE || !hasTfliteHeader(file)) return false;
        String path = file.getAbsolutePath();
        long length = file.length();
        long modified = file.lastModified();
        if (path.equals(verifiedPath) && length == verifiedLength && modified == verifiedModified) return true;
        try {
            if (!EXPECTED_SHA256.equals(sha256(file))) return false;
            verifiedPath = path;
            verifiedLength = length;
            verifiedModified = modified;
            return true;
        } catch (Exception ignored) { return false; }
    }

    private static String sha256(File file) throws Exception {
        java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-256");
        try (InputStream in = new java.io.FileInputStream(file)) {
            byte[] buffer = new byte[64 * 1024];
            int read;
            while ((read = in.read(buffer)) != -1) digest.update(buffer, 0, read);
        }
        StringBuilder hex = new StringBuilder(64);
        for (byte value : digest.digest()) hex.append(String.format(java.util.Locale.ROOT, "%02x", value & 0xff));
        return hex.toString();
    }

    private static boolean hasTfliteHeader(File file) {
        try (InputStream in = new java.io.FileInputStream(file)) {
            byte[] header = new byte[8];
            return in.read(header) == 8 && new String(header, 4, 4, StandardCharsets.US_ASCII).equals("TFL3");
        } catch (Exception ignored) { return false; }
    }
}
