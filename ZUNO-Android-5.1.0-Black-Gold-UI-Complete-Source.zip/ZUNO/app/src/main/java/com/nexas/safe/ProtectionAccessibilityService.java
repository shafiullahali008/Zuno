package com.nexas.safe;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.Context;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.Locale;
import java.util.Set;

/** User-enabled, local-only service for selected-app focus rules and page-text checks. It does not capture the screen. */
public class ProtectionAccessibilityService extends AccessibilityService {
    private static final long MIN_SCAN_INTERVAL_MS = 850L;
    private static final int MAX_TEXT_CHARS = 7000;
    private static final int MAX_VISITED_NODES = 600;
    private long lastTextScanAt;
    private String lastScannedPackage = "";
    private String lastCurrentPackage = "";
    private int lastTextHash;
    private long lastBlockAt;
    private AdultDomainBlocklist adultDomainBlocklist;
    private PureViewTextRiskModel textRiskModel;
    private PureViewUrlRiskModel urlRiskModel;
    private static final Set<String> SUPPORTED_BROWSERS = new java.util.HashSet<>(java.util.Arrays.asList(
            "com.android.chrome", "com.chrome.beta", "com.chrome.dev", "com.chrome.canary",
            "org.mozilla.firefox", "org.mozilla.firefox_beta", "org.mozilla.fenix", "org.mozilla.focus",
            "com.sec.android.app.sbrowser", "com.sec.android.app.sbrowser.beta", "com.microsoft.emmx",
            "com.brave.browser", "com.duckduckgo.mobile.android", "com.vivaldi.browser", "com.opera.browser",
            "com.mi.globalbrowser", "com.android.browser", "com.mi.globalbrowser.mini"));

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        try {
            AdultDomainBlocklist list = new AdultDomainBlocklist();
            list.load(getAssets().open("adult_domains.hashes"));
            adultDomainBlocklist = list;
        } catch (Exception ignored) { adultDomainBlocklist = null; }
        try { BundledKeywordSignals.load(this); } catch (Exception ignored) { }
        // These are supplemental prototype models. They report advisory signals only;
        // the synthetic-seed models are deliberately not used as automatic block authorities.
        try { textRiskModel = new PureViewTextRiskModel(this); } catch (Exception ignored) { textRiskModel = null; }
        try { urlRiskModel = new PureViewUrlRiskModel(this); } catch (Exception ignored) { urlRiskModel = null; }
        ProtectionPrefs.prefs(this).edit()
                .putString(ProtectionPrefs.KEY_TEXT_MODEL_STATE,
                        textRiskModel != null && textRiskModel.isReady() ? "READY" : "MISSING_OR_INCOMPATIBLE")
                .putString(ProtectionPrefs.KEY_URL_MODEL_STATE,
                        urlRiskModel != null && urlRiskModel.isReady() ? "READY" : "MISSING_OR_INCOMPATIBLE")
                .apply();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        String packageName = event.getPackageName().toString();
        if (!packageName.equals(lastCurrentPackage)) {
            lastCurrentPackage = packageName;
            ProtectionPrefs.prefs(this).edit().putString(ProtectionPrefs.KEY_CURRENT_PACKAGE, packageName).apply();
        }
        if (packageName.equals(getPackageName()) || packageName.equals("com.android.systemui")) return;

        if (ProtectionPrefs.isFocusActive(this)
                && ProtectionPrefs.blockedPackages(this).contains(packageName.toLowerCase(Locale.ROOT))) {
            performGlobalAction(GLOBAL_ACTION_HOME);
            showBlockScreen("focus");
            return;
        }

        if (!ProtectionPrefs.keywordProtectionEnabled(this)) return;
        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                && type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                && type != AccessibilityEvent.TYPE_VIEW_SCROLLED) return;

        long now = android.os.SystemClock.uptimeMillis();
        boolean packageChanged = !packageName.equals(lastScannedPackage);
        if (!packageChanged && now - lastTextScanAt < MIN_SCAN_INTERVAL_MS) return;
        lastScannedPackage = packageName;
        lastTextScanAt = now;

        StringBuilder pageText = new StringBuilder(1024);
        for (CharSequence text : event.getText()) appendText(pageText, text);
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) {
            try { collectVisibleText(root, 0, pageText, new int[]{MAX_VISITED_NODES}); }
            finally { root.recycle(); }
        }
        if (pageText.length() == 0) return;
        int textHash = pageText.toString().hashCode();
        if (textHash == lastTextHash && !packageChanged) return;
        lastTextHash = textHash;
        String visibleText = pageText.toString();
        runSupplementalModels(visibleText, SUPPORTED_BROWSERS.contains(packageName));
        if (SUPPORTED_BROWSERS.contains(packageName) && adultDomainBlocklist != null) {
            if (adultDomainBlocklist.containsBlockedDomain(visibleText)) {
                showBlockScreen("website");
                return;
            }
        }
        Set<String> customKeywords = ProtectionPrefs.keywords(this);
        int bundledHits = BundledKeywordSignals.distinctHits(visibleText);
        if (ContextAwareTextClassifier.shouldBlock(visibleText, customKeywords, bundledHits)) {
            showBlockScreen("keyword");
        }
    }

    private void runSupplementalModels(String visibleText, boolean browser) {
        long now = System.currentTimeMillis();
        if (textRiskModel != null) {
            PureViewModelResult result = textRiskModel.classify(visibleText);
            ProtectionPrefs.prefs(this).edit()
                    .putString(ProtectionPrefs.KEY_TEXT_MODEL_LAST_RESULT, result.decision.name())
                    .putLong(ProtectionPrefs.KEY_TEXT_MODEL_LAST_AT, now)
                    .apply();
        } else {
            ProtectionPrefs.prefs(this).edit()
                    .putString(ProtectionPrefs.KEY_TEXT_MODEL_LAST_RESULT, "UNKNOWN")
                    .putLong(ProtectionPrefs.KEY_TEXT_MODEL_LAST_AT, now).apply();
        }

        if (!browser) return;
        String candidate = extractVisibleUrl(visibleText);
        if (candidate.isEmpty()) return;
        PureViewModelResult result = urlRiskModel == null
                ? new PureViewModelResult(PureViewModelResult.Decision.UNKNOWN,
                    "URL model unavailable", 0f, "Missing or incompatible model")
                : urlRiskModel.classify(candidate);
        ProtectionPrefs.prefs(this).edit()
                .putString(ProtectionPrefs.KEY_URL_MODEL_LAST_RESULT, result.decision.name())
                .putLong(ProtectionPrefs.KEY_URL_MODEL_LAST_AT, now)
                .apply();
    }

    private static String extractVisibleUrl(String text) {
        if (text == null || text.isEmpty()) return "";
        java.util.regex.Matcher matcher = java.util.regex.Pattern
                .compile("(?i)(https?://[^\\s<>\"']+|www\\.[^\\s<>\"']+)")
                .matcher(text);
        if (!matcher.find()) {
            // Browser address bars often expose the bare hostname rather than a scheme.
            matcher = java.util.regex.Pattern
                    .compile("(?i)(?<![a-z0-9._%+-])((?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+(?:com|net|org|edu|gov|mil|int|io|ai|co|uk|pk|us|info|biz|me|app|dev|xyz|online|site|store|cloud|tech)(?::[0-9]{1,5})?(?:/[^\\s<>\"']*)?)")
                    .matcher(text);
            if (!matcher.find()) return "";
        }
        String value = matcher.group(1);
        while (!value.isEmpty() && ".,;:!?)]}".indexOf(value.charAt(value.length() - 1)) >= 0) {
            value = value.substring(0, value.length() - 1);
        }
        return value;
    }

    private void collectVisibleText(AccessibilityNodeInfo node, int depth, StringBuilder out, int[] remainingNodes) {
        if (node == null || depth > 18 || out.length() >= MAX_TEXT_CHARS || remainingNodes[0] <= 0) return;
        remainingNodes[0]--;
        appendText(out, node.getText());
        appendText(out, node.getContentDescription());
        int count = Math.min(node.getChildCount(), 55);
        for (int i = 0; i < count && out.length() < MAX_TEXT_CHARS; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { collectVisibleText(child, depth + 1, out, remainingNodes); }
                finally { child.recycle(); }
            }
        }
    }

    private void appendText(StringBuilder out, CharSequence value) {
        if (value == null || out.length() >= MAX_TEXT_CHARS) return;
        String text = value.toString().trim();
        if (text.isEmpty()) return;
        if (out.length() > 0) out.append(' ');
        int remaining = MAX_TEXT_CHARS - out.length();
        out.append(text, 0, Math.min(text.length(), remaining));
    }

    private void showBlockScreen(String reason) {
        long now = android.os.SystemClock.uptimeMillis();
        if (lastBlockAt != 0L && now - lastBlockAt < 2200L) return;
        lastBlockAt = now;
        Intent intent = new Intent(this, BlockActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra("reason", reason);
        startActivity(intent);
    }

    @Override public void onInterrupt() { }

    @Override public void onDestroy() {
        if (textRiskModel != null) textRiskModel.close();
        if (urlRiskModel != null) urlRiskModel.close();
        ProtectionPrefs.prefs(this).edit()
                .putString(ProtectionPrefs.KEY_TEXT_MODEL_STATE, "SERVICE_STOPPED")
                .putString(ProtectionPrefs.KEY_URL_MODEL_STATE, "SERVICE_STOPPED")
                .apply();
        super.onDestroy();
    }
}
