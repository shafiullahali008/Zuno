package com.nexas.safe;

/** Explicit three-state result: model failure is UNKNOWN, never SAFE. */
final class PureViewModelResult {
    enum Decision { FLAG, SAFE_CANDIDATE, UNKNOWN }
    final Decision decision;
    final String label;
    final float score;
    final String limitation;
    PureViewModelResult(Decision d, String l, float s, String note) {
        decision=d; label=l; score=s; limitation=note;
    }
}
