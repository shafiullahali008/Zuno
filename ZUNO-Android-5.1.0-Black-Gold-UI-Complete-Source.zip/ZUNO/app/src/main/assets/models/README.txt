Bundled trained prototype models:
- text_safety.tflite: basic text-risk screening (synthetic training examples)
- url_risk.tflite: URL-pattern screening (synthetic training examples)

Optional weights not bundled:
- nsfw_classifier.tflite (image moderation)
- yamnet.tflite and yamnet_class_map.csv (audio-event classification)
- efficientdet_lite0.tflite (object detection)

Missing model weights return UNKNOWN. Do not treat prototype scores as a guarantee.
