# Model asset provisioning

Run `python tools/provision_models.py` from the project root on a machine with internet access. The script downloads verified TFLite assets, checks the TFL3 signature and minimum expected size, pins YAMNet's SHA-256, and writes `provision_report.json`.

Included at package creation: `text_safety.tflite` and `url_risk.tflite`. Both were trained on synthetic data and are prototypes only.

Optional external downloads:

- `nsfw_classifier.tflite`: GantMan MobileNetV2 224x224 five-class image-screening model, used by image screening and sampled video-frame screening.
- `yamnet.tflite` + `yamnet_class_map.csv`: 521-class sound-event classification. It does not transcribe or moderate spoken words.
- `asr/whisper_tiny_30s_i8.litertlm`: optional multilingual speech-to-text bundle. It requires LiteRT-LM Omni and has not been integrated into the Android app; it is not a standard `.tflite` model.

ML Kit object detection is separate from these downloads. Its model is managed by Google Play services. The app requests install-time module download; check on a physical device that it has completed before relying on offline use.

Deepfake detection and production-quality harmful-speech moderation remain unimplemented. Do not replace those gaps with dummy model files or heuristic claims.
