package com.nexas.safe;

import org.junit.Test;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.ByteArrayInputStream;
import static org.junit.Assert.*;

public class AdultDomainBlocklistTest {
    private static long hash(String value) {
        long result = 0xcbf29ce484222325L;
        for (int i = 0; i < value.length(); i++) {
            result ^= value.charAt(i);
            result *= 0x100000001b3L;
        }
        return result;
    }

    @Test public void matchesHostAndParentDomain() throws Exception {
        String host = "blocked.invalid";
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (DataOutputStream out = new DataOutputStream(bytes)) {
            out.write(new byte[]{'V','D','H','1'});
            out.writeInt(1);
            out.writeInt(1);
            out.writeLong(hash(host));
        }
        AdultDomainBlocklist list = new AdultDomainBlocklist();
        list.load(new ByteArrayInputStream(bytes.toByteArray()));
        assertTrue(list.containsBlockedDomain("https://sub.blocked.invalid/path"));
        assertFalse(list.containsBlockedDomain("https://safe.invalid/path"));
    }
}
