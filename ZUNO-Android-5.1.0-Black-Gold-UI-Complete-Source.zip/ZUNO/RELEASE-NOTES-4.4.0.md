# VYRA 4.4.0 — PureView protection/model merge

- Bundled NudeNet 320n TFLite model and offline first-use installation.
- Reworked visual classifier for the actual 320n tensor layout and upstream per-anchor class decoding.
- Added local image scanning and sampled scanning of user-selected video files.
- Added offline hashed website-domain and keyword indexes from PureView.
- Connected local URL/text checks to VYRA's existing supported-browser Accessibility service.
- Kept VYRA's light UI, Focus, 7-Layer protection, and existing games; no duplicate game pack or Compose UI imported.
- No screen sharing, screenshot capture, recording, or Internet permission.
- Full Gradle build and Android 16 device/game runtime test remain unverified in this environment.
