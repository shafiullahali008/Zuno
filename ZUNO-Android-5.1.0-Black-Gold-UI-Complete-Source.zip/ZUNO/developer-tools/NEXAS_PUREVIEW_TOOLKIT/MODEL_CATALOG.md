# NEXAS PUREVIEW — Model and capability catalog (v0.3.1)

| Capability | State in this package | Notes |
|---|---|---|
| Text risk screening | Trained prototype included | Synthetic examples only. Not production-grade, especially for Urdu/Roman Urdu. |
| URL pattern screening | Trained prototype included | Synthetic URL patterns only. Not a threat-intelligence service. |
| Image content safety | Adapter included; weights provisionable | Requires `nsfw_classifier.tflite`; otherwise result is `UNKNOWN`. |
| Video frame screening | Sampler included; depends on image model | Samples frames at an interval. It does not inspect every frame and cannot guarantee that a video is safe. |
| OCR | Bundled ML Kit dependency | Extracts Latin-script text as a utility signal; does not judge safety. |
| Face detection | Bundled ML Kit dependency | Detects face regions; does not identify people or judge safety. |
| General image labels | Bundled ML Kit dependency | Generic labels are context only. |
| Object detection | ML Kit API; Play Services-managed model | Generic object classes; app requests install-time download. Verify readiness on device before offline use. |
| Audio events | Adapter included; YAMNet weights provisionable | 521 sound-event classes; does not transcribe or moderate spoken language. |
| Speech-to-text | Whisper Tiny LiteRT-LM model provisionable | Requires LiteRT-LM Omni native runtime; not integrated into this Android app. Default decoder prefix targets English. |
| Harmful-speech classification | Not complete | Needs accurate offline ASR and real, labelled, independently tested text moderation. |
| Deepfake detection | Not complete | No broad, verified mobile TFLite model selected. Requires a defined detection target and task-specific evaluation. |
| Urdu / Roman Urdu safety | Prototype only | Synthetic seed examples are insufficient for real-world coverage. |

## Important safety and quality behavior

- Missing, incompatible or failing specialist models return `UNKNOWN`, never silently `SAFE`.
- `SAFE_CANDIDATE` only means the current model did not cross its threshold; it is not a guarantee.
- OCR, object labels, face boxes and audio-event labels are utility signals, not safety verdicts.
- The existing text and URL weights are small synthetic-data prototypes. Their synthetic holdout metrics are not evidence of real-world accuracy.

## Model setup

Use `provision_all_models_windows.bat` on Windows, or run `python tools/provision_models.py` from the project root. It provisions YAMNet, its labels, an image-safety classifier, and the optional Whisper Tiny LiteRT-LM bundle. It writes a report with byte counts and SHA-256 hashes. The current archive does not include those external binary model weights because this environment cannot reach external download hosts.

## References

- LiteRT overview: https://developers.google.com/edge/litert/overview
- ML Kit guides: https://developers.google.com/ml-kit/guides
- ML Kit object detection installation: https://developers.google.com/ml-kit/vision/object-detection/android
- YAMNet Android codelab: https://developers.google.com/codelabs/tflite-audio-classification-basic-android
- Whisper Tiny LiteRT model card: https://huggingface.co/litert-community/whisper-tiny
- GantMan NSFW model: https://github.com/GantMan/nsfw_model
