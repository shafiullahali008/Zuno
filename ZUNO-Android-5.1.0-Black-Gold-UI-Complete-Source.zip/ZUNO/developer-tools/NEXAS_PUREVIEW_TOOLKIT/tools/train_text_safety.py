#!/usr/bin/env python3
"""Train text_safety.tflite from a labelled CSV using hashed-word features.

CSV columns: text,label (0=benign candidate, 1=flag). Labels should cover
bullying, threats, scams, and benign context in the intended languages.
Use a lawful, representative dataset and hold out real-world evaluation data.
"""
from __future__ import annotations
import json, pathlib, re, sys
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix
from write_linear_tflite import make_linear_tflite
from sync_model_hashes import sync_hashes



def find_project_root() -> pathlib.Path:
    """Find the VYRA root when this toolkit is nested under developer-tools/."""
    script = pathlib.Path(__file__).resolve()
    for parent in script.parents:
        if (parent / "settings.gradle").is_file() and (parent / "app/src/main/assets/models").is_dir():
            return parent
    raise RuntimeError("Could not locate the VYRA project root (expected settings.gradle and app/src/main/assets/models)")

TOOLKIT_ROOT = pathlib.Path(__file__).resolve().parents[1]
PROJECT_ROOT = find_project_root()

OUT = PROJECT_ROOT / "app/src/main/assets/models"
DIM = 512

def token_hash(token: str) -> int:
    h = 2166136261
    for byte in token.encode("utf-8"):
        h ^= byte
        h = (h * 16777619) & 0xffffffff
    return h % DIM

def encode(text: str) -> np.ndarray:
    x = np.zeros(DIM, dtype=np.float32)
    for token in re.findall(r"[^\W_]+", str(text).lower(), flags=re.UNICODE):
        x[token_hash(token)] = 1.0
    return x

def main(csv_path: str) -> int:
    df = pd.read_csv(csv_path)
    if not {"text", "label"}.issubset(df.columns):
        raise ValueError("CSV must contain text,label columns")
    df = df.dropna(subset=["text", "label"])
    y = df.label.astype(int).to_numpy()
    if len(df) < 200 or set(np.unique(y)) != {0, 1}: raise ValueError("Need >=200 labelled rows and labels 0 and 1")
    x = np.stack([encode(t) for t in df.text])
    xtr, xte, ytr, yte = train_test_split(x, y, test_size=0.2, random_state=42, stratify=y)
    model = LogisticRegression(C=2.0, max_iter=1500, class_weight="balanced", random_state=42)
    model.fit(xtr, ytr)
    pred = model.predict(xte)
    p, r, f, _ = precision_recall_fscore_support(yte, pred, average="binary", zero_division=0)
    weights = np.vstack([np.zeros(DIM, np.float32), model.coef_[0].astype(np.float32)])
    bias = np.asarray([0.0, float(model.intercept_[0])], dtype=np.float32)
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "text_safety.tflite").write_bytes(make_linear_tflite(weights, bias, DIM, "NEXAS PUREVIEW trained text safety linear model; logits."))
    sync_hashes()  # Update the Java model pin and shared checksum manifest.
    metrics = {"training_rows": len(xtr), "test_rows": len(xte), "accuracy": float(accuracy_score(yte, pred)),
               "precision": float(p), "recall": float(r), "f1": float(f), "confusion_matrix": confusion_matrix(yte, pred).tolist(),
               "input_shape": [1, DIM], "feature": "FNV-1a word hashing", "labels": {"0":"benign candidate", "1":"flag"},
               "test_source": "CSV holdout; confirm that it is representative before trusting these metrics"}
    (OUT / "text_safety_metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    (OUT / "text_model_config.json").write_text(json.dumps({"input_shape":[1,DIM],"feature":"FNV-1a token hashing","threshold":0.70,"output":"raw logits; apply softmax"}, indent=2), encoding="utf-8")
    print(json.dumps(metrics, indent=2))
    return 0

if __name__ == "__main__":
    if len(sys.argv) != 2: raise SystemExit("Usage: python tools/train_text_safety.py path/to/text.csv")
    raise SystemExit(main(sys.argv[1]))
