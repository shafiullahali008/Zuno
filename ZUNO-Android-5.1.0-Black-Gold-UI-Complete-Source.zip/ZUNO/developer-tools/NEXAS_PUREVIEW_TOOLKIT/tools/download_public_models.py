#!/usr/bin/env python3
"""Backward-compatible wrapper for the v0.3.1 model provisioner."""
from provision_models import main
if __name__ == "__main__":
    raise SystemExit(main())
