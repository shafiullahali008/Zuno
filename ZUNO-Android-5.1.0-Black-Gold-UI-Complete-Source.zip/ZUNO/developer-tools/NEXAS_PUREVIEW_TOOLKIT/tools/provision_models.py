#!/usr/bin/env python3
"""Provision public on-device models for NEXAS PUREVIEW.

Run with internet access:
    python tools/provision_models.py

This script downloads real third-party model artifacts; it never invents weights.
A download is installed only after file-signature/size checks. SHA-256 is recorded
for every downloaded file. The deepfake model is deliberately not fabricated:
there is no general-purpose, mobile-ready TFLite artifact in this package that
can be verified for this use case.
"""
from __future__ import annotations
import hashlib, json, pathlib, sys, urllib.request
from typing import Any



def find_project_root() -> pathlib.Path:
    """Find the VYRA root when this toolkit is nested under developer-tools/."""
    script = pathlib.Path(__file__).resolve()
    for parent in script.parents:
        if (parent / "settings.gradle").is_file() and (parent / "app/src/main/assets/models").is_dir():
            return parent
    raise RuntimeError("Could not locate the VYRA project root (expected settings.gradle and app/src/main/assets/models)")

TOOLKIT_ROOT = pathlib.Path(__file__).resolve().parents[1]
PROJECT_ROOT = find_project_root()

MODELS = PROJECT_ROOT / "app" / "src" / "main" / "assets" / "models"
ASR_DIR = MODELS / "asr"
MODELS.mkdir(parents=True, exist_ok=True)

# Official YAMNet mirror; SHA-256 comes from Google's Flutter/MediaPipe model registry.
ASSETS: dict[str, dict[str, Any]] = {
    "yamnet.tflite": {
        "url": "https://storage.googleapis.com/mediapipe-models/audio_classifier/yamnet/float32/1/yamnet.tflite",
        "min_bytes": 1_000_000,
        "sha256": "4d8b4a53282dc83ef04e3e7dbc4fbc98082e34e44ed798e16c3a0cdd4c584faf",
        "license": "Apache-2.0 (Google MediaPipe model distribution; verify upstream notice before redistribution)",
        "purpose": "521-class audio-event classification; not speech moderation",
    },
    "yamnet_class_map.csv": {
        "url": "https://storage.googleapis.com/audioset/yamnet_class_map.csv",
        "min_bytes": 1_000,
        "sha256": None,
        "license": "AudioSet/YAMNet class-map terms; retain upstream attribution",
        "purpose": "YAMNet class labels",
    },
    "nsfw_classifier.tflite": {
        "url": "https://raw.githubusercontent.com/AceWaffles/ImageModerationService/main/models/gantman_mobilenet_v2_140_224.tflite",
        "min_bytes": 3_000_000,
        "sha256": None,
        "license": "MIT attribution for the unmodified GantMan nsfw_model weights; see THIRD_PARTY_ATTRIBUTION.md",
        "purpose": "Image content-safety screening; MobileNetV2 224x224 RGB float32 [0,1], five output classes",
    },
}

def sha256(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def is_tflite(path: pathlib.Path) -> bool:
    try:
        with path.open("rb") as f:
            head = f.read(8)
        return len(head) == 8 and head[4:8] == b"TFL3"
    except OSError:
        return False

def download_one(name: str, meta: dict[str, Any]) -> dict[str, Any]:
    target = MODELS / name
    temp = target.with_suffix(target.suffix + ".part")
    req = urllib.request.Request(meta["url"], headers={"User-Agent": "NEXAS-PUREVIEW-model-provisioner/0.3"})
    print(f"Downloading {name} ...")
    try:
        with urllib.request.urlopen(req, timeout=120) as response, temp.open("wb") as out:
            final_url = response.geturl()
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                out.write(chunk)
        size = temp.stat().st_size
        if size < int(meta["min_bytes"]):
            raise RuntimeError(f"unexpectedly small response ({size} bytes); likely a web error or LFS pointer")
        if name.endswith(".tflite") and not is_tflite(temp):
            raise RuntimeError("file does not have the TensorFlow Lite TFL3 signature")
        digest = sha256(temp)
        expected = meta.get("sha256")
        if expected and digest.lower() != expected.lower():
            raise RuntimeError(f"SHA-256 mismatch: expected {expected}, received {digest}")
        temp.replace(target)
        return {"file": name, "bytes": size, "sha256": digest, "url": final_url,
                "license": meta["license"], "purpose": meta["purpose"], "state": "downloaded_and_signature_checked"}
    finally:
        temp.unlink(missing_ok=True)

def download_whisper() -> dict[str, Any]:
    """Download the self-contained LiteRT-LM Whisper Tiny bundle (not a plain TFLite file)."""
    ASR_DIR.mkdir(parents=True, exist_ok=True)
    try:
        from huggingface_hub import hf_hub_download
    except ImportError:
        return {"file": "whisper_tiny_30s_i8.litertlm", "state": "not_downloaded",
                "reason": "Install huggingface_hub: python -m pip install huggingface_hub"}
    print("Downloading Whisper Tiny LiteRT-LM bundle (~42 MB) ...")
    path = pathlib.Path(hf_hub_download(
        repo_id="litert-community/whisper-tiny",
        filename="whisper_tiny_30s_i8.litertlm",
        local_dir=str(ASR_DIR),
    ))
    if path.stat().st_size < 10_000_000:
        raise RuntimeError("Whisper bundle is unexpectedly small; refusing to mark it ready")
    return {"file": str(path.relative_to(PROJECT_ROOT)), "bytes": path.stat().st_size,
            "sha256": sha256(path), "source": "https://huggingface.co/litert-community/whisper-tiny",
            "license": "Apache-2.0", "state": "downloaded_but_requires_litert_lm_omni_runtime",
            "note": "This is a .litertlm bundle, not a plain Interpreter-ready .tflite model."}

def main() -> int:
    successes, failures = [], []
    for name, meta in ASSETS.items():
        try:
            successes.append(download_one(name, meta))
        except Exception as e:
            failures.append({"file": name, "state": "missing", "error": str(e)})
            print(f"FAILED {name}: {e}", file=sys.stderr)
    try:
        asr = download_whisper()
    except Exception as e:
        asr = {"file": "whisper_tiny_30s_i8.litertlm", "state": "download_failed", "error": str(e)}
        print(f"Whisper optional download failed: {e}", file=sys.stderr)
    report = {
        "bundle_version": "0.3.1",
        "downloaded": successes,
        "failed": failures,
        "speech_to_text": asr,
        "not_provisioned": [
            {"component": "general-purpose deepfake detection", "reason": "No verified, general-purpose, mobile-ready model selected; must define target and test domain first."},
            {"component": "production text/speech moderation", "reason": "Requires a licensed representative dataset and real held-out evaluation; synthetic seed weights remain prototype-only."},
            {"component": "object detection offline readiness", "reason": "ML Kit object detection is managed by Google Play services; download/install the model before relying on offline use."}
        ],
    }
    (MODELS / "provision_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")

    # Keep the machine-readable inventory synchronized with files actually present.
    status_path = MODELS / "MODEL_STATUS.json"
    if status_path.exists():
        current = json.loads(status_path.read_text(encoding="utf-8"))
        for item in current.get("provisionable_optional_assets", []):
            rel = pathlib.Path(item.get("file", ""))
            candidate = MODELS / rel
            if candidate.is_file() and candidate.stat().st_size > 0:
                if rel.suffix == ".tflite" and not is_tflite(candidate):
                    item["state"] = "invalid_file_signature"
                else:
                    item["state"] = "present_locally; check provision_report.json"
            else:
                item["state"] = "missing"
        status_path.write_text(json.dumps(current, indent=2), encoding="utf-8")
        root_status = TOOLKIT_ROOT / "MODEL_STATUS.json"
        root_status.write_text(json.dumps(current, indent=2), encoding="utf-8")

    print(f"\nModel provisioning finished: {len(successes)} downloaded, {len(failures)} failed.")
    print(f"Report: {MODELS / 'provision_report.json'}")
    return 0 if not failures else 2

if __name__ == "__main__":
    raise SystemExit(main())
