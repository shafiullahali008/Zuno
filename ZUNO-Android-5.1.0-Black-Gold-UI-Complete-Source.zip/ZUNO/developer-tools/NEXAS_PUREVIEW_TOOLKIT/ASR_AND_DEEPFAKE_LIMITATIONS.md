# ASR and deepfake limitations

## Offline speech-to-text

The optional Whisper Tiny package is available from LiteRT Community as a self-contained `.litertlm` bundle. It contains a multilingual Whisper Tiny model, tokenizer, and audio preprocessing metadata, and is documented for LiteRT-LM Omni. Its model card notes that the default decoder prefix targets English; other language prefixes must be set explicitly. It is **not** loadable by the existing generic `Interpreter` adapter. Android app integration requires adding the LiteRT-LM Omni native runtime, NDK/Bazel build outputs, audio resampling, stream/session code, and testing on supported ABIs. The bundle is therefore kept out of the APK until that runtime is integrated.

Even after transcription is available, transcript moderation depends on a separate text-safety model trained and validated on the target languages. Whisper transcription itself is not a harmful-speech classifier.

## Deepfake detection

No fake `.tflite` file is included. Deepfake detection is task-sensitive: face-swap video, synthetic portrait images, voice cloning, and manipulated audio have different data and evaluation requirements. Before creating a model, define the target modality and threat type, use a licensed dataset with suitable rights, prevent identity leakage between train/test splits, validate across generators/codecs/devices, and report false positives and false negatives. A generic edge classifier without this work would give users false confidence.
