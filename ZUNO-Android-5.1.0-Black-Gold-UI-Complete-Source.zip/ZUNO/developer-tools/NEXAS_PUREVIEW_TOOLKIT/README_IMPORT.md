# NEXAS PureView model toolkit retained with VYRA

This folder retains the model training/provisioning scripts, seed data and metadata from the supplied NEXAS_PUREVIEW_AI 0.3.1 archive. It is developer tooling only; it is not a second Android app and is not part of VYRA's Gradle runtime.

The `text_safety.tflite` and `url_risk.tflite` model files are already in `app/src/main/assets/models/` and are used by VYRA's Java adapters. Both are synthetic-seed prototypes and their live output is advisory only.

Optional models were not included in the source ZIP: `nsfw_classifier.tflite`, `yamnet.tflite`, `yamnet_class_map.csv` and the Whisper `.litertlm` bundle. The scripts can provision some optional weights from an internet-connected development machine. Review licenses, hashes, upstream terms and compatibility before redistributing any downloaded binary. Do not place a downloaded file in VYRA's assets until its adapter/runtime is integrated and device-tested.

The toolkit was kept separate to avoid adding a second Android application or mixing its Kotlin/ML Kit/LiteRT-LM dependencies into the Java VYRA app.
