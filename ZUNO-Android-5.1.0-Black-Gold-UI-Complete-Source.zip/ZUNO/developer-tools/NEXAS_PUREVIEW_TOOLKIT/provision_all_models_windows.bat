@echo off
setlocal
cd /d %~dp0
where py >nul 2>nul
if errorlevel 1 goto use_python
py -3.11 -m pip install --upgrade huggingface_hub
if errorlevel 1 py -3.12 -m pip install --upgrade huggingface_hub
py -3.11 tools\provision_models.py
if errorlevel 1 py -3.12 tools\provision_models.py
if errorlevel 1 echo Model provisioning reported failures. Review provision_report.json.
goto done
:use_python
python -m pip install --upgrade huggingface_hub
python tools\provision_models.py
if errorlevel 1 echo Model provisioning reported failures. Review provision_report.json.
:done
echo.
echo Review app\src\main\assets\models\provision_report.json
pause
