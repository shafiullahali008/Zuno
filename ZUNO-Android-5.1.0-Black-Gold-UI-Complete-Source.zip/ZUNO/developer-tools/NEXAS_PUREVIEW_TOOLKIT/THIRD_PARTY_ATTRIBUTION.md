# Third-party components and attribution (v0.3.1)

- **Google ML Kit:** bundled Android dependencies provide Latin-script text recognition, face detection and image labeling. Object detection uses the separate `com.google.mlkit:object-detection` API and a Google Play-services-managed model, which must be downloaded before first use. These outputs are utilities, not safety verdicts.
- **Google YAMNet:** optional download from the official Google MediaPipe model distribution. YAMNet classifies 521 AudioSet sound-event labels; it is not a speech moderation model. Retain relevant Google/AudioSet attribution and licensing notices when redistributing weights.
- **GantMan `nsfw_model` MobileNetV2:** optional image-safety weights provisioned as `nsfw_classifier.tflite`. The upstream project lists five output categories: `drawings`, `hentai`, `neutral`, `porn`, `sexy`. Its repository is MIT-licensed; include `app/src/main/assets/models/third_party_licenses/GANTMAN_NSFW_MODEL_MIT.txt` with redistributed weights. Model reference: https://github.com/GantMan/nsfw_model.
- **Whisper Tiny / LiteRT Community:** optional speech-to-text `.litertlm` bundle distributed under Apache-2.0 according to its model card. It requires LiteRT-LM Omni and is not wired into the current Android app.
- **Text and URL prototype weights:** generated locally using the scripts in `tools/` from synthetic examples. They are original prototype artifacts, not production moderation models.

Original Kotlin/Python glue code and synthetic seed data are provided under the repository MIT License in `LICENSE`. Third-party library and model terms remain separate and take precedence for those components.
