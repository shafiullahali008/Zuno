@echo off
setlocal
cd /d %~dp0
call provision_all_models_windows.bat
