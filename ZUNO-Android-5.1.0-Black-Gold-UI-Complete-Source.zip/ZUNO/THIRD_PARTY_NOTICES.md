# Third-party notices

## NudeNet 320n model

The bundled `nudenet_320n_fp16.tflite` model is NudeNet 320n by Praneeth Bedapudi / notAI-tech, trained with Ultralytics YOLOv8. It is distributed under GNU Affero General Public License v3.0. See `licenses/NudeNet-AGPL-3.0.txt`.

## PureView / NoXXX source provenance

PureView v2.2.0 is derived from NoXXX and distributed under GNU General Public License v3.0. The license copy supplied with the source archive is retained at `licenses/PureView-GPL-3.0.txt`. Only the data/model assets and compatible algorithmic behavior described in `PUREVIEW-FEATURE-MERGE.md` are merged into VYRA; the PureView Compose UI is not included.

## Adult domain blocklist

`app/src/main/assets/adult_domains.hashes` is derived from the adult-content extension of StevenBlack/hosts. The source list is MIT-licensed; the distributed lookup index contains hashes rather than readable domain names; attribution: Copyright © 2023 Steven Black. See `licenses/StevenBlack-MIT.txt`.

## PureView keyword list

`app/src/main/assets/pureview_keyword_hashes.bin` is copied from the supplied PureView v2.2.0 source archive. The distributed index contains hashes rather than readable terms. Retain the PureView/NoXXX source license notice above when redistributing it.
