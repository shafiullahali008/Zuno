# ZUNO 4.7.0 — Shia Prayer, Azan and audited Android source

ZUNO is an Android focus and digital-wellbeing app with persistent focus sessions, selected-app restrictions, offline page-text/domain checks, on-device image classification, selected-video frame scanning and built-in mini-games. Application ID: `com.nexas.safe`.

## PureView protection
- Bundled NudeNet 320n TFLite model; it is copied into private app storage on first use and runs locally.
- Offline hashed adult-domain and keyword indexes are checked against text exposed by supported browsers and accessibility nodes.
- Selected images and user-imported videos can be analyzed on-device. Video scanning samples up to 60 frames; it is not live or exhaustive video monitoring.
- Existing ZUNO Focus, 7-Layer protection, app restrictions, interface, and arcade games remain. Existing ZUNO games were not replaced with duplicate mini-games.
- No screen capture, MediaProjection, screenshot scanner, screen sharing, screen recording or Internet permission was added.

## Protection boundaries
Android Accessibility can inspect only text/content exposed by supported apps. Browser domain matching depends on the browser exposing its URL or relevant text; this is not system-wide DNS filtering. Image and selected-video inference is local, but probabilistic; false positives and misses are possible. Background availability is subject to Android/device-vendor restrictions.

The PureView screenshot scanner remains excluded to preserve ZUNO's no-capture design. The Compose UI was not imported because ZUNO uses Java Views and already has a distinct interface. ZUNO 4.7.0 adds a native Shia prayer/Azan module with the user-provided Azan recording; it is a ZUNO implementation, not an import of PureView's optional module.

## Build environment and verification
- Android Gradle Plugin 8.7.3, Gradle 8.9 wrapper, JDK 17, compile/target SDK 35, min SDK 26.
- The Gradle wrapper and GitHub Actions build workflow are included. The authoring environment has no Android SDK and cannot reach `services.gradle.org`, so a full Gradle build/APK could not be run locally. The first actual Android build must be confirmed by GitHub Actions after pushing this source.
- See `AUDIT-REPORT-4.6.1.md` for the exact checks performed, fixes and remaining verification gaps.

## Licensing
See `THIRD_PARTY_NOTICES.md`, `licenses/`, and `MODEL-LICENSE.md` before redistribution. The bundled model is AGPL-3.0; related source/data notices are retained.


## Version 4.5.0 model additions

See `RELEASE-NOTES-4.5.0.md`, `MODEL-CATALOG-4.5.0.md`, and `MERGE-REPORT-4.5.0.md` for the bundled text/URL prototype models and their limitations.

## Version 4.6.0 All-in-One and model integration
- Added a gold All-in-One elapsed-time dial (days and HH:MM:SS), fixed-duration presets, custom duration, saved deadline, current/best streak, milestone levels, points and completion/emergency-exit handling.
- Connected the Text Safety and URL Risk prototype adapters to ZUNO's live Accessibility text scan path. Their results remain advisory, not automatic block decisions, because training/validation used synthetic seed data only.
- Preserved the existing NudeNet 320n image model and existing domain/keyword blocking pipeline.
- Retained the NEXAS training/provisioning toolkit under `developer-tools/NEXAS_PUREVIEW_TOOLKIT/`.
- See `RELEASE-NOTES-4.6.0.md`, `MERGE-REPORT-4.6.0.md`, and `MODEL-CATALOG-4.6.0.md` for the original feature scope and limitations.

## Version 4.6.1 source audit fixes
- Added the Gradle 8.9 wrapper and a GitHub Actions workflow for unit tests, debug APK assembly, TFLite structure/smoke checks and model-hash consistency.
- Corrected toolkit project-root discovery, optional Whisper report path, CSV header validation and Python cache exclusions.
- Added model SHA synchronization so retraining updates the Java runtime pins and model checksum manifest.
- Aligned Java URL feature extraction with Python training for IPv4/IPv6 literals, port values and trailing-dot host depth.
- Improved All-in-One countdown presentation, timer view sizing, non-finite model-output handling and Android notification-permission fallback.
- Added system-bar and display-cutout insets on target-SDK-35 screens for Android 15/16.
- Source version: 4.7.0 (versionCode 25). This is not a claim that the Android Gradle build or on-device runtime has passed; see `AUDIT-REPORT-4.6.1.md`.

## Version 4.7.0 — Shia Prayer, Azan and Islamic Calendar
- Added an offline Shia prayer module reachable from Home: Fajr, Dhuhr, Asr, Maghrib and Isha times, next-prayer countdown, Sehri/Fajr and Iftar/Maghrib countdowns, Jafari Islamic midnight estimate, Qibla compass, daily prayer completion tracking, streaks and levels.
- Default calculation preset is Jafari/Qom: Fajr 16°, Maghrib 4° and Isha 14°; Asr uses shadow factor 1. Optional presets include University of Tehran (17.7° / 4.5° / 14°) and Islamic Centre of England (Fajr 15°, Maghrib sunset + 15 minutes, Isha 14°). Local minute offsets are configurable. Prayer methods and local Maghrib definitions can differ by Marja and mosque; users should compare against their trusted local timetable.
- Added the Android Hijri calendar with Shia occasion countdowns (including Ashura, Arbaeen, 13 Rajab, Mid-Sha'ban, Ramadan, Laylat al-Qadr nights, Eid al-Fitr, Eid al-Adha and Eid al-Ghadir), a ±2-day local moon-sighting adjustment, and personal date countdowns. Android's built-in Hijri chronology is an estimate, not an authoritative local moon-sighting calendar.
- Added automatic Azan scheduling, a foreground media-playback service intended to continue with the display locked, a notification action to stop playback, per-prayer Azan switches, audio preview, and an in-app picker to replace the default audio. Uploaded replacement audio is copied into the app-private files directory.
- Bundled the user-provided `Best-Azan-in-the-world.MP3` as `app/src/main/assets/azan_default.mp3` (MP3, 44.1 kHz, stereo, approximately 5m 34s). This user-supplied recording is not independently licensed or redistributed separately from this app source package.
- Location starts with an approximate Wah Cantt fallback (33.7995, 72.7221); the user can grant foreground location permission or enter coordinates manually. Times use the device's current time zone.
- Android requires notification permission for visible stop controls and exact-alarm special access for the most punctual scheduling. Without exact access, the app falls back to inexact idle alarms; battery policies, Do Not Disturb, force-stop and manufacturer-specific restrictions can still delay or prevent playback. This is not an unbreakable alarm guarantee.
- Source version is 4.7.0 (versionCode 25). Source parsing, resource checks, offline solar-calculation tests and media metadata checks were run in the authoring environment. A complete Android Gradle build and real-device playback test remain pending because this environment cannot download the Gradle distribution or install the Android SDK; use the included GitHub Actions workflow for the first full build.

Prayer calculation references:
- Pray Times method documentation: https://praytimes.org/docs/manual (Jafari method values, Asr shadow factor and user adjustments).
- TheShia method documentation: https://theshia.org/en/api/methods/ (Jafari/Qom and Tehran presets).
- TheShia prayer-time documentation: https://theshia.org/en/api/prayer-times/ (Jafari midnight convention and calculation notes).


## Version 4.7.0 Shia prayer module

- See `RELEASE-NOTES-4.7.0.md` for prayer calculation presets, uploaded Azan, lock-screen playback and calendar limitations.
- See `PRAYER-MODULE-IMPLEMENTATION-REPORT-4.7.0.md` for code inventory and test coverage.
