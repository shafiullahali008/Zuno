# VYRA 4.6.0 merge and integration report

## Inputs
- VYRA Android source package 4.5.0.
- NEXAS_PUREVIEW_AI source package 0.3.1.

## Result
The output remains one VYRA Android app (`com.nexas.safe`) using the original Java Views UI and existing application identity. No second Android application/module was added to the build.

### Imported or preserved
- Existing VYRA focus timer, app selection/blocking, 7-layer protection status, reminders, progress, achievements, custom block screen, games, offline domain list, keyword logic, NudeNet image model and selected-video sampler.
- Existing `text_safety.tflite` and `url_risk.tflite` from VYRA were byte-identical to the NEXAS model assets; they were retained in their app assets folder.
- NEXAS Java/TFLite adapters were already present in VYRA. They are now instantiated by `ProtectionAccessibilityService`, called after visible text extraction and their advisory decisions are persisted for the UI.
- The NEXAS model catalog, status, training report, provisioning notes, training scripts, synthetic seed data, requirements and license/attribution material are retained under `developer-tools/NEXAS_PUREVIEW_TOOLKIT/`.

### All-in-One implementation
- `AllInOneDial.java`: custom gold dial displaying elapsed days and HH:MM:SS.
- `AllInOneTime.java`: pure duration validation and elapsed/streak arithmetic.
- `MainActivity.java`: duration selection, opt-in activation, saved deadline, live streak rewards, milestone updates, completion and emergency exit handling.
- `ProtectionPrefs.java`: persistent All-in-One state and deadline takes precedence over the legacy open-ended journey state.
- `ProtectionAccessibilityService.java`: selected-app enforcement uses the shared `isFocusActive()` check, which honours the All-in-One deadline.
- `AllInOneTimeTest.java`: unit tests for duration boundaries, day transitions and elapsed arithmetic.

### Model connection details
1. Service startup attempts to load both supplemental TFLite prototypes and stores `READY` or `MISSING_OR_INCOMPATIBLE` status.
2. Supported Accessibility events expose text to the Text Safety adapter.
3. For supported browsers, explicit URL strings or common bare hostnames exposed in visible text are sent to the URL Risk adapter.
4. The latest result and timestamp are stored locally and shown in the AI section.
5. The models are advisory only. Synthetic-seed model predictions do not directly block content. Existing context-aware keyword and hashed-domain rules still determine automatic text/domain blocks.

## Explicit omissions
The supplied NEXAS archive includes adapter source code for optional models, but did not include their actual model weights. `nsfw_classifier.tflite`, `yamnet.tflite`, `yamnet_class_map.csv` and `asr/whisper_tiny_30s_i8.litertlm` are therefore not packaged or reported as operational. No deepfake or harmful-speech model was supplied. ML Kit OCR, face and image-label dependencies from the separate Kotlin app were not added to VYRA.

## Enforcement boundary
A standard Android app cannot guarantee an unbreakable lock. Selected-app blocking depends on the user-enabled Accessibility service; Android Settings, emergency functions, force-stop/uninstall paths and device-owner controls remain governed by Android and the device owner. All-in-One retains an emergency exit. A stored deadline prevents ordinary in-app duration changes but does not make the device tamper-proof.
