# VYRA + PureView 2.2.0 feature/model merge

This package retains VYRA's existing Java/Android application and adds the compatible PureView offline model and protection indexes. It does not replace VYRA's UI or duplicate its existing games/focus system.

## Integrated
- NudeNet 320n TFLite model bundled in `app/src/main/assets/nudenet_320n_fp16.tflite`; first-use installation is offline and private to the app with a SHA-256 asset check; arbitrary model replacement/import is disabled.
- Tensor shape validation for float32 `[1,320,320,3]` input and `[1,22,2100]` output. The class-selection step follows the upstream per-anchor highest-class decoding and class-specific thresholds.
- Local classification of user-selected images.
- Local selected-video scan using up to 60 evenly spaced frames (minimum 2-second spacing); large frames are downscaled before inference. This is sampled video review, not continuous monitoring.
- Offline domain index derived from the PureView/StevenBlack adult-domain data, stored as non-cryptographic FNV-1a lookup hashes (76,798 source domains). These hashes are a compact index, not encryption.
- Offline phrase index copied from PureView's keyword list, stored as non-cryptographic FNV-1a lookup hashes (437 source entries). These hashes are a compact index, not encryption. Sensitive list contents are not distributed as readable text files.
- Browser-domain and phrase checks integrated into VYRA's existing Accessibility text-scanning service; current safe-context logic remains.
- Existing VYRA focus sessions, 7-Layer controls, selected-app restrictions, UI and arcade games retained. The project already has corresponding focus/productivity mini-games, so duplicate PureView mini-game source was not added.

## Excluded by design / compatibility
- PureView screen/window screenshot scanner and all screen capture/share/recording functions: excluded per VYRA's no-screen-capture requirement.
- PureView Compose UI: not imported; VYRA uses Java Views and retains its own light UI.
- Private DNS setup: not imported; its filtering depends on a configured DNS resolver and Android system settings, rather than the bundled offline AI model.
- Prayer/Azan module: not included in this protection-focused merge. PureView's prayer UI requires a separate VYRA screen integration and the bundled audio's redistribution rights were not established from the supplied project materials.

## Runtime boundaries
- Browser domain detection only works when the browser exposes URL/text via Android Accessibility; this is not device-wide DNS blocking.
- AI detection is probabilistic and may miss content or produce false positives.
- Video analysis samples no more than 60 frames, so content between sampled frames can be missed.
- Background Accessibility execution remains subject to Android and device-vendor behavior.

## Verification
- Domain index: 76,798 source rows / 79,997 stored hashes, parsed and compared against the source data.
- Keyword index: 437 entries, parsed and compared against the supplied source list.
- Core index classes compiled and ran under targeted Java API stubs.
- No full Gradle build, APK generation, physical Android 16 runtime test, or game crash test was performed because Android SDK/Gradle are unavailable in this environment.
