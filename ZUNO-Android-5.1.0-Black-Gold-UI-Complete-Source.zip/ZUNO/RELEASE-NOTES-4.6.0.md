# VYRA 4.6.0 — All-in-One commitment and connected model prototypes

## All-in-One commitment mode
- Added a gold elapsed-time dial with day count and live hours, minutes and seconds.
- Added fixed-duration presets (1, 7, 30, 90 and 365 days) plus a custom duration from 1 minute up to 10 years.
- Activating All-in-One starts the streak immediately, saves a wall-clock start/deadline, enables strict recovery, and freezes the selected-app list until the deadline or an emergency release.
- The streak count, best streak, daily progress, milestones and points are persisted locally and recovered after reopening the app.
- Milestones: 1 day, 7 days, 1 month, 3 months, 6 months, 1 year, 2 years, 5 years and 10 years.
- Points: 5 per fully elapsed 24-hour period, 50 for each newly achieved milestone, and 25 on normal completion. Early emergency exit saves elapsed time but does not award the completion bonus and resets the current streak.
- Emergency release remains available through Android device credentials (when configured) or a timed confirmation flow. Android Settings and essential device functions remain accessible.

## PureView model integration
- Kept the existing NudeNet 320n visual model and image/video selection scanning.
- Connected the existing Text Safety and URL Risk TFLite adapters to the live Accessibility text scan path.
- Text model receives visible text on supported Accessibility events. URL model receives visible `http(s)://`, `www.` or common bare-hostname candidates exposed by supported browsers.
- Text/URL outputs are recorded as advisory model signals. They are not an automatic block authority because both models were trained and evaluated only on synthetic seed data.
- Existing domain-list and context-aware keyword rules remain the actual automatic text/domain blocking mechanism.
- Added model status and last-result reporting in the UI, plus complete model hashes and the NEXAS training/provisioning toolkit.

## Not added / still unavailable
- Optional image-safety (`nsfw_classifier.tflite`), YAMNet weights/labels and Whisper LiteRT-LM bundle were not present in the supplied NEXAS ZIP. Their downloader/provisioning source and limitations are retained under `developer-tools/NEXAS_PUREVIEW_TOOLKIT/`.
- YAMNet audio-event classification, offline speech transcription/moderation, general deepfake detection and production-grade Urdu/Roman Urdu text moderation are not operational features in this build.
- ML Kit OCR/face/label utility dependencies from the separate NEXAS Android app were not introduced into VYRA; they are not standalone safety models and would add unrelated runtime dependencies.

## Build status
- Source version: 4.6.0 (versionCode 23).
- Android SDK and Gradle are not installed in the authoring environment, so no APK/full Android build or Android 16 device test is claimed. See `BUILD-STATUS-4.6.0.md`.
