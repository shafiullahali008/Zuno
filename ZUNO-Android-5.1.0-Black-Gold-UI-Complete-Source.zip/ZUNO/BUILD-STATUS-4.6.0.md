# VYRA 4.6.0 original packaging verification (historical)

## Environment
- Android SDK / `android.jar`: not available in the authoring environment.
- Gradle wrapper was not included in the original 4.6.0 archive; it is added in the 4.6.1 audited source package.
- JDK: `javac` available.
- Compile/target SDK: 35; minimum SDK: 26; Java 17.

## Checks performed for this source package
- ZIP archive integrity checked after packaging.
- Android XML files parsed for well-formedness.
- Model asset sizes, `TFL3` signatures and SHA-256 checksums checked.
- Pure time arithmetic source compiled and exercised with standalone Java checks.
- Static source checks performed for modified Java files and balanced delimiters.

## Not performed
- Full Android Gradle build.
- APK generation/signing.
- Android 16 physical-device testing.
- Android Accessibility, TFLite Interpreter, boot-recovery or app-blocking end-to-end testing.
- Real-world accuracy evaluation for Text Safety or URL Risk.

This file records the original 4.6.0 packaging stage. For the updated wrapper, CI workflow and latest verification state, read `AUDIT-REPORT-4.6.1.md`.
