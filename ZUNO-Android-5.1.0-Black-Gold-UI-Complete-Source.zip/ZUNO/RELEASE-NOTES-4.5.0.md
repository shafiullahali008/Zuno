# VYRA 4.5.0 — model-only expansion

- Preserved VYRA 4.4.0 features, light UI, games, local protection and bundled NudeNet image model.
- Added two verified local TFLite prototype assets: text safety and URL risk.
- Added Java inference modules and SHA-256 checked private model installation.
- Kept model outputs three-state: FLAG, SAFE_CANDIDATE, UNKNOWN. Missing or failed models never return SAFE.
- No new UI, permissions, capture features, network access, or model downloads added.
- Model quality caveat: text/URL weights use synthetic seed datasets only; not production-grade.
