# VYRA 4.5.0 — local model additions

## Bundled models
- `nudenet_320n_fp16.tflite`: existing visual-content detector retained from VYRA 4.4.0.
- `models/text_safety.tflite`: 512-feature text-risk prototype for bullying/threat/scam wording.
- `models/url_risk.tflite`: 20-feature URL-pattern prototype.

## Runtime modules
- `PureViewTextRiskModel`: verified asset installation, local TFLite inference, three-state result.
- `PureViewUrlRiskModel`: verified asset installation, URL feature extraction and local inference.
- `PureViewModelAssets`: private-storage copy and SHA-256 verification.

## Important model limitations
The text and URL models were trained on synthetic seed data only. Their reported holdout metrics are synthetic smoke-test metrics, not real-world accuracy. They must not be treated as a reliable protection boundary or as proof that content is safe. Both modules return `UNKNOWN` when a model is missing, invalid, or inference fails. The existing NudeNet visual model is retained unchanged.

No YAMNet, EfficientDet, speech-recognition, deepfake, or additional NSFW weights are bundled in the source material; adapters or references alone are not trained models.
