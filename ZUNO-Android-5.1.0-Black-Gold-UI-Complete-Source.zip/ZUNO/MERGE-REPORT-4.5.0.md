# VYRA 4.5.0 — feature and model merge report

## Preserved from VYRA 4.4.0
- Existing VYRA light UI, branding, Focus and 7-layer protection flows.
- Existing Temple Sprint / Orbit Roll game code and current app controls.
- Existing PureView local domain and keyword filtering, browser accessibility text checks, selected-image NudeNet inference, and sampled user-selected video frame scan.
- Existing offline behavior and permissions; no screen capture, recording, model downloads, or new network permission was added.
- Existing third-party license notices were retained.

## Added in 4.5.0
- Bundled `text_safety.tflite` and `url_risk.tflite` prototype model weights.
- Java runtime adapters for text-risk and URL-pattern inference.
- SHA-256 verification and private-storage installation for both model files.
- Three-state inference results: `FLAG`, `SAFE_CANDIDATE`, and `UNKNOWN`.
- Model metadata, synthetic-data metrics, and smoke-test vectors bundled beside the weights.

## Deliberately not claimed
- The text and URL models were trained on synthetic seed data only. Synthetic holdout scores are not real-world performance evidence.
- These prototype models are not used as sole automatic blocking authorities. The new adapters expose local inference; existing VYRA blocking logic remains unchanged.
- No additional YAMNet, EfficientDet, ASR, deepfake, or extra NSFW weights were present in the supplied AI package. Adapter references without model weights were not represented as working models.
- No automatic live-screen scanning was added. Android Accessibility reads only supported exposed text/events; video scanning is sampled and limited to user-selected media.

## Local validation
- New Java model classes compile with Java 17 against minimal Android/TFLite API stubs.
- Both bundled TFLite files have a valid `TFL3` header and match their supplied SHA-256 checksums.
- XML parsing and ZIP CRC checks are run during packaging.
- Full Android Gradle build, APK packaging, LiteRT runtime inference, and physical-device testing were not available in this environment. Run the repository's Android CI workflow before installing or releasing.
