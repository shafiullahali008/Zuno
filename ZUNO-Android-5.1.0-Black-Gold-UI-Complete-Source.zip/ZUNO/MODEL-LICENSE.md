# Bundled on-device model notice

This VYRA 4.4.0 source archive includes `app/src/main/assets/nudenet_320n_fp16.tflite`, a NudeNet 320n YOLOv8n TensorFlow Lite model by Praneeth Bedapudi / notAI-tech. The upstream license text is retained at `licenses/NudeNet-AGPL-3.0.txt`.

The application installs the bundled asset into private app storage on first use. It does not download model weights. The model is expected to use float32 NHWC input `[1,320,320,3]` and float32 output `[1,22,2100]`; the app validates these shapes before inference.

The model license is separate from VYRA's own project license. Review AGPL-3.0 attribution, source availability and distribution requirements before redistributing builds or derived products.
