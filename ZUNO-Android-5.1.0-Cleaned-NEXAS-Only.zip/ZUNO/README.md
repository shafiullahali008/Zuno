# ZUNO Android — cleaned source

ZUNO is an Android focus and digital-wellbeing app with focus sessions, selected-app restrictions, All-in-One commitments, streaks, points, levels, built-in games, custom block-screen settings, and the native Shia prayer/Azan and Islamic calendar module. Application ID: `com.nexas.safe`.

## ZUNO-owned AI

The app retains only the NEXAS Text Safety and URL Risk TensorFlow Lite models under `app/src/main/assets/models/`. The app's NEXAS adapters verify the model hashes before copying model files into private app storage. These models are prototype-level and trained on synthetic seed data; their results are advisory and are not used as standalone automatic block decisions.

Android Accessibility can inspect only text and content descriptions exposed by the active app. Browser URL analysis depends on the browser exposing its address text. Focus Mode app restrictions and user-configured text rules remain separate ZUNO features. The app does not use screen capture, MediaProjection, screenshot scanning, screen sharing, or screen recording.

## Removed from this source package

No external app source, imported visual model, adult-domain hash database, imported keyword hash database, image/video classifier, or related runtime integration is included. The old scanner UI and its picker callbacks have also been removed.

## Retained modules

- Focus Mode, selected-app restrictions, reminders, block screen and custom block-screen image.
- All-in-One timer, saved commitment, streaks, milestones, points and levels.
- Built-in games and existing ZUNO interface/branding.
- Native Shia prayer times, Azan scheduling, Qibla, Hijri calendar and occasion countdowns.
- NEXAS AI model training/tooling under `developer-tools/NEXAS_AI_TOOLKIT/`.

## Build and verification

The project includes Gradle wrapper files and GitHub Actions workflow. This cleanup has been statically checked and the ZIP archive integrity is verified; a complete Android Gradle build still needs to run in an environment with the Android SDK and a downloadable Gradle distribution.

## Model limitations

The NEXAS text and URL model weights were trained on synthetic seed data. Smoke-test metrics do not establish real-world accuracy. The models must not be treated as proof that content is safe or as a production-grade protection boundary.

## Islamic calculation notes

Prayer calculations use locally selected presets and device time zone. Prayer methods and local Maghrib definitions can differ by Marja and mosque; users should compare against their trusted local timetable.
